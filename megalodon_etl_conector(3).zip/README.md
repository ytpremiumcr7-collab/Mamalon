# Megalodon Costos — Base de datos, ETL y conector (v4.0)

Entregable completo para alimentar el backend `megalodon_costos_v3_3.py` con
todos los documentos del ZIP (`txtmd1.zip`, 118 archivos / 263 MB: leyes,
catálogos CMIC/CDMX, libros técnicos, normativa SAT/CFDI, formularios, etc.)

## Contenido

```
schema/
  schema_megalodon_definitivo.sql   # Esquema PostgreSQL completo (v3.3 + ampliación v4.0)
db/
  connector.py                      # Conector con pool de conexiones (drop-in para el backend)
etl/
  config.py                         # Configuración (variables de entorno)
  classify.py                       # Clasificador de archivos -> estrategia de ingestión
  utils.py                          # Hashing, limpieza de texto OCR, parsing de montos
  pipeline.py                       # Orquestador: recorre, clasifica, parsea y carga
  cli.py                            # Punto de entrada (`python -m etl.cli`)
  parsers/
    leyes.py                        # LOPSRM/LAASSP/LGA/LGPDPPSO/reglamentos -> artículos
    catalogos_excel.py              # XLSX limpios (SGIH, tabulador CDMX, pesos materiales)
    catalogos_ocr_txt.py            # TXT de catálogos CMIC con OCR degradado
    referencias_pdf.py              # Libros/manuales/informes PDF
    referencias_md.py               # Markdown (catálogos CFDI/NOM/PACs + narrativa)
    referencias_docx.py             # DOCX (costos paramétricos por m², texto)
    legacy_office.py                # Conversión .doc/.xls -> .docx/.xlsx vía LibreOffice
    nested_zip.py                   # Extracción recursiva de zips anidados (FORMULARIOS.zip)
requirements.txt
```

## 1. Crear la base de datos

```bash
createdb megalodon          # o usa tu instancia de Supabase
psql $DATABASE_URL -f schema/schema_megalodon_definitivo.sql
```

El script es **100% compatible con `megalodon_costos_v3_3.py`**: no renombra
ni elimina ninguna tabla/columna de tu borrador v3.3 (las consultas literales
de `RepositorioPostgres` se revisaron una por una contra el esquema). Solo
**añade**:

- `leyes` / `ley_articulos` — marco legal completo con texto íntegro y
  artículos individuales, indexados con full-text search en español.
- `documentos_referencia` / `documento_referencia_fragmentos` — base de
  conocimiento técnico (libros, manuales, informes) con FTS.
- `catalogos_referencia_generica` — catálogos clave/descripción genéricos
  (CFDI, Carta Porte, NOM, PACs, combustibles, casetas, etc.).
- `costos_parametricos_m2` / `materiales_pesos_referencia` — tablas de
  ingeniería (costos por m² y pesos de perfiles/materiales).
- `etl_archivos_procesados` / `etl_runs` — bitácora de idempotencia y
  auditoría del pipeline.
- Columnas nuevas en `catalogo_insumos` (`confianza_extraccion`,
  `pagina_origen`, `seccion`) y `catalogos_fuente` (`archivo_origen`,
  `hash_sha256` + índice único parcial sobre `hash_archivo`).
- Extensión `pg_trgm` (búsqueda difusa) y una vista `v_busqueda_unificada`.

## 2. Instalar dependencias

```bash
pip install -r requirements.txt --break-system-packages
```

Para convertir los 3 archivos legados (`.doc`/`.xls`) necesitas **LibreOffice**
instalado localmente (headless, sin red): `apt install libreoffice` o
equivalente. El pipeline lo invoca vía `soffice --headless --convert-to`.

## 3. Configurar variables de entorno

```bash
export DATABASE_URL="postgresql://user:pass@host:5432/megalodon"
export ETL_SOURCE_DIR="/ruta/a/la/carpeta/txtmd"   # carpeta descomprimida del zip
```

## 4. Validar antes de cargar (recomendado)

```bash
python -m etl.cli --dry-run --reporte reporte.json
```

Esto recorre y parsea **todo** el corpus sin tocar la base de datos y te
imprime conteos por tipo de archivo. Ya se ejecutó contra tu ZIP completo:
ver sección "Resultado de la validación" abajo.

## 5. Cargar a PostgreSQL

```bash
python -m etl.cli
```

El pipeline es **idempotente**: vuelve a correrlo cuantas veces quieras — cada
archivo se identifica por su hash SHA-256 en `etl_archivos_procesados`, así
que si no cambió, se omite; si cambió, se reprocesa y reemplaza sus filas
(catálogos, artículos de ley, fragmentos, etc. — sin duplicar).

### Si corres esto en Termux/Android y el proceso se cierra solo

Android puede matar la app de Termux si pasa a segundo plano o se apaga la
pantalla, sin importar nada de tu código. Como la carga real SÍ es
resumible (por el hash de cada archivo), un corte a medias no es grave —
solo vuelve a correr el mismo comando y retoma donde se quedó. Para
evitar el corte de inicio:

```bash
# corre en segundo plano, sobrevive si se cierra la sesión de terminal
nohup python -m etl.cli > etl.log 2>&1 &
disown

# revisa el avance sin bloquear la terminal
tail -f etl.log
```

Si tienes `termux-api` instalado, además ejecuta `termux-wake-lock` antes de
empezar para evitar que Android suspenda el proceso por inactividad de
pantalla.

## 6. Conectar el backend (`megalodon_costos_v3_3.py`)

El backend original abre una conexión PostgreSQL nueva en cada query. El
conector añade un pool sin tocar tu archivo:

```python
import megalodon_costos_v3_3 as backend
from db.connector import get_repositorio

repo = get_repositorio(backend)   # mismo objeto, misma interfaz, con pool
```

`RepositorioPostgresPool` hereda de tu `RepositorioPostgres` y solo
sobreescribe `_get_conn()`; todas las queries y el mapeo a dataclasses
siguen siendo exactamente las que ya escribiste.

Diagnóstico rápido de conexión:

```bash
python -m db.connector --check
```

## Arquitectura v6: catálogos CMIC "estudio de mercado" a confianza ALTA + reporte honesto

Sesión de depuración dirigida (el usuario marcó archivos con extracción
pobre y exigió **confiabilidad real para presupuestar licitaciones**, no
solo candidatos de baja confianza):

- **7 catálogos CMIC que daban 0 (o un "1 registro" engañoso)** —
  Vivienda, Sector Salud, Infraestructura Educativa, Cimentaciones
  Profundas, Perforación de Pozos para Agua, Rehabilitación de Pozos,
  Ecotecnologías — resultaron tener un formato distinto al que asumía el
  extractor original: NO son catálogos de conceptos APU, son un **estudio
  de mercado de precios de materiales y mano de obra por región y zona
  (Urbana/Rural)**, repetido en 9 bloques "Parte N" por archivo. Se
  construyó `extractor_cmic_estudio_mercado` (validado fila por fila contra
  el texto fuente real de los 6 archivos) que captura clave, descripción,
  unidad, precio **y la zona económica exacta** (ej. "Coahuila Sureste -
  URBANA") en la nueva columna `catalogo_insumos.zona` — exactamente para
  poder presupuestar distinto por ubicación, como pediste.
- `extractor_cmic_catalogo` (el genérico) ahora cae automáticamente a este
  nuevo extractor si encuentra menos de 5 coincidencias — protege contra
  que un catálogo CMIC no mapeado explícitamente repita el mismo fallo.
- **Fecha de vigencia real**: antes todo quedaba fechado "2026" porque era
  un valor estático adivinado. Ahora se busca la fecha real en el propio
  documento (`Vigencia a partir de enero de 2026`, `Ciudad de México, a 31
  de marzo de 2026`, etc.) y esa es la que se guarda en
  `catalogos_fuente.vigencia_desde` — confirmado: el "Factor de Indirecto"
  de marzo quedó fechado marzo (no enero).
- **Factor de Indirecto CDMX reescrito**: el formato real es una tabla fija
  de 9-10 tipos de servicio con su propio multiplicador (no un porcentaje
  mensual único, que era la suposición original) — ahora extrae los 10/10
  valores correctamente.
- **El reporte ya no oculta extracciones pobres**: antes "Parciales/err"
  imprimía por error el contador de errores (siempre 0), no el de
  parciales — un catálogo con 1 registro se reportaba como
  "PROCESADO" exitoso. Ahora hay un contador `parcial` separado, cualquier
  catálogo con menos de 5 registros se marca `PARCIAL` explícitamente, y el
  CLI lista esos archivos al final con el motivo.

## Arquitectura v5: extracción nativa de alta confianza

A partir de un ETL de referencia que aportaste (`megalodon_etl_cmic_2_.py`),
se identificó que apuntaba a un esquema `costos.*` **distinto** del que usa
tu backend real (`piedra_angular_megalodon.py`, que exige el esquema
`megalodon`). Se portó su técnica de extracción (mucho más precisa) pero
dirigida al esquema `megalodon` real:

- `etl/parsers/catalogos_pdf_nativo.py` — usa `pdftotext -layout` (poppler)
  directo sobre el PDF nativo, con regex afinados por familia editorial
  (SICT, CMIC, CFE, CONAGUA, CDMX, CEICO, salarios, maquinaria). Esto evita
  el ruido de marca de agua que sí tienen los `.txt` pre-OCR'd, y funciona
  igual sobre `.md`/`.txt` ya limpios (reutiliza los mismos patrones).
- Si el PDF no tiene capa de texto (escaneado), cae automáticamente a OCR
  con Tesseract (`-l eng`; este entorno no tiene el paquete de idioma
  español — instala `tesseract-ocr-spa` para mejor calidad en producción).
- Si ni con eso se encuentra nada estructurado, cae al texto completo
  indexado (igual que antes) — **ningún archivo se queda sin indexar**.
- Nuevas tablas (`schema_megalodon_definitivo.sql` sección 14):
  `maquinaria_catalogo`, `mano_obra_salarios`, `indices_precios_materiales`,
  `factores_indirectos`, `costos_parametricos_obra`, `rendimientos_mano_obra`
  — alimentan directamente `MotorPreciosBIM`/`AnalisisPreciosUnitarios` de
  tu backend. `catalogos_fuente` ganó `categoria_sector`/`codigo_fuente`/
  `anio_vigencia` para el selector "2026|2025|2024 → CMIC Vivienda → ..."
  que describes para el frontend (ver vista `v_explorador_catalogos`).
- `leyes` ganó `ambito`/`estado`/`municipio` + vista `v_marco_juridico_aplicable`
  para el motor jurídico de 12 reglas (resuelve leyes federales + estatales +
  municipales según la ubicación de la licitación).
- `costos_parametricos_m2` preserva el histórico de los 5 periodos (no solo
  el valor más reciente) en `metadata_jsonb.historico_periodos` — pensado
  para alimentar directamente tu módulo de Montecarlo histórico.

## Resultado de la validación (lote de 77 archivos, post-fix v6)

**77/77 archivos, 0 errores, 70 PROCESADO + 7 PARCIAL (genuinos, ver abajo)**,
20,742 registros, con reporte honesto (ya no oculta extracciones pobres):

| Tipo detectado | Archivos | Notas |
|---|---|---|
| `CATALOGO_PDF_NATIVO` | 43 | Conceptos APU, maquinaria, paramétricos, salarios, índices CEICO, factores de indirecto, **y los 7 estudios de mercado CMIC con zona económica por fila** |
| `REFERENCIA_MD` | 14 | Catálogos CFDI/NOM/PACs + normativa |
| `CATALOGO_OCR_TXT` | 7 | Textos sin tabla de precios (libros/artículos) — 0 candidatos es el resultado correcto, no una falla |
| `LEY_TXT` | 7 | LOPSRM, LAASSP, LGA, LGPDPPSO, etc. |
| `REFERENCIA_DOCX` | 2 | Costos paramétricos m² |
| `REFERENCIA_PDF` | 2 | Libros sin patrón de catálogo conocido |
| `CATALOGO_XLSX_LIMPIO` | 2 | SGIH, tabulador CDMX |

Los 7 `PARCIAL` son documentos legítimamente sin tabla de precios (manual de
Geo-Python, informe de Big Data, etc.) — 0 registros estructurados ahí es
correcto, no un fallo. Si en el ZIP completo aparece un `PARCIAL` en un
archivo que SÍ debería tener precios, ese es el que hay que revisar.

## Limitaciones conocidas (decisión deliberada, no descuido)

1. **Catálogos CMIC/CEICO en `.txt`/PDF que aún no coinciden con ningún
   patrón validado** (distintos de los 7 ya corregidos arriba): si el
   extractor de alta confianza no encuentra nada, el pipeline cae al texto
   completo indexado + candidatos de precio en `confianza_extraccion='BAJA'`,
   pensados para curaduría manual, **no para presupuestar directamente**
   sin revisión. Mándame cualquier archivo de este tipo que seas detectado
   en `PARCIAL`/`CATALOGO_OCR_TXT` y lo reviso igual que estos 7.
2. **PDFs grandes tipo tabulador** (`TCD_Cons-2026.pdf`, 485 páginas, con capa
   de texto nativa) se indexan como texto completo + fragmentos buscables,
   pero no se intenta reconstruir su tabla de precios automáticamente — son
   buenos candidatos para una segunda fase de extracción de tablas.
3. `116871_RPTB86F.xls` es una plantilla vacía de análisis de precio unitario
   (formato OPUS/ECOSTOS) sin datos cargados — se detecta y se omite
   correctamente (0 filas, sin error).
