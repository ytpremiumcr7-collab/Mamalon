"""
db/connector.py
================
Conector robusto de PostgreSQL para Megalodon Costos.

Resuelve dos problemas del backend original (megalodon_costos_v3_3.py):
  1. RepositorioPostgres abre una conexión TCP nueva en cada query
     (psycopg2.connect en cada _get_conn). Bajo carga esto es lento y
     puede agotar conexiones del servidor (especialmente en Supabase,
     que limita conexiones concurrentes).
  2. No hay reintentos ni manejo de caídas de red transitorias.

Este módulo agrega un pool de conexiones (ThreadedConnectionPool) y una
clase `RepositorioPostgresPool` que hereda de `RepositorioPostgres` y
únicamente sobreescribe `_get_conn()`, por lo que TODO el resto del
backend (queries, mapeos a dataclasses, etc.) sigue funcionando exactamente
igual, sin tocar megalodon_costos_v3_3.py.

Uso típico en el backend:

    from db.connector import get_repositorio
    repo = get_repositorio()   # usa DATABASE_URL / USE_DATABASE del entorno

Uso típico en el ETL:

    from db.connector import get_pool, pooled_cursor
    with pooled_cursor(commit=True) as cur:
        cur.execute("INSERT INTO ...", params)
"""
from __future__ import annotations

import os
import sys
import time
import logging
import threading
from contextlib import contextmanager
from typing import Optional, Iterable, Sequence, Any

try:
    import psycopg2
    import psycopg2.pool
    import psycopg2.extras
    from psycopg2.extras import RealDictCursor, Json, execute_values
    _PSYCOPG2_AVAILABLE = True
except ImportError:
    _PSYCOPG2_AVAILABLE = False

log = logging.getLogger("megalodon.db.connector")

# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------

def _database_url() -> str:
    url = (
        os.environ.get("DATABASE_URL")
        or os.environ.get("SUPABASE_DB_URL")
        or "postgresql://user:pass@localhost/megalodon"
    )
    return url


DB_POOL_MIN = int(os.environ.get("DB_POOL_MIN", "1"))
DB_POOL_MAX = int(os.environ.get("DB_POOL_MAX", "10"))
DB_CONNECT_RETRIES = int(os.environ.get("DB_CONNECT_RETRIES", "5"))
DB_CONNECT_BACKOFF_S = float(os.environ.get("DB_CONNECT_BACKOFF_S", "1.5"))
DB_REQUIRED_SCHEMA = "megalodon"


class PoolNotAvailable(RuntimeError):
    pass


# ---------------------------------------------------------------------------
# Pool singleton (thread-safe)
# ---------------------------------------------------------------------------

_pool_lock = threading.Lock()
_pool: "Optional[psycopg2.pool.ThreadedConnectionPool]" = None


def get_pool(dsn: Optional[str] = None) -> "psycopg2.pool.ThreadedConnectionPool":
    global _pool
    if not _PSYCOPG2_AVAILABLE:
        raise PoolNotAvailable(
            "psycopg2 no está instalado. Ejecuta: pip install psycopg2-binary --break-system-packages"
        )
    if _pool is not None:
        return _pool
    with _pool_lock:
        if _pool is not None:
            return _pool
        dsn = dsn or _database_url()
        last_err = None
        for attempt in range(1, DB_CONNECT_RETRIES + 1):
            try:
                _pool = psycopg2.pool.ThreadedConnectionPool(DB_POOL_MIN, DB_POOL_MAX, dsn)
                log.info("Pool PostgreSQL inicializado (min=%s, max=%s)", DB_POOL_MIN, DB_POOL_MAX)
                return _pool
            except Exception as e:  # noqa: BLE001
                last_err = e
                log.warning("Intento %s/%s de conexión a PostgreSQL falló: %s", attempt, DB_CONNECT_RETRIES, e)
                time.sleep(DB_CONNECT_BACKOFF_S * attempt)
        raise RuntimeError(f"No se pudo establecer el pool de conexiones a PostgreSQL: {last_err}")


def close_pool() -> None:
    global _pool
    with _pool_lock:
        if _pool is not None:
            _pool.closeall()
            _pool = None
            log.info("Pool PostgreSQL cerrado.")


def verify_schema(dsn: Optional[str] = None) -> bool:
    """Confirma que el esquema 'megalodon' (y al menos la tabla expedientes) existe."""
    with pooled_cursor(dsn=dsn) as cur:
        cur.execute(
            "SELECT 1 FROM information_schema.tables WHERE table_schema=%s AND table_name='expedientes' LIMIT 1",
            (DB_REQUIRED_SCHEMA,),
        )
        return cur.fetchone() is not None


# ---------------------------------------------------------------------------
# Wrapper de conexión: se comporta como una conexión psycopg2 normal dentro
# de un bloque `with`, pero al salir la regresa al pool en vez de cerrarla.
# Esto permite que RepositorioPostgres (backend original) siga usando
# `with self._get_conn() as conn:` sin cambios.
# ---------------------------------------------------------------------------

class _PooledConnection:
    def __init__(self, pool: "psycopg2.pool.ThreadedConnectionPool"):
        self._pool = pool
        self._conn = pool.getconn()

    def __enter__(self):
        return self._conn

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is not None:
                self._conn.rollback()
        finally:
            self._pool.putconn(self._conn)
        return False

    def cursor(self, *a, **kw):
        return self._conn.cursor(*a, **kw)

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._pool.putconn(self._conn)


def get_pooled_connection(dsn: Optional[str] = None) -> _PooledConnection:
    return _PooledConnection(get_pool(dsn))


@contextmanager
def pooled_cursor(dsn: Optional[str] = None, commit: bool = False, dict_cursor: bool = True):
    """Context manager de alto nivel para uso en ETL/scripts sueltos."""
    pool = get_pool(dsn)
    conn = pool.getconn()
    try:
        cur_factory = RealDictCursor if dict_cursor else None
        with conn.cursor(cursor_factory=cur_factory) as cur:
            yield cur
        if commit:
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        pool.putconn(conn)


def bulk_upsert(table: str, columns: Sequence[str], rows: Iterable[Sequence[Any]],
                 conflict_cols: Optional[Sequence[str]] = None,
                 update_cols: Optional[Sequence[str]] = None,
                 dsn: Optional[str] = None, page_size: int = 500) -> int:
    """
    Inserta en bloque con execute_values. Si conflict_cols se especifica,
    genera ON CONFLICT (...) DO UPDATE para las columnas indicadas en update_cols
    (o todas excepto las de conflicto si no se especifican).
    Devuelve el número de filas enviadas (no necesariamente las afectadas, por los DO NOTHING).
    """
    rows = list(rows)
    if not rows:
        return 0
    cols_sql = ", ".join(columns)
    query = f"INSERT INTO {table} ({cols_sql}) VALUES %s"
    if conflict_cols:
        upd_cols = update_cols or [c for c in columns if c not in conflict_cols]
        set_sql = ", ".join(f"{c}=EXCLUDED.{c}" for c in upd_cols)
        query += f" ON CONFLICT ({', '.join(conflict_cols)}) DO UPDATE SET {set_sql}"
    with pooled_cursor(dsn=dsn, commit=True, dict_cursor=False) as cur:
        execute_values(cur, query, rows, page_size=page_size)
    return len(rows)


# ---------------------------------------------------------------------------
# Integración directa con el backend megalodon_costos_v3_3.py
# ---------------------------------------------------------------------------

def get_repositorio(backend_module=None):
    """
    Devuelve una instancia de repositorio apta para el backend, usando pool
    de conexiones en vez de abrir una conexión nueva por query.

    `backend_module` es el módulo megalodon_costos_v3_3 ya importado por
    quien llama (para no generar una dependencia circular de import aquí).
    Si no se provee, se intenta importar por nombre de archivo estándar.
    """
    if backend_module is None:
        import importlib
        backend_module = importlib.import_module("megalodon_costos_v3_3")

    RepositorioPostgres = backend_module.RepositorioPostgres
    ConfigDB = backend_module.ConfigDB

    class RepositorioPostgresPool(RepositorioPostgres):
        def __init__(self, dsn):
            self.dsn = dsn
            self._lock = threading.RLock()
            get_pool(dsn)  # fuerza creación/validación temprana del pool
            self._validate_connection()

        def _get_conn(self):
            return get_pooled_connection(self.dsn)

    if not ConfigDB.USE_DATABASE:
        raise RuntimeError("USE_DATABASE=false: configura USE_DATABASE=true y DATABASE_URL en el entorno.")
    return RepositorioPostgresPool(ConfigDB.DATABASE_URL)


# ---------------------------------------------------------------------------
# CLI de diagnóstico: `python -m db.connector --check`
# ---------------------------------------------------------------------------

def _main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if not _PSYCOPG2_AVAILABLE:
        print("❌ psycopg2 no está instalado. pip install psycopg2-binary --break-system-packages")
        sys.exit(1)
    try:
        get_pool()
        ok = verify_schema()
        if ok:
            print("✅ Conexión exitosa y esquema 'megalodon' presente (tabla 'expedientes' encontrada).")
        else:
            print("⚠️  Conexión exitosa, pero no se encontró el esquema 'megalodon'. Ejecuta schema_megalodon_definitivo.sql")
            sys.exit(2)
    except Exception as e:  # noqa: BLE001
        print(f"❌ Error de conexión: {e}")
        sys.exit(1)
    finally:
        close_pool()


if __name__ == "__main__":
    _main()
