"""
etl/parsers/legacy_office.py — convierte .doc/.xls (OLE legado) a .docx/.xlsx
usando LibreOffice en modo headless (sin red, 100% local), para luego
reutilizar los parsers modernos (catalogos_excel / referencias_docx).
"""
from __future__ import annotations
import shutil
import subprocess
from pathlib import Path

from ..config import SOFFICE_BIN


class ConversionError(RuntimeError):
    pass


def convertir(path: Path, destino_dir: Path, formato: str, timeout: int = 120) -> Path:
    """
    formato: 'xlsx' para .xls -> .xlsx, 'docx' para .doc -> .docx
    Devuelve la ruta del archivo convertido dentro de destino_dir.
    """
    destino_dir.mkdir(parents=True, exist_ok=True)
    soffice = shutil.which(SOFFICE_BIN)
    if not soffice:
        raise ConversionError(
            f"No se encontró el binario '{SOFFICE_BIN}' (LibreOffice). "
            "Instálalo o ajusta SOFFICE_BIN en el entorno."
        )
    cmd = [soffice, "--headless", "--norestore", "--convert-to", formato, "--outdir", str(destino_dir), str(path)]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired as e:
        raise ConversionError(f"Conversión de {path.name} excedió el timeout de {timeout}s") from e
    salida = destino_dir / f"{path.stem}.{formato}"
    if proc.returncode != 0 or not salida.exists():
        raise ConversionError(
            f"LibreOffice no pudo convertir {path.name} (rc={proc.returncode}): "
            f"{proc.stdout[-400:]} {proc.stderr[-400:]}"
        )
    return salida
