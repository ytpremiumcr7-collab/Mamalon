"""
etl/parsers/referencias_md.py — markdown con tablas (catálogos genéricos
tipo CFDI/Carta Porte, NOM, PACs, combustibles, casetas) y markdown
narrativo (legislación, normativa, estándares).
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

_TABLA_RE = re.compile(
    r"(?P<encabezado>^\|.+\|)\n\|[-:| ]+\|\n(?P<filas>(?:^\|.*\|\n?)+)",
    re.MULTILINE,
)
_TITULO_SECCION_RE = re.compile(r"(?m)^#{1,3}\s+(.+)$")


@dataclass
class FilaTablaGenerica:
    catalogo_nombre: str
    clave: str
    descripcion: str
    valor_adicional: str


@dataclass
class ResultadoMarkdown:
    archivo: str
    titulo: str
    texto_completo: str
    tiene_tablas: bool
    filas_genericas: List[FilaTablaGenerica] = field(default_factory=list)


def _seccion_previa(pos: int, texto: str) -> str:
    ultimo = ""
    for m in _TITULO_SECCION_RE.finditer(texto[:pos]):
        ultimo = m.group(1).strip()
    return ultimo


def _split_row(line: str) -> List[str]:
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def parse_markdown(path: Path) -> ResultadoMarkdown:
    texto = path.read_text(encoding="utf-8", errors="replace")
    m_titulo = re.search(r"(?m)^#\s+(.+)$", texto)
    titulo = m_titulo.group(1).strip() if m_titulo else path.stem

    filas: List[FilaTablaGenerica] = []
    tiene_tablas = False
    for tm in _TABLA_RE.finditer(texto):
        tiene_tablas = True
        encabezado = _split_row(tm.group("encabezado"))
        nombre_catalogo = _seccion_previa(tm.start(), texto) or path.stem
        # localiza columnas plausibles: clave, descripcion, valor/vigencia/monto
        idx_clave = next((i for i, h in enumerate(encabezado) if re.search(r"clave|c[oó]digo|key", h, re.I)), 0)
        idx_desc = next((i for i, h in enumerate(encabezado) if re.search(r"descrip|nombre|concepto", h, re.I)),
                         1 if len(encabezado) > 1 else 0)
        idx_valor = next((i for i, h in enumerate(encabezado) if re.search(r"vigenc|valor|monto|precio|fecha", h, re.I)), None)

        for linea in tm.group("filas").strip().splitlines():
            celdas = _split_row(linea)
            if len(celdas) <= max(idx_clave, idx_desc):
                continue
            clave = celdas[idx_clave].strip()
            desc = celdas[idx_desc].strip() if idx_desc < len(celdas) else ""
            if not clave or clave in ("---", ""):
                continue
            valor = celdas[idx_valor].strip() if (idx_valor is not None and idx_valor < len(celdas)) else ""
            filas.append(FilaTablaGenerica(
                catalogo_nombre=nombre_catalogo[:120],
                clave=clave[:120],
                descripcion=desc[:500],
                valor_adicional=valor[:200],
            ))

    return ResultadoMarkdown(
        archivo=path.name,
        titulo=titulo,
        texto_completo=texto,
        tiene_tablas=tiene_tablas,
        filas_genericas=filas,
    )
