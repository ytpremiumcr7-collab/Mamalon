"""
etl/parsers/leyes.py — extrae metadatos + artículos de textos legales.

Funciona tanto con los archivos "_ESTRUCTURADO.txt" (ya separados con
encabezados TÍTULO/CAPÍTULO) como con los .txt "planos" de la misma ley
(LOPSRM (1).txt, LGA.txt, etc.) que tienen el mismo cuerpo sin esos
separadores extra; el regex de artículos funciona en ambos casos.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

# Detecta encabezado de artículo: "Artículo 123." / "Artículo 45 Bis." / "Artículo 7o."
_ART_RE = re.compile(
    r"(?m)^\s*Art[íi]culo\s+(\d+(?:\s*(?:Bis|Ter|Quáter|Quater|Quinquies))?(?:o)?\.?)\s*\.?\s*"
)
_TITULO_RE = re.compile(r"(?m)^\s*T[ÍI]TULO\s+([A-ZÁÉÍÓÚÑ]+)")
_CAPITULO_RE = re.compile(r"(?m)^\s*CAP[ÍI]TULO\s+([A-ZÁÉÍÓÚÑ0-9]+)")
_TRANSITORIO_RE = re.compile(r"(?m)^\s*(Transitorios?|TRANSITORIOS?)\b")
_REFORMA_RE = re.compile(r"DOF\s+(\d{2}-\d{2}-\d{4})")
_ULTIMA_REFORMA_RE = re.compile(r"[ÚU]ltima Reforma DOF\s+(\d{2}-\d{2}-\d{4})", re.IGNORECASE)

# Catálogo de leyes conocidas: clave -> (nombre completo, regex de archivo)
CATALOGO_LEYES = {
    "LOPSRM": "Ley de Obras Públicas y Servicios Relacionados con las Mismas",
    "LAASSP": "Ley de Adquisiciones, Arrendamientos y Servicios del Sector Público",
    "LGA": "Ley General de Aguas / Ley de Aguas Nacionales",
    "LGPDPPSO": "Ley General de Protección de Datos Personales en Posesión de Sujetos Obligados",
    "LEY_FISCALIZACION": "Ley de Fiscalización y Rendición de Cuentas de la Federación",
    "REG_LOPSRM": "Reglamento de la Ley de Obras Públicas y Servicios Relacionados con las Mismas",
    "REG_LAASSP": "Reglamento de la Ley de Adquisiciones, Arrendamientos y Servicios del Sector Público",
    "LEY_CONTRATACION_EDOMEX": "Ley de Contratación Pública del Estado de México y Municipios",
    "LEY_OBRAS_TLAXCALA": "Ley de Obras Públicas para el Estado de Tlaxcala y sus Municipios",
}


@dataclass
class ArticuloExtraido:
    numero_articulo: str
    titulo: str
    capitulo: str
    titulo_seccion: str
    texto: str
    orden: int
    es_transitorio: bool
    reformas_dof: List[str] = field(default_factory=list)


@dataclass
class LeyExtraida:
    clave: str
    nombre_completo: str
    jurisdiccion: str
    archivo_origen: str
    texto_completo: str
    ultima_reforma_dof: Optional[str]
    articulos: List[ArticuloExtraido]


def _detectar_clave(nombre_archivo: str) -> str:
    n = nombre_archivo.upper()
    if "LOPSRM" in n and ("REG" in n or "REGLAMENTO" in n):
        return "REG_LOPSRM"
    if "LAASSP" in n and ("REG" in n or "REGLAMENTO" in n or n.startswith("R")):
        return "REG_LAASSP"
    if "LOPSRM" in n:
        return "LOPSRM"
    if "LAASSP" in n:
        return "LAASSP"
    if "LGPDPPSO" in n:
        return "LGPDPPSO"
    if "FISCALIZACION" in n:
        return "LEY_FISCALIZACION"
    if "EDOMEX" in n or "ESTADO-DE-MEXICO" in n or "ESTADO_DE_MEXICO" in n:
        return "LEY_CONTRATACION_EDOMEX"
    if "TLAXCALA" in n:
        return "LEY_OBRAS_TLAXCALA"
    if re.match(r"^LGA([_.\s]|$)", n):
        return "LGA"
    # fallback: usa el stem del archivo como clave
    return re.sub(r"[^A-Z0-9]+", "_", Path(nombre_archivo).stem.upper()).strip("_")[:60]


def parse_ley(path: Path, jurisdiccion: str = "FEDERAL") -> LeyExtraida:
    raw = path.read_text(encoding="utf-8", errors="replace")
    return parse_ley_texto(raw, path.name, jurisdiccion)


def parse_ley_texto(raw: str, nombre_archivo: str, jurisdiccion: str = "FEDERAL") -> LeyExtraida:
    clave = _detectar_clave(nombre_archivo)
    nombre_completo = CATALOGO_LEYES.get(clave, Path(nombre_archivo).stem.replace("_", " ").strip())

    m_ref = _ULTIMA_REFORMA_RE.search(raw)
    ultima_reforma = m_ref.group(1) if m_ref else None

    articulos = _extraer_articulos(raw)

    return LeyExtraida(
        clave=clave,
        nombre_completo=nombre_completo,
        jurisdiccion=jurisdiccion,
        archivo_origen=nombre_archivo,
        texto_completo=raw,
        ultima_reforma_dof=ultima_reforma,
        articulos=articulos,
    )


def _extraer_articulos(raw: str) -> List[ArticuloExtraido]:
    matches = list(_ART_RE.finditer(raw))
    articulos: List[ArticuloExtraido] = []
    if not matches:
        return articulos

    # Pre-calcula posiciones de título/capítulo para asignar contexto a cada artículo
    titulos = [(m.start(), m.group(1)) for m in _TITULO_RE.finditer(raw)]
    capitulos = [(m.start(), m.group(1)) for m in _CAPITULO_RE.finditer(raw)]
    transitorios_pos = None
    m_tr = _TRANSITORIO_RE.search(raw)
    if m_tr:
        transitorios_pos = m_tr.start()

    def _contexto(pos: int, lista):
        actual = ""
        for p, val in lista:
            if p <= pos:
                actual = val
            else:
                break
        return actual

    seen = {}
    for idx, m in enumerate(matches):
        numero = m.group(1).strip().rstrip(".")
        start = m.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(raw)
        texto = raw[start:end].strip()
        if not texto or len(texto) < 3:
            continue
        titulo_ctx = _contexto(m.start(), titulos)
        capitulo_ctx = _contexto(m.start(), capitulos)
        es_transitorio = transitorios_pos is not None and m.start() >= transitorios_pos
        reformas = _REFORMA_RE.findall(texto)[:10]

        key = numero
        orden = seen.get(key, 0)
        seen[key] = orden + 1

        articulos.append(ArticuloExtraido(
            numero_articulo=numero,
            titulo=f"Artículo {numero}",
            capitulo=capitulo_ctx,
            titulo_seccion=titulo_ctx,
            texto=texto[:20000],
            orden=orden,
            es_transitorio=es_transitorio,
            reformas_dof=reformas,
        ))
    return articulos
