"""
etl/parsers/referencias_pdf.py — extrae texto de PDFs (libros, manuales,
informes, catálogos no tabulares) para indexarlos como documentos_referencia
+ fragmentos de búsqueda. No intenta reconstruir tablas de precios desde PDF
(para eso existen los .xlsx ya extraídos / el ETL OCR de catálogos txt);
aquí el objetivo es hacer buscable el conocimiento técnico.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

import pdfplumber

from ..utils import limpiar_texto_ocr_basico, chunk_text
from ..config import FRAGMENTO_CHARS, MAX_TEXTO_COMPLETO_CHARS


@dataclass
class FragmentoPDF:
    pagina: int
    orden: int
    contenido: str


@dataclass
class ResultadoPDF:
    archivo: str
    paginas: int
    texto_completo: str
    calidad_extraccion: str
    fragmentos: List[FragmentoPDF] = field(default_factory=list)


def parse_pdf(path: Path, max_paginas: int | None = None) -> ResultadoPDF:
    textos_pagina: List[str] = []
    n_paginas = 0
    paginas_sin_texto = 0
    with pdfplumber.open(str(path)) as pdf:
        n_paginas = len(pdf.pages)
        limite = min(n_paginas, max_paginas) if max_paginas else n_paginas
        for i in range(limite):
            try:
                txt = pdf.pages[i].extract_text() or ""
            except Exception:
                txt = ""
            if not txt.strip():
                paginas_sin_texto += 1
            textos_pagina.append(txt)

    texto_completo = "\n\f\n".join(textos_pagina)
    texto_completo = limpiar_texto_ocr_basico(texto_completo)

    ratio_vacio = (paginas_sin_texto / n_paginas) if n_paginas else 1.0
    if ratio_vacio > 0.6:
        calidad = "OCR_DEGRADADO"  # probablemente escaneado sin capa de texto
    elif ratio_vacio > 0.15:
        calidad = "MEDIA"
    else:
        calidad = "ALTA"

    fragmentos: List[FragmentoPDF] = []
    orden = 0
    for pagina_idx, txt in enumerate(textos_pagina, start=1):
        txt = limpiar_texto_ocr_basico(txt)
        for chunk in chunk_text(txt, FRAGMENTO_CHARS):
            fragmentos.append(FragmentoPDF(pagina=pagina_idx, orden=orden, contenido=chunk))
            orden += 1

    return ResultadoPDF(
        archivo=path.name,
        paginas=n_paginas,
        texto_completo=texto_completo[:MAX_TEXTO_COMPLETO_CHARS],
        calidad_extraccion=calidad,
        fragmentos=fragmentos,
    )
