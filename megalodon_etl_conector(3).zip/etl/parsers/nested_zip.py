"""etl/parsers/nested_zip.py — extrae zips anidados (ej. FORMULARIOS.zip) a la
carpeta de trabajo para que el pipeline reclasifique su contenido."""
from __future__ import annotations
import zipfile
from pathlib import Path
from typing import List


def extraer_zip(path: Path, destino_dir: Path) -> List[Path]:
    destino_dir = destino_dir / path.stem
    destino_dir.mkdir(parents=True, exist_ok=True)
    extraidos: List[Path] = []
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            try:
                zf.extract(info, destino_dir)
                extraidos.append(destino_dir / info.filename)
            except Exception:
                continue
    return extraidos
