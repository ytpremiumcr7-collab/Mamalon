"""
etl/parsers/catalogos_pdf_nativo.py

Extrae catálogos de costos directamente del PDF nativo usando `pdftotext`
(poppler-utils) con patrones de regex afinados por familia editorial
(SICT, CMIC, CFE, CONAGUA, CDMX, materiales, salarios, maquinaria, índices
CEICO, factores de indirecto, paramétricos).

Origen: portado y adaptado de un ETL de referencia que el usuario aportó
(megalodon_etl_cmic_2_.py). Validado en este entorno contra el PDF real
TCD_Cons-2026.pdf: extrae filas LINEA/CÓDIGO/DESCRIPCIÓN/UNIDAD/COSTO
limpias y correctas directamente del PDF, SIN el ruido de marca de agua
que sí aparece en los .txt pre-extraídos de los catálogos CMIC. Por eso
este extractor se prioriza sobre el genérico `referencias_pdf` cuando el
nombre de archivo coincide con un patrón conocido (ver FUENTES_CONFIG).

Diferencia clave con el ETL de referencia: aquí NO se escribe a una base
de datos propia (`costos.*`); se devuelven dataclasses puras que
`etl/pipeline.py` carga en el esquema `megalodon` real (el único que
acepta `piedra_angular_megalodon.py`), vía `catalogos_fuente`,
`catalogo_insumos`, `apu_conceptos`, `apu_concepto_insumos`,
`maquinaria_catalogo`, `mano_obra_salarios`, `indices_precios_materiales`,
`factores_indirectos`, `costos_parametricos_obra` y `rendimientos_mano_obra`.
"""
from __future__ import annotations
import re
import subprocess
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional

# ─────────────────────────────────────────────────────────────────────────
# Utilidades de extracción PDF (poppler-utils, ya validado disponible)
# ─────────────────────────────────────────────────────────────────────────

def _pdftotext(ruta: Path, primera: int = 1, ultima: int = 9999, layout: bool = False) -> str:
    cmd = ["pdftotext"]
    if layout:
        cmd.append("-layout")
    cmd += ["-f", str(primera), "-l", str(ultima), str(ruta), "-"]
    try:
        resultado = subprocess.run(cmd, capture_output=True, timeout=300)
        return resultado.stdout.decode("utf-8", errors="replace")
    except Exception:
        return ""


def _ocr_pdf_escaneado(ruta: Path, dpi: int = 300, max_paginas: int = 30) -> str:
    """
    Respaldo para PDFs sin capa de texto (escaneados). Usa pdftoppm + tesseract.
    NOTA: en este entorno solo está disponible el paquete de idioma inglés de
    Tesseract (no hay red para instalar 'spa'); la calidad sobre texto en
    español es buena para nombres/montos pero puede perder acentos (é, í, ñ).
    Se marca confianza MEDIA/OCR para que el frontend lo distinga de la
    extracción nativa de texto.
    """
    import tempfile
    textos = []
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        try:
            subprocess.run(
                ["pdftoppm", "-png", "-r", str(dpi), "-f", "1", "-l", str(max_paginas), str(ruta), str(tmp_path / "pg")],
                capture_output=True, timeout=600,
            )
        except Exception:
            return ""
        for img in sorted(tmp_path.glob("pg-*.png")):
            try:
                out = subprocess.run(
                    ["tesseract", str(img), "stdout", "-l", "eng", "--psm", "6"],
                    capture_output=True, timeout=120,
                )
                textos.append(out.stdout.decode("utf-8", errors="replace"))
            except Exception:
                continue
    return "\n\f\n".join(textos)


_RE_VIGENCIA_GENERICA = [
    re.compile(r"Vigencia a partir de\s+(\w+)\s+de\s+(\d{4})", re.IGNORECASE),
    re.compile(r"[Vv]igente\s+(?:a partir\s+)?(?:de\s+|desde\s+)?(\w+)\s+de\s+(\d{4})"),
    re.compile(r"Ciudad de M[eé]xico,?\s+a\s+\d{1,2}\s+de\s+(\w+)\s+de\s+(\d{4})", re.IGNORECASE),
    re.compile(r"\b(ENERO|FEBRERO|MARZO|ABRIL|MAYO|JUNIO|JULIO|AGOSTO|SEPTIEMBRE|OCTUBRE|NOVIEMBRE|DICIEMBRE)\s+(?:DE\s+)?(20\d{2})\b"),
]


def _detectar_vigencia_real(texto: str) -> Optional["date"]:
    """Busca una fecha de vigencia/publicación real en el propio contenido del
    documento, en vez de depender de un valor estático adivinado en
    FUENTES_CONFIG (que de otro modo siempre marcaría '2026' por ser el año
    en que se armó el catálogo de patrones, sin relación con la vigencia real
    de cada archivo en particular)."""
    muestra = texto[:8000]  # la vigencia casi siempre aparece cerca del inicio
    for patron in _RE_VIGENCIA_GENERICA:
        m = patron.search(muestra)
        if m:
            mes_txt, anio_txt = m.groups()
            mes_num = _MESES_ES.get(mes_txt.upper())
            if mes_num:
                try:
                    return date(int(anio_txt), mes_num, 1)
                except ValueError:
                    continue
    return None


def _obtener_texto(ruta: Path, cfg: Dict[str, Any], layout: bool = False) -> tuple[str, str]:
    """Devuelve (texto, calidad). calidad in {'NATIVO','OCR_EN','DIRECTO'}.
    Como efecto colateral, intenta fijar cfg['_vigencia_real'] con una fecha
    encontrada en el propio texto (ver _detectar_vigencia_real)."""
    import os
    sufijo = ruta.suffix.lower()
    if sufijo in (".md", ".txt"):
        texto = ruta.read_text(encoding="utf-8", errors="replace")
        vig = _detectar_vigencia_real(texto)
        if vig:
            cfg["_vigencia_real"] = vig
        return texto, "DIRECTO"
    texto = _pdftotext(ruta, layout=layout)
    if len(texto.strip()) >= 80:
        vig = _detectar_vigencia_real(texto)
        if vig:
            cfg["_vigencia_real"] = vig
        return texto, "NATIVO"
    if os.environ.get("ETL_SKIP_OCR", "false").lower() == "true":
        return "", "OCR_OMITIDO"
    # probablemente escaneado: respaldo con OCR (inglés, ver nota en _ocr_pdf_escaneado)
    texto_ocr = _ocr_pdf_escaneado(ruta)
    vig = _detectar_vigencia_real(texto_ocr)
    if vig:
        cfg["_vigencia_real"] = vig
    return texto_ocr, "OCR_EN"


def _num_paginas(ruta: Path) -> int:
    try:
        out = subprocess.run(["pdfinfo", str(ruta)], capture_output=True, timeout=30).stdout.decode("utf-8", errors="replace")
        m = re.search(r"Pages:\s+(\d+)", out)
        return int(m.group(1)) if m else 0
    except Exception:
        return 0


def _limpiar_precio(raw: str) -> Optional[float]:
    if not raw:
        return None
    raw = raw.replace("$", "").replace(",", "").strip()
    try:
        return float(raw)
    except ValueError:
        return None


# ─────────────────────────────────────────────────────────────────────────
# Dataclasses de staging (1:1 con lo que pipeline.py carga al esquema real)
# ─────────────────────────────────────────────────────────────────────────

@dataclass
class RegistroConceptoAPU:
    clave: str
    descripcion: str
    unidad: str
    costo_directo: float
    alcances: str = ""
    linea_num: Optional[int] = None
    insumos: List[Dict[str, Any]] = field(default_factory=list)

@dataclass
class RegistroMaquinaria:
    clave: str
    descripcion: str
    costo_horario: float
    tipo: str = ""
    marca: str = ""
    hp: Optional[float] = None

@dataclass
class RegistroMaterialSimple:
    clave: str
    descripcion: str
    unidad: str
    precio: float
    familia: str = ""
    marca: str = ""
    zona: str = ""
    tipo_recurso: str = "material"

@dataclass
class RegistroSalario:
    categoria: str
    salario_base: float
    factor_imss: Optional[float] = None
    factor_imss_total: Optional[float] = None
    salario_real: Optional[float] = None

@dataclass
class RegistroParametrico:
    tipo_obra: str
    descripcion: str
    unidad: str
    costo: float
    costo_min: Optional[float] = None
    costo_max: Optional[float] = None

@dataclass
class RegistroCostoM2:
    tipo_espacio: str
    precio_m2: float
    uso: str = ""
    categoria: str = ""
    historico_periodos: Dict[str, float] = field(default_factory=dict)  # {'ene-25': 10574, ..., 'ene-26': 11320}
    variacion_pct_periodo: Optional[float] = None

@dataclass
class RegistroIndice:
    insumo: str
    variacion_pct: float
    periodo_inicio: date
    periodo_fin: date
    familia: str = ""

@dataclass
class RegistroFactor:
    convocante: str
    factor_indirecto: float
    mes_anio: date
    factor_utilidad: Optional[float] = None
    tipo_obra: str = "GENERAL"

@dataclass
class RegistroRendimiento:
    actividad: str
    unidad_trabajo: str
    rendimiento_minimo: float
    rendimiento_medio: Optional[float] = None
    rendimiento_maximo: Optional[float] = None


@dataclass
class ResultadoCatalogoPDF:
    archivo: str
    tipo_registro: str          # nombre del dataclass contenido en `registros`
    registros: List[Any] = field(default_factory=list)
    calidad: str = "NATIVO"
    vigencia_real: Optional["date"] = None


# ─────────────────────────────────────────────────────────────────────────
# Catálogo de fuentes conocidas (portado de FUENTES_CONFIG, adaptado a los
# nombres de columna del esquema `megalodon`: fuente/categoria_sector/
# vigencia_desde/codigo_fuente/tipo_catalogo)
# ─────────────────────────────────────────────────────────────────────────

FUENTES_CONFIG: List[Dict[str, Any]] = [
    {"patron": "TCD_Cons-2026", "codigo_fuente": "SICT-TCD-CARRETERAS-2026",
     "nombre_catalogo": "Tabulador a Costo Directo para Infraestructura Carretera 2026",
     "fuente": "SICT", "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "CARRETERAS",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_tcd"},
    {"patron": "TCParametricos_2026", "codigo_fuente": "SICT-PARAMETRICOS-2026",
     "nombre_catalogo": "Tabulador de Costos Paramétricos para Infraestructura Carretera 2026",
     "fuente": "SICT", "tipo_catalogo": "PARAMETRICO", "categoria_sector": "CARRETERAS",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_parametricos_general"},
    {"patron": "TServicio-2026", "codigo_fuente": "SICT-SERVICIOS-2026",
     "nombre_catalogo": "Tabulador a Costo Directo de Servicios Relacionados con Obra Pública 2026",
     "fuente": "SICT", "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "SERVICIOS",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_tcd"},
    {"patron": "101_terracerias", "codigo_fuente": "SICT-101-TERRACERIAS",
     "nombre_catalogo": "Terracerías – SICT", "fuente": "SICT", "tipo_catalogo": "PRECIOS_UNITARIOS",
     "categoria_sector": "TERRACERIAS", "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_tcd"},
    {"patron": "102_estructuras", "codigo_fuente": "SICT-102-ESTRUCTURAS",
     "nombre_catalogo": "Estructuras – SICT", "fuente": "SICT", "tipo_catalogo": "PRECIOS_UNITARIOS",
     "categoria_sector": "ESTRUCTURAS", "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_tcd"},
    {"patron": r"^\d{3}_", "codigo_fn": lambda n: f"SICT-{n.split('_')[0]}-{n.split('_')[1].upper()[:15]}",
     "nombre_fn": lambda n: f"SICT Sección {n.replace('_', ' ').replace('.pdf', '')}",
     "fuente": "SICT", "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "CARRETERAS",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_tcd"},
    {"patron": "Catalogo-de-Costos-Directos-de-Carreteras-2026", "codigo_fuente": "CMIC-CARRETERAS-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Carreteras 2026", "fuente": "CMIC",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "CARRETERAS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_catalogo"},
    {"patron": "Catalogo-de-costos-directos-de-Vivienda-2026", "codigo_fuente": "CMIC-VIVIENDA-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Vivienda 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "VIVIENDA",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Catalogo-de-costos-directos-del-Sector-Salud-2026", "codigo_fuente": "CMIC-SALUD-2026",
     "nombre_catalogo": "Catálogo de Costos Directos del Sector Salud 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "SALUD",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Catalogo-de-costos-directos-de-Infraestructura-Educativa-2026", "codigo_fuente": "CMIC-EDUCATIVA-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Infraestructura Educativa 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "EDUCATIVA",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Catalogo-de-costos-directos-de-Cimentaciones-Profundas-2026", "codigo_fuente": "CMIC-CIMENTACIONES-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Cimentaciones Profundas 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "CIMENTACIONES_PROFUNDAS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Catalogo-de-costos-directos-de-perforacion-de-pozos-para-agua-2026", "codigo_fuente": "CMIC-POZOS-AGUA-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Perforación de Pozos para Agua 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "POZOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Rehabilitacion-Pozos-2026", "codigo_fuente": "CMIC-REHABILITACION-POZOS-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Rehabilitación de Pozos 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "POZOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Ecotecnologias-2026", "codigo_fuente": "CMIC-ECOTECNOLOGIAS-2026",
     "nombre_catalogo": "Catálogo de Costos Directos de Ecotecnologías 2026 (Estudio de Mercado)", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "ECOTECNOLOGIAS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_estudio_mercado"},
    {"patron": "Catalogo-de-costos-directos-para-utilizacion-de-materiales-reciclados-2026", "codigo_fuente": "CMIC-RECICLADOS-2026",
     "nombre_catalogo": "Catálogo de Costos Directos para Utilización de Materiales Reciclados 2026", "fuente": "CMIC",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "MATERIALES_RECICLADOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_catalogo"},
    {"patron": "Catalogo-de-costos-Horario-de-Maquinari", "codigo_fuente": "CMIC-MAQUINARIA-2026",
     "nombre_catalogo": "Catálogo de Costos Horarios de Maquinaria 2026", "fuente": "CMIC",
     "tipo_catalogo": "MAQUINARIA", "categoria_sector": "MAQUINARIA_GENERAL",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_maquinaria"},
    {"patron": r"TCMaquinaria_2026", "codigo_fuente": "SICT-MAQUINARIA-2026",
     "nombre_catalogo": "Tabulador de Costos Horarios de Maquinaria SICT 2026", "fuente": "SICT",
     "tipo_catalogo": "MAQUINARIA", "categoria_sector": "MAQUINARIA_GENERAL",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_sict_maquinaria"},
    {"patron": "Libro-de-Costos-Ene-2026", "codigo_fuente": "CMIC-LIBRO-COSTOS-2026",
     "nombre_catalogo": "Libro de Costos CMIC – Enero 2026", "fuente": "CMIC",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cmic_catalogo"},
    {"patron": "CATALOGO-DE-PRECIOS-UNITARIOS-CFE-2026", "codigo_fuente": "CFE-PU-2026",
     "nombre_catalogo": "Catálogo de Precios Unitarios CFE 2026", "fuente": "CFE",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "ELECTRICO",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_cfe"},
    {"patron": "CAT_LOGO_POR_GERENCIA_SGIH_2026", "codigo_fuente": "CONAGUA-SGIH-2026",
     "nombre_catalogo": "Catálogo por Gerencia SGIH CONAGUA 2026", "fuente": "CONAGUA",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "HIDRAULICA",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cfe"},
    {"patron": "tabulador.*precios.*unitarios.*ciudad.*mexico.*abril", "codigo_fuente": "CDMX-TGPU-ABR-2026",
     "nombre_catalogo": "Tabulador General de PU CDMX – Abril 2026", "fuente": "CDMX-SOBSE",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 4, 1), "extractor": "extractor_cdmx"},
    {"patron": "tabulador.*precios.*unitarios.*ciudad.*mexico.*marzo", "codigo_fuente": "CDMX-TGPU-MAR-2026",
     "nombre_catalogo": "Tabulador General de PU CDMX – Marzo 2026", "fuente": "CDMX-SOBSE",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 3, 1), "extractor": "extractor_cdmx"},
    {"patron": "tabulador.*precios.*unitarios.*ciudad.*mexico.*febrero", "codigo_fuente": "CDMX-TGPU-FEB-2026",
     "nombre_catalogo": "Tabulador General de PU CDMX – Febrero 2026", "fuente": "CDMX-SOBSE",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 2, 1), "extractor": "extractor_cdmx"},
    {"patron": "tabulador.*precios.*unitarios.*ciudad.*mexico.*enero", "codigo_fuente": "CDMX-TGPU-ENE-2026",
     "nombre_catalogo": "Tabulador General de PU CDMX – Enero 2026", "fuente": "CDMX-SOBSE",
     "tipo_catalogo": "PRECIOS_UNITARIOS", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_cdmx"},
    {"patron": "PARAMETRICOS-GUAD", "codigo_fuente": "GDLJ-PARAMETRICOS-ENE-2026",
     "nombre_catalogo": "Paramétricos Guadalajara – Enero 2026", "fuente": "GDLJ",
     "tipo_catalogo": "PARAMETRICO", "categoria_sector": "GENERAL",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_parametricos_general"},
    {"patron": "Costos-m2-Construccion", "codigo_fuente": "CEICO-M2-ENE26",
     "nombre_catalogo": "Costos m² de Construcción (CEICO)", "fuente": "CMIC-CEICO",
     "tipo_catalogo": "PARAMETRICO", "categoria_sector": "COSTO_M2",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_costos_m2"},
    {"patron": "catalogo-materiales-de-construccion-ligera", "codigo_fuente": "CMIC-MAT-LIGERA-2026",
     "nombre_catalogo": "Catálogo de Materiales de Construcción Ligera 2026", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "CONSTRUCCION_LIGERA",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_materiales_general"},
    {"patron": "Catalogo-Aceromex", "codigo_fuente": "ACEROMEX-2026",
     "nombre_catalogo": "Catálogo Aceromex 2026", "fuente": "ACEROMEX",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "ACERO",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_materiales_general"},
    {"patron": "Madera-para-Cimbra", "codigo_fuente": "CMIC-MADERA-CIMBRA-2026",
     "nombre_catalogo": "Catálogo de Madera para Cimbra 2026", "fuente": "CMIC",
     "tipo_catalogo": "MATERIALES", "categoria_sector": "MADERA",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_materiales_general"},
    {"patron": "Anexo 1 Tabulador de Salarios", "codigo_fuente": "SICT-SAL-ESTUDIOS-2026",
     "nombre_catalogo": "Tabulador de Salarios – Personal de Estudios y Proyectos 2026", "fuente": "SICT",
     "tipo_catalogo": "SALARIOS", "categoria_sector": "ESTUDIOS", "tipo_personal": "ESTUDIOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_salarios_profesionales"},
    {"patron": "anexo-2-tabulador-de-salarios", "codigo_fuente": "SICT-SAL-SUPERVISION-2026",
     "nombre_catalogo": "Tabulador de Salarios – Personal de Supervisión 2026", "fuente": "SICT",
     "tipo_catalogo": "SALARIOS", "categoria_sector": "SUPERVISION", "tipo_personal": "SUPERVISION",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_salarios_profesionales"},    {"patron": "Tabulador-Servicios-Profesionales-2026", "codigo_fuente": "SICT-SAL-PROFESIONALES-2026",
     "nombre_catalogo": "Tabulador de Servicios Profesionales 2026", "fuente": "SICT",
     "tipo_catalogo": "SALARIOS", "categoria_sector": "PROFESIONALES", "tipo_personal": "PROFESIONALES",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_salarios_profesionales"},
    {"patron": "TABULADORES_DE_RENDIMIENTOS_MINIMOS", "codigo_fuente": "CMIC-RENDIMIENTOS-2019",
     "nombre_catalogo": "Tabuladores de Rendimientos Mínimos de Mano de Obra y Maquinaria 2019", "fuente": "CMIC",
     "tipo_catalogo": "INDICES", "categoria_sector": "RENDIMIENTOS",
     "vigencia_desde": date(2019, 9, 25), "extractor": "extractor_rendimientos", "es_historico": True},
    {"patron": "Anexo 3 Factor de Indirecto Integrado", "codigo_fuente": "CDMX-FACTOR-INDIRECTO-2026",
     "nombre_catalogo": "Factor de Indirecto Integrado CDMX 2026", "fuente": "CDMX-SOBSE",
     "tipo_catalogo": "INDIRECTOS", "categoria_sector": "FACTOR_INDIRECTO",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_factores_indirectos"},
    {"patron": "CEICO_Informe_Enero_2026_Variacion_precio_materiales", "codigo_fuente": "CEICO-VAR-ENE-2026",
     "nombre_catalogo": "CEICO – Variación de Precio de Materiales Enero 2026", "fuente": "CMIC-CEICO",
     "tipo_catalogo": "INDICES", "categoria_sector": "VARIACION_PRECIOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_ceico"},
    {"patron": "CEICO_Informe_Junio_2025", "codigo_fuente": "CEICO-VAR-JUN-2025",
     "nombre_catalogo": "CEICO – Variación de Precio de Materiales Junio 2025", "fuente": "CMIC-CEICO",
     "tipo_catalogo": "INDICES", "categoria_sector": "VARIACION_PRECIOS",
     "vigencia_desde": date(2025, 6, 1), "extractor": "extractor_ceico", "es_historico": True},
    {"patron": "AJUSTE-DE-COSTOS-CASO-PRACTICO", "codigo_fuente": "CEICO-AJUSTE-COSTOS-2026",
     "nombre_catalogo": "Ajuste de Costos – Caso Práctico (CEICO)", "fuente": "CMIC-CEICO",
     "tipo_catalogo": "INDICES", "categoria_sector": "AJUSTE_COSTOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_ceico"},
    {"patron": "Rendimientos-Bimsa-Edificacion", "codigo_fuente": "BIMSA-RENDIMIENTOS-2026",
     "nombre_catalogo": "Rendimientos BIMSA – Edificación", "fuente": "BIMSA",
     "tipo_catalogo": "INDICES", "categoria_sector": "RENDIMIENTOS",
     "vigencia_desde": date(2026, 1, 1), "extractor": "extractor_rendimientos"},
]


_RE_CODEPOINT_MANGLADO = re.compile(r"#U([0-9A-Fa-f]{4,6})")


def _reparar_nombre_mangled(s: str) -> str:
    """Repara el artefacto de codificación '#U0301' -> 'COMBINING ACUTE ACCENT'
    que aparece en ~6 archivos del corpus (probablemente de cómo el ZIP
    original codificó nombres con acentos). Sin esto, 'Cata#U0301logo' nunca
    coincide con el patrón 'Catalogo' y el archivo cae al extractor genérico."""
    def _decode(m):
        try:
            return chr(int(m.group(1), 16))
        except ValueError:
            return m.group(0)
    return _RE_CODEPOINT_MANGLADO.sub(_decode, s)


def _sin_acentos(s: str) -> str:
    import unicodedata
    s = _reparar_nombre_mangled(s)
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c))


def fuente_para_archivo(nombre: str) -> Optional[Dict[str, Any]]:
    nombre_normalizado = _sin_acentos(nombre)
    for cfg in FUENTES_CONFIG:
        patron_normalizado = _sin_acentos(cfg["patron"])
        if re.search(patron_normalizado, nombre_normalizado, re.IGNORECASE):
            cfg = dict(cfg)
            if "codigo_fn" in cfg:
                cfg["codigo_fuente"] = cfg["codigo_fn"](nombre)
            if "nombre_fn" in cfg:
                cfg["nombre_catalogo"] = cfg["nombre_fn"](nombre)
            return cfg
    return None


# ─────────────────────────────────────────────────────────────────────────
# Patrones de extracción por familia
# ─────────────────────────────────────────────────────────────────────────

_RE_SICT_FILA = re.compile(
    r"^\s*(?:(\d+)\s+)?([A-Z]{0,3}[\d\.]{3,}[A-Z]?)\s+(.+?)\s+([\w²³/]+)\s+\$([\d,]+\.\d{2})", re.MULTILINE,
)
_RE_APU_INSUMO = re.compile(
    r"^([A-Z0-9][A-Z0-9\-]{2,40})\s{2,}(.{5,100}?)\s{2,}(\S+)\s+([\d\.]+)\s+\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})",
    re.MULTILINE,
)
_RE_MAQUINARIA = re.compile(
    r"^((?:CMIC-CH-\d+|GIC-CH-\d+|\d{4}-\d{2}-\d{2})[A-Z0-9\-]*)\s{2,}(.{10,120}?)\s{2,}hora\s+\$([\d,]+\.\d{2})",
    re.MULTILINE,
)
_RE_MAQUINARIA_ALT = re.compile(r"^(.{15,120}?)\s{2,}hora\s+\$([\d,]+\.\d{2})", re.MULTILINE)
_RE_MATERIAL_SIMPLE = re.compile(
    r"^(.{10,120}?)\s{2,}([A-Za-záéíóúüñ²³/\-\.]{1,20})\s+\$([\d,]+\.\d{2})\s*$", re.MULTILINE,
)
_RE_CFE = re.compile(
    r"^([A-Z]{2,4}\d[A-Z]{2,3}\d{3,6}[A-Z]?)\s{2,}(.{5,200}?)\s{2,}([A-Z]{1,4})\s+([\d,]+\.\d{2})", re.MULTILINE,
)
_RE_CDMX_LAYOUT = re.compile(
    r"^([A-Z]{1,5}\d{1,5}[A-Z]{0,5})\s{3,}(.{5,200}?)\s{3,}([A-Za-záéíóúüñ²³/\-\.]{1,25})\s+([\d,]+\.\d{2})\s*$",
    re.MULTILINE,
)
_RE_SALARIO = re.compile(
    r"^(.{10,80}?)\s{2,}\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})\s+([\d\.]+)\s+([\d\.]+)\s+([\d\.]+)\s+\$([\d,]+\.\d{2})",
    re.MULTILINE,
)
_RE_SALARIO_SIMPLE = re.compile(r"^(.{8,80}?)\s{2,}\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})", re.MULTILINE)
_RE_CEICO = re.compile(r"^(.{5,100}?):\s+([\-\d]+\.\d+)%", re.MULTILINE)
_RE_CEICO_TABLA = re.compile(r"^\s{0,30}(.{4,60}?)\s{3,}([\-\d]+\.\d{2})%\s+[\-\d]+\.\d{2}%", re.MULTILINE)
_RE_PARAMETRICO = re.compile(
    r"^(.{10,120}?)\s{2,}(km|m²|m³|m|ml|cama|aula|pza|ha|lt|kg)\s+\$([\d,]+\.\d{2})", re.MULTILINE | re.IGNORECASE,
)
_RE_COSTO_M2 = re.compile(r"^(.{8,100}?)\s{2,}\$([\d,]+\.\d{2})\s*/?\s*m²", re.MULTILINE | re.IGNORECASE)
_RE_INDIRECTO = re.compile(r"INDIRECTO INTEGRADO PARA ESTE MES ES DEL\s+([\d\.]+)\s*%", re.IGNORECASE)
_RE_RENDIMIENTO = re.compile(
    r"^(.{10,100}?)\s{2,}([a-záéíóúüñ²³/\-\.]+)\s{2,}([\d\.]+)\s+([\d\.]+)(?:\s+([\d\.]+))?", re.MULTILINE,
)
_MESES_ES = {"ENERO": 1, "FEBRERO": 2, "MARZO": 3, "ABRIL": 4, "MAYO": 5, "JUNIO": 6,
             "JULIO": 7, "AGOSTO": 8, "SEPTIEMBRE": 9, "OCTUBRE": 10, "NOVIEMBRE": 11, "DICIEMBRE": 12}


def _extraer_insumos_bloque(bloque: str) -> List[Dict[str, Any]]:
    insumos = []
    tipo_actual = "material"
    for linea in bloque.split("\n"):
        linea = linea.strip()
        if re.match(r"^(MATERIALES|MATERIAL)", linea, re.I):
            tipo_actual = "material"
        elif re.match(r"^(MANO DE OBRA|MANO_OBRA)", linea, re.I):
            tipo_actual = "mano_obra"
        elif re.match(r"^(MAQUINARIA|EQUIPO|BASICOS)", linea, re.I):
            tipo_actual = "equipo"
        m = _RE_APU_INSUMO.match(linea)
        if m:
            clave, desc, unidad, cant_raw, pu_raw, _total_raw = m.groups()
            insumos.append({
                "tipo": tipo_actual, "clave": clave, "descripcion": desc.strip(),
                "unidad": unidad, "cantidad": float(cant_raw or 0),
                "precio_unitario": _limpiar_precio(pu_raw) or 0.0,
            })
    return insumos


# ─────────────────────────────────────────────────────────────────────────
# Extractores por familia (1:1 con el ETL de referencia del usuario)
# ─────────────────────────────────────────────────────────────────────────

def extractor_sict_tcd(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroConceptoAPU]:
    registros: List[RegistroConceptoAPU] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)
    seen: set = set()
    for m in _RE_SICT_FILA.finditer(texto):
        linea, codigo, desc, unidad, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        codigo = codigo.strip()
        if precio and precio > 0 and len(desc.strip()) > 4 and codigo not in seen:
            seen.add(codigo)
            registros.append(RegistroConceptoAPU(
                clave=codigo, descripcion=desc.strip()[:300], unidad=unidad.strip(),
                costo_directo=precio, linea_num=int(linea) if linea else None,
            ))
    return registros


def extractor_cmic_catalogo(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroConceptoAPU]:
    registros: List[RegistroConceptoAPU] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    re_concepto = re.compile(
        r"^([A-Z0-9][A-Z0-9\-]{2,50})\s{2,}(.{5,150}?)\s{2,}([a-zA-Záéíóúüñ²³/\-\.]{1,25})\s+\n?.*?"
        r"(?:COSTO DIRECTO|Importe)\s*:\s*\$([\d,]+\.\d{2})", re.MULTILINE | re.DOTALL,
    )
    re_fila_simple = re.compile(
        r"^((?:[A-Z]{1,5}-[A-Z0-9]+|CMIC[A-Z0-9\-]+|MAT-\d+|MO-\d+|\d{4}-\d{2}-\d{2})[A-Z0-9\-\.]*)\s{2,}"
        r"(.{5,150}?)\s{2,}([a-zA-Záéíóúüñ²³/\-\.]{1,25})\s+\$([\d,]+\.\d{2})", re.MULTILINE,
    )
    seen: set = set()
    for pagina in texto.split("\f"):
        for m in re_concepto.finditer(pagina):
            clave, desc, unidad, precio_raw = m.groups()
            precio = _limpiar_precio(precio_raw)
            if not precio or precio <= 0:
                continue
            k = (clave.strip(), precio)
            if k in seen:
                continue
            seen.add(k)
            registros.append(RegistroConceptoAPU(
                clave=clave.strip(), descripcion=desc.strip()[:300], unidad=unidad.strip(),
                costo_directo=precio, insumos=_extraer_insumos_bloque(m.group(0)),
            ))
        for m in re_fila_simple.finditer(pagina):
            clave, desc, unidad, precio_raw = m.groups()
            precio = _limpiar_precio(precio_raw)
            if not precio or precio <= 0 or len(desc.strip()) < 5:
                continue
            k = (clave.strip(), precio)
            if k in seen:
                continue
            seen.add(k)
            registros.append(RegistroConceptoAPU(
                clave=clave.strip(), descripcion=desc.strip()[:300], unidad=unidad.strip(), costo_directo=precio,
            ))
    if len(registros) < 5:
        # Menos de 5 coincidencias casi siempre significa que el patrón de
        # "concepto APU con desglose" no aplica a este archivo (es un caso
        # real observado: un catálogo dio 1 coincidencia espuria y se
        # reportaba como "PROCESADO" exitoso, ocultando que en realidad no
        # se extrajo nada útil). Se intenta el patrón de "estudio de
        # mercado" (precios de materiales/mano de obra por zona), que cubre
        # la mayoría de catálogos CMIC con OCR degradado.
        alterno = extractor_cmic_estudio_mercado(ruta, cfg)
        if len(alterno) > len(registros):
            return alterno
    return registros


def extractor_sict_maquinaria(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroMaquinaria]:
    """
    Formato real validado en TCMaquinaria_2026.pdf (con -layout):
    SERIE   DESCRIPCIÓN (puede envolver varias líneas)   $VA_USD   $VA_MXN   $Activo   $Espera   $Reserva
    El "Costo Horario" relevante para presupuestar es la columna "Activo".
    """
    registros: List[RegistroMaquinaria] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)
    patron = re.compile(
        r"^\s*(\d{3,6})\s+(.{8,250}?)\s+\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})\s+\$([\d,]+\.\d{2})\s*$",
        re.MULTILINE,
    )
    seen: set = set()
    for m in patron.finditer(texto):
        serie, desc, _va_usd, _va_mxn, costo_activo, _costo_espera, _costo_reserva = m.groups()
        if serie in seen or len(desc.strip()) < 5:
            continue
        precio = _limpiar_precio(costo_activo)
        if not precio or precio <= 0:
            continue
        seen.add(serie)
        hp_match = re.search(r"(\d+(?:\.\d+)?)\s*HP", desc, re.IGNORECASE)
        marcas = ["Caterpillar", "Komatsu", "John Deere", "Case", "Champion", "Volvo", "Hitachi", "Liebherr",
                  "Ford", "Chevrolet", "Toyota", "Sokkia", "Leica", "GeoMax", "Stihl", "Echo", "Milwaukee"]
        marca = next((mk for mk in marcas if mk.lower() in desc.lower()), "")
        registros.append(RegistroMaquinaria(
            clave=serie, descripcion=re.sub(r"\s+", " ", desc.strip())[:300], costo_horario=precio,
            marca=marca, hp=float(hp_match.group(1)) if hp_match else None,
        ))
    return registros


def extractor_cmic_maquinaria(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroMaquinaria]:
    registros: List[RegistroMaquinaria] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    seen: set = set()
    for m in _RE_MAQUINARIA.finditer(texto):
        clave, desc, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0 or clave in seen:
            continue
        seen.add(clave)
        hp_match = re.search(r"(\d+(?:\.\d+)?)\s*[Hh][\.Pp]", desc)
        marcas = ["Caterpillar", "Komatsu", "John Deere", "Case", "Champion", "Volvo", "Hitachi", "Liebherr"]
        marca = next((mk for mk in marcas if mk.lower() in desc.lower()), "")
        registros.append(RegistroMaquinaria(
            clave=clave, descripcion=desc.strip()[:300], costo_horario=precio,
            marca=marca, hp=float(hp_match.group(1)) if hp_match else None,
        ))
    for m in _RE_MAQUINARIA_ALT.finditer(texto):
        desc, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0:
            continue
        clave_gen = f"MAQ-{abs(hash(desc.strip()[:40])) % 100000:05d}"
        if clave_gen in seen:
            continue
        seen.add(clave_gen)
        registros.append(RegistroMaquinaria(clave=clave_gen, descripcion=desc.strip()[:300], costo_horario=precio))
    return registros


def extractor_cfe(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroConceptoAPU]:
    registros: List[RegistroConceptoAPU] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    seen: set = set()
    for m in _RE_CFE.finditer(texto):
        clave, desc, unidad, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0 or clave in seen:
            continue
        seen.add(clave)
        registros.append(RegistroConceptoAPU(clave=clave, descripcion=desc.strip()[:300], unidad=unidad, costo_directo=precio))
    return registros


def extractor_cdmx(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroConceptoAPU]:
    registros: List[RegistroConceptoAPU] = []
    seen: set = set()
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)
    for m in _RE_CDMX_LAYOUT.finditer(texto):
        clave, desc, unidad, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0 or len(desc.strip()) < 4 or clave in seen:
            continue
        seen.add(clave)
        registros.append(RegistroConceptoAPU(clave=clave.strip(), descripcion=desc.strip()[:300], unidad=unidad.strip(), costo_directo=precio))
    return registros


_RE_PARTE_ESTUDIO = re.compile(
    r"Parte\s+\d+\s*[\u2013\-]\s*Estudio de mercado del costo de (los materiales|la mano de obra)",
    re.IGNORECASE,
)
_RE_REGION_ESTUDIO = re.compile(r"^\s{15,}([A-Za-zÁÉÍÓÚÑáéíóúñ][A-Za-zÁÉÍÓÚÑáéíóúñ ]{3,40})$", re.MULTILINE)
_RE_ZONA_ESTUDIO = re.compile(r"Zona\s+(Urbana|Rural)", re.IGNORECASE)
_RE_FILA_ESTUDIO_MERCADO = re.compile(
    r"^\s*(\d{1,3})\s+(.+?)\s+(ton|m2|m3|m\u00b2|m\u00b3|ml|pza|lote|jornada|jornal|hora|millar|viaje|km|kg|lt|hr|t|l)\b[^\n$]{0,25}\$([\d,]+\.\d{2})",
    re.MULTILINE | re.IGNORECASE,
)


def _limpiar_descripcion_estudio(desc: str) -> str:
    """Quita fragmentos residuales de la marca de agua diagonal (grupos cortos
    en MAYÚSCULAS al final, ej. 'Cemento gris   V O' -> 'Cemento gris')."""
    desc = re.sub(r"(\s+[A-Z]{1,4}\b){1,3}\s*$", "", desc)
    return re.sub(r"\s+", " ", desc).strip(" -")


def extractor_cmic_estudio_mercado(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroMaterialSimple]:
    """
    Formato real validado en los 6 catálogos CMIC con OCR degradado
    (Vivienda, Salud, Educativa, Cimentaciones Profundas, Pozos para Agua,
    Rehabilitación de Pozos, Ecotecnologías): el documento ENTERO es un
    'Estudio de mercado' de precios de materiales y mano de obra, repetido
    por región y por zona (Urbana/Rural) en bloques 'Parte N'. No es un
    catálogo de conceptos de obra con desglose APU — es directamente una
    tabla de precios de insumos por zona, que es justo lo que necesita el
    motor de costos para variar presupuestos por ubicación.

    Se valida exhaustivamente contra los 6 archivos reales (ver sesión de
    desarrollo): estructura idéntica en los 6, con número de fila, descripción,
    unidad (de una lista cerrada de unidades válidas) y precio en pesos.
    """
    registros: List[RegistroMaterialSimple] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)

    partes = list(_RE_PARTE_ESTUDIO.finditer(texto))
    if not partes:
        return registros

    seen: set = set()
    for idx, p in enumerate(partes):
        tipo_recurso = "material" if "materiales" in p.group(1).lower() else "mano_obra"
        inicio = p.end()
        fin = partes[idx + 1].start() if idx + 1 < len(partes) else len(texto)
        cabecera = texto[inicio:inicio + 600]
        region_m = _RE_REGION_ESTUDIO.search(cabecera)
        zona_m = _RE_ZONA_ESTUDIO.search(cabecera)
        region = region_m.group(1).strip() if region_m else "NACIONAL"
        zona_tipo = zona_m.group(1).upper() if zona_m else "URBANA"
        zona_completa = f"{region} - {zona_tipo}"

        bloque = texto[inicio:fin]
        for m in _RE_FILA_ESTUDIO_MERCADO.finditer(bloque):
            numero, desc_raw, unidad, precio_raw = m.groups()
            precio = _limpiar_precio(precio_raw)
            if not precio or precio <= 0 or precio > 50_000_000:
                continue
            desc = _limpiar_descripcion_estudio(desc_raw)
            if len(desc) < 3:
                continue
            dedupe_key = (numero, desc.lower()[:60], zona_completa)
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            prefijo = "MAT" if tipo_recurso == "material" else "MO"
            clave = f"{prefijo}-{numero}-{abs(hash(zona_completa)) % 10_000_000:07d}"
            registros.append(RegistroMaterialSimple(
                clave=clave, descripcion=desc[:300], unidad=unidad.lower(), precio=precio,
                familia=tipo_recurso.upper(), zona=zona_completa, tipo_recurso=tipo_recurso,
            ))
    return registros


def extractor_materiales_general(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroMaterialSimple]:
    registros: List[RegistroMaterialSimple] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    seen: set = set()
    nombre = ruta.name.lower()
    familia = "ACERO" if "acero" in nombre else "MADERA" if ("madera" in nombre or "cimbra" in nombre) else \
        "CONSTRUCCION_LIGERA" if "ligera" in nombre else "GENERAL"
    for m in _RE_MATERIAL_SIMPLE.finditer(texto):
        desc, unidad, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0 or len(desc.strip()) < 5:
            continue
        clave = f"MAT-{abs(hash(desc.strip()[:60])) % 1_000_000:06d}"
        if clave in seen:
            continue
        seen.add(clave)
        registros.append(RegistroMaterialSimple(clave=clave, descripcion=desc.strip()[:300], unidad=unidad.strip(), precio=precio, familia=familia))
    return registros


_RE_SALARIO_CATEGORIA_MONTO = re.compile(
    r"^[\|\s\-=•]*([A-Za-zÁÉÍÓÚÑáéíóúñ][A-Za-zÁÉÍÓÚÑáéíóúñ0-9 ,\.\"'“”]{4,90}?)\s*[\"'“”]?\s+\$([\d,]+\.\d{2})\b",
    re.MULTILINE,
)


def extractor_salarios_profesionales(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroSalario]:
    """
    Formato real validado (CDMX-SOBSE, Anexo 1 y Anexo 2 — tabulador de
    sueldos mensuales nominales por categoría): una categoría por línea
    seguida de un único monto en $, ej.:
        Gerente de Supervisión de obra grupo "A"   $77,166.00
    Se tolera ruido típico de OCR (comillas curvas mal codificadas, "=-",
    corchetes sueltos de pie de página) sin intentar repararlo carácter a
    carácter — eso se deja para revisión humana si la categoría queda con
    artefactos visibles.
    """
    registros: List[RegistroSalario] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    vistos: set = set()
    for m in _RE_SALARIO_CATEGORIA_MONTO.finditer(texto):
        categoria_raw, monto_raw = m.groups()
        categoria = re.sub(r"\s+", " ", categoria_raw).strip(" \"'“”-=|")
        if len(categoria) < 4 or re.search(r"^(PAG|PÁGINA|PAGINA|TOTAL|SUMA)\b", categoria, re.IGNORECASE):
            continue
        monto = _limpiar_precio(monto_raw)
        if not monto or monto <= 0 or categoria.lower() in vistos:
            continue
        vistos.add(categoria.lower())
        registros.append(RegistroSalario(categoria=categoria[:150], salario_base=monto))

    if not registros:  # formatos con columnas de factor IMSS explícitas
        for m in _RE_SALARIO.finditer(texto):
            cat, sal_b, _sal_c, firma, _factor_var, factor_total, sal_real = m.groups()
            sb = _limpiar_precio(sal_b)
            if not sb or sb <= 0:
                continue
            try:
                f_firma, f_total = float(firma), float(factor_total)
            except ValueError:
                f_firma, f_total = None, None
            registros.append(RegistroSalario(categoria=cat.strip()[:120], salario_base=sb, factor_imss=f_firma,
                                              factor_imss_total=f_total, salario_real=_limpiar_precio(sal_real)))
    return registros


def extractor_rendimientos(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroRendimiento]:
    registros: List[RegistroRendimiento] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    for m in _RE_RENDIMIENTO.finditer(texto):
        actividad, unidad, rmin_s, rmed_s, rmax_s = m.groups()
        try:
            rmin = float(rmin_s)
        except ValueError:
            continue
        if rmin <= 0 or rmin > 100_000:
            continue
        registros.append(RegistroRendimiento(
            actividad=actividad.strip()[:200], unidad_trabajo=unidad.strip(), rendimiento_minimo=rmin,
            rendimiento_medio=float(rmed_s) if rmed_s else None, rendimiento_maximo=float(rmax_s) if rmax_s else None,
        ))
    return registros


_RE_PARAMETRICO_CLAVE = re.compile(
    r"^([A-Z][A-Z0-9]{3,9})\s{3,}(.{10,250}?)\s{2,}(km|m²|m³|ml|pza|lote|aula|cama)\s+\$([\d,]+(?:\.\d{1,2})?)\s*$",
    re.MULTILINE,
)


def extractor_parametricos_general(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroParametrico]:
    registros: List[RegistroParametrico] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)

    def _clasificar(desc: str) -> str:
        d = desc.lower()
        return next((t for t, kw in [("CARRETERA", "carretera"), ("PUENTE", "puente"), ("VIVIENDA", "vivienda"),
                                      ("SALUD", "hospital"), ("EDUCATIVA", "escuel"), ("TUNEL", "tunel"),
                                      ("PRESA", "presa"), ("POZO", "pozo")] if kw in d), "GENERAL")

    seen: set = set()
    for m in _RE_PARAMETRICO_CLAVE.finditer(texto):
        clave, desc, unidad, precio_raw = m.groups()
        precio = _limpiar_precio(precio_raw)
        if not precio or precio <= 0 or clave in seen:
            continue
        seen.add(clave)
        registros.append(RegistroParametrico(tipo_obra=_clasificar(desc), descripcion=f"[{clave}] {desc.strip()}"[:300],
                                              unidad=unidad.strip(), costo=precio))
    if not registros:
        for m in _RE_PARAMETRICO.finditer(texto):
            desc, unidad, precio_raw = m.groups()
            precio = _limpiar_precio(precio_raw)
            if not precio or precio <= 0:
                continue
            registros.append(RegistroParametrico(tipo_obra=_clasificar(desc), descripcion=desc.strip()[:300],
                                                   unidad=unidad.strip(), costo=precio))
    return registros


_RE_COSTO_M2_FILA = re.compile(
    r"^(.{4,60}?)\s{2,}([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\-\d]+\.\d+)%\s*$", re.MULTILINE,
)
_RE_COSTO_M2_ENCABEZADO = re.compile(
    r"^\s*Tipo de Edificaci[oó]n.*?\n\s*(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+", re.IGNORECASE,
)


def extractor_costos_m2(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroCostoM2]:
    """
    Formato real validado (CMIC/CEICO 'Costos por m2 de construcción'):
      VIVIENDA UNIFAMILIAR                      <- encabezado de categoría (sin números)
      Interés Social   10,574 10,816 ... 11,320  7.1%   <- fila de detalle (5 periodos + variación)
    Se preserva el histórico de los 5 periodos (no solo el más reciente) porque
    alimenta directamente el módulo de Montecarlo histórico del usuario.
    """
    registros: List[RegistroCostoM2] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)

    etiquetas_periodo = ["p1", "p2", "p3", "p4", "p5"]
    m_enc = _RE_COSTO_M2_ENCABEZADO.search(texto)
    if m_enc:
        etiquetas_periodo = list(m_enc.groups())

    categoria_actual = ""
    for linea in texto.split("\n"):
        cruda = linea.strip()
        if not cruda:
            continue
        m = _RE_COSTO_M2_FILA.match(linea)
        if m:
            subtipo, v1, v2, v3, v4, v5, variacion = m.groups()
            valores = [_limpiar_precio(v) for v in (v1, v2, v3, v4, v5)]
            if any(v is None for v in valores):
                continue
            tipo_espacio = f"{categoria_actual} - {subtipo.strip()}" if categoria_actual else subtipo.strip()
            d = tipo_espacio.lower()
            uso = next((u for u, kw in [("HABITACIONAL", "vivienda"), ("INDUSTRIAL", "industrial"),
                                         ("SALUD", "hospital"), ("SALUD", "clinica"), ("EDUCATIVO", "escuel"),
                                         ("EDUCATIVO", "educac"), ("COMERCIAL", "oficin"), ("HOTEL", "hotel"),
                                         ("URBANIZACION", "calle"), ("URBANIZACION", "jardin")] if kw in d), "GENERAL")
            registros.append(RegistroCostoM2(
                tipo_espacio=tipo_espacio[:200], precio_m2=valores[-1], uso=uso, categoria=categoria_actual[:120],
                historico_periodos=dict(zip(etiquetas_periodo, valores)),
                variacion_pct_periodo=_limpiar_precio(variacion) if "-" not in variacion else -_limpiar_precio(variacion.lstrip("-")),
            ))
        elif re.match(r"^[A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑ \(\)/]{3,60}$", cruda) and not re.search(r"\d", cruda):
            categoria_actual = cruda
    return registros


def extractor_ceico(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroIndice]:
    registros: List[RegistroIndice] = []
    vigencia = cfg.get("vigencia_desde", date.today())
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=True)
    if ruta.suffix.lower() == ".pdf":
        # Limita a las primeras páginas (resumen narrativo): las páginas con
        # gráficas de barras producen texto de ejes/etiquetas verticales muy
        # ruidoso al extraerlo con pdftotext.
        texto_resumen, _ = _obtener_texto(ruta, cfg, layout=True)
        texto = "\n".join(texto_resumen.split("\f")[:3])
    periodo_match = re.search(
        r"(enero|febrero|marzo|junio|diciembre)\s+de\s+(20\d{2})\s+a\s+(enero|febrero|marzo|junio|diciembre)\s+de\s+(20\d{2})",
        texto, re.IGNORECASE,
    )
    p_inicio = p_fin = vigencia
    if periodo_match:
        try:
            p_inicio = date(int(periodo_match.group(2)), _MESES_ES.get(periodo_match.group(1).upper(), 1), 1)
            p_fin = date(int(periodo_match.group(4)), _MESES_ES.get(periodo_match.group(3).upper(), 12), 28)
        except Exception:
            pass
    seen: set = set()
    for patron in (_RE_CEICO, _RE_CEICO_TABLA):
        for m in patron.finditer(texto):
            insumo_raw, var_str = m.groups()
            insumo = re.sub(r"^[o•▪\-\*]\s*", "", insumo_raw.strip())  # quita viñetas mal codificadas
            try:
                variacion = float(var_str.replace(",", "."))
            except ValueError:
                continue
            if abs(variacion) > 200 or insumo in seen or len(insumo) < 4:
                continue
            seen.add(insumo)
            d = insumo.lower()
            familia = next((f for f, kw in [("ACERO", "acero"), ("ACERO", "varilla"), ("CEMENTO_CONCRETO", "cemento"),
                                             ("MADERA", "madera"), ("MAMPOSTERIA", "block"), ("PLOMERIA", "tubo"),
                                             ("ELECTRICO", "cable"), ("ASFALTO", "asfalto"), ("PETREOS", "arena")]
                           if kw in d), "GENERAL")
            registros.append(RegistroIndice(insumo=insumo.strip()[:200], variacion_pct=variacion,
                                             periodo_inicio=p_inicio, periodo_fin=p_fin, familia=familia))
    return registros


_RE_FACTOR_ITEM = re.compile(r"^(\d+[ab]?)\.\s+", re.MULTILINE)


def extractor_factores_indirectos(ruta: Path, cfg: Dict[str, Any]) -> List[RegistroFactor]:
    """
    Formato real validado (CDMX-SOBSE 'Factor de Indirecto Integrado'): NO es
    un porcentaje mensual único, es una tabla fija de 9-10 tipos de servicio,
    cada uno con su propio factor multiplicador (ej. '1. Supervisión de
    construcción de obra.  1.7211'). El documento suele incluir además un
    EJEMPLO numérico de cálculo más abajo que reutiliza la misma numeración
    (1., 2., 3.…) — se corta la búsqueda antes de esa sección para no
    confundir los factores reales de la tabla con los pasos del ejemplo.
    """
    registros: List[RegistroFactor] = []
    texto, cfg["_calidad"] = _obtener_texto(ruta, cfg, layout=False)
    vig = cfg.get("vigencia_desde", date.today())

    limite = len(texto)
    for marcador in ("Notas:", "EJEMPLO DE LA DETERMINACIÓN", "EJEMPLO DE LA DETERMINACION"):
        pos = texto.find(marcador)
        if pos != -1:
            limite = min(limite, pos)
    texto_tabla = texto[:limite]

    m_mes = re.search(
        r"Ciudad de M[eé]xico,?\s+a\s+\d{1,2}\s+de\s+(\w+)\s+de\s+(\d{4})", texto[:2000], re.IGNORECASE,
    )
    if m_mes:
        mes_num = _MESES_ES.get(m_mes.group(1).upper())
        if mes_num:
            try:
                vig = date(int(m_mes.group(2)), mes_num, 1)
            except ValueError:
                pass

    items = list(_RE_FACTOR_ITEM.finditer(texto_tabla))
    for idx, m in enumerate(items):
        inicio = m.end()
        fin = items[idx + 1].start() if idx + 1 < len(items) else min(inicio + 500, limite)
        bloque = texto_tabla[inicio:fin]
        valor_m = re.search(r"(\d\.\d{3,4})\s*\*?", bloque)
        if not valor_m:
            continue
        try:
            factor = float(valor_m.group(1))
        except ValueError:
            continue
        if factor <= 0 or factor > 5:
            continue
        desc = re.sub(r"\s+", " ", bloque[:valor_m.start()]).strip(" .")
        if len(desc) < 5:
            continue
        registros.append(RegistroFactor(
            convocante="CDMX", tipo_obra=f"[{m.group(1)}] {desc}"[:120], factor_indirecto=factor, mes_anio=vig,
        ))
    return registros


EXTRACTORES = {
    "extractor_sict_tcd": extractor_sict_tcd,
    "extractor_cmic_catalogo": extractor_cmic_catalogo,
    "extractor_cmic_estudio_mercado": extractor_cmic_estudio_mercado,
    "extractor_cmic_maquinaria": extractor_cmic_maquinaria,
    "extractor_sict_maquinaria": extractor_sict_maquinaria,
    "extractor_cfe": extractor_cfe,
    "extractor_cdmx": extractor_cdmx,
    "extractor_materiales_general": extractor_materiales_general,
    "extractor_salarios_profesionales": extractor_salarios_profesionales,
    "extractor_rendimientos": extractor_rendimientos,
    "extractor_parametricos_general": extractor_parametricos_general,
    "extractor_costos_m2": extractor_costos_m2,
    "extractor_ceico": extractor_ceico,
    "extractor_factores_indirectos": extractor_factores_indirectos,
}


def parse_catalogo_pdf_nativo(ruta: Path, cfg: Dict[str, Any]) -> ResultadoCatalogoPDF:
    fn = EXTRACTORES.get(cfg.get("extractor", ""))
    if not fn:
        return ResultadoCatalogoPDF(archivo=ruta.name, tipo_registro="NINGUNO", registros=[])
    cfg = dict(cfg)
    registros = fn(ruta, cfg)
    tipo_registro = type(registros[0]).__name__ if registros else "NINGUNO"
    calidad = cfg.get("_calidad", "DIRECTO" if ruta.suffix.lower() in (".md", ".txt") else "NATIVO")
    return ResultadoCatalogoPDF(archivo=ruta.name, tipo_registro=tipo_registro, registros=registros,
                                calidad=calidad, vigencia_real=cfg.get("_vigencia_real"))
