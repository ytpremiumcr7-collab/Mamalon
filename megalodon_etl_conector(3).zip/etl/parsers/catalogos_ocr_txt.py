"""
etl/parsers/catalogos_ocr_txt.py

Los catálogos CMIC/CEICO en .txt (Vivienda, Carreteras, Maquinaria horaria,
Infraestructura Educativa, Sector Salud, Pozos, Ecotecnologías, etc.) vienen
de un OCR/extracción de PDF con una marca de agua vertical letra-por-línea
("Documento sin costo para OSCAR ENRIQUE...") intercalada en el texto, lo
que rompe cualquier alineación columna a columna.

Estrategia honesta y conservadora (para NO meter precios incorrectos a un
sistema de presupuestos de obra pública):

  1. Se limpia el texto (se quita la marca de agua vertical, se normalizan
     espacios) y se guarda ÍNTEGRO en `documentos_referencia` +
     `catalogos_fuente`, indexado con full-text search. Esto es lo que
     queda con confianza ALTA: el contenido es buscable y queda trazado.

  2. Se hace un escaneo best-effort de líneas que parezcan precios unitarios
     (un monto en $ cerca de una unidad de medida tipo m2/m3/kg/pza/ml) y se
     cargan como candidatos en `catalogo_insumos` con
     confianza_extraccion='BAJA'. Esto NO debe usarse para presupuestar sin
     revisión humana — sirve como punto de partida para curaduría manual o
     para una segunda pasada con OCR orientado a tablas (Textract, Azure
     Form Recognizer, camelot sobre el PDF fuente con `lattice`), que no
     está disponible en este entorno sin conexión a internet.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from ..utils import limpiar_texto_ocr_basico, parse_monto

_UNIDADES = r"(?:m2|m3|ml|kg|ton|pza|lote|jornada|hr|millar|m|km|l|lt)"
_LINEA_CANDIDATA_RE = re.compile(
    rf"(?P<desc>[^\n$]{{8,140}}?)\s+(?P<unidad>{_UNIDADES})\b[^\n$]{{0,40}}\$\s?(?P<precio>[\d,]+\.\d{{2}})",
    re.IGNORECASE,
)


@dataclass
class CandidatoPrecio:
    descripcion: str
    unidad: str
    precio: float
    confianza: str = "BAJA"


@dataclass
class ResultadoCatalogoOCR:
    archivo: str
    texto_limpio: str
    candidatos: List[CandidatoPrecio] = field(default_factory=list)


def parse_catalogo_ocr(path: Path, max_candidatos: int = 5000) -> ResultadoCatalogoOCR:
    raw = path.read_text(encoding="utf-8", errors="replace")
    limpio = limpiar_texto_ocr_basico(raw)

    candidatos: List[CandidatoPrecio] = []
    for m in _LINEA_CANDIDATA_RE.finditer(limpio):
        desc = re.sub(r"\s+", " ", m.group("desc")).strip(" .,:;-")
        if len(desc) < 6:
            continue
        precio = parse_monto(m.group("precio"))
        if precio is None or precio <= 0:
            continue
        candidatos.append(CandidatoPrecio(
            descripcion=desc[:300],
            unidad=m.group("unidad").lower(),
            precio=precio,
            confianza="BAJA",
        ))
        if len(candidatos) >= max_candidatos:
            break

    return ResultadoCatalogoOCR(archivo=path.name, texto_limpio=limpio, candidatos=candidatos)
