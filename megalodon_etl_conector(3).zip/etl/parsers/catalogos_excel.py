"""
etl/parsers/catalogos_excel.py — ingestión de catálogos tabulares limpios (.xlsx).

Cubre dos perfiles reales observados en el corpus de Megalodon:

  A) Hojas "Items_YYYY" con encabezados en inglés tipo:
     source_pdf, year, section, category, code, description, unit, price, page
     (ej. CAT_LOGO_POR_GERENCIA_SGIH_2026_extraccion.xlsx)

  B) Hojas "Items_YYYY" con encabezados extendidos tipo:
     source_pdf, document_type, year, page, section_code, section_title,
     section_raw, code, description, unit, price_mxn, currency, supplier,
     phone, source_date, source_date_text
     (ej. tabulador_general_precios_unitarios_cdmx_2026_extraccion_revisado.xlsx)

  C) Hojas de tablas de ingeniería sin columnas estándar (ej. pesos de
     materiales: ángulos, PTR, varilla corrugada, IPR, etc.) — estas se
     enrutan a `materiales_pesos_referencia` en lugar de `catalogo_insumos`.

Si una hoja no contiene ninguna columna reconocible de catálogo de precios,
se intenta como tabla de pesos/ingeniería; si tampoco aplica, se reporta
como hoja no clasificada (no se descarta el archivo completo).
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Any

import openpyxl

_COLS_PRECIO_CANDIDATAS = {
    "code": "clave", "clave": "clave",
    "description": "descripcion", "descripcion": "descripcion", "descripción": "descripcion",
    "unit": "unidad", "unidad": "unidad",
    "price": "precio", "price_mxn": "precio", "precio": "precio",
    "section": "seccion", "section_title": "seccion", "category": "seccion", "seccion": "seccion",
    "page": "pagina", "source_pdf": "archivo_fuente", "year": "anio",
}


@dataclass
class FilaCatalogo:
    clave: str
    descripcion: str
    unidad: str
    precio: float
    seccion: str = ""
    pagina: Optional[int] = None
    archivo_fuente: str = ""
    confianza: str = "ALTA"
    extra: dict = field(default_factory=dict)


@dataclass
class FilaPesoMaterial:
    categoria: str
    producto: str
    peso_kg_pza: Optional[float]
    peso_kg_ml: Optional[float]
    especificacion: dict


@dataclass
class ResultadoCatalogoExcel:
    archivo: str
    nombre_catalogo: str
    filas_catalogo: List[FilaCatalogo] = field(default_factory=list)
    filas_peso: List[FilaPesoMaterial] = field(default_factory=list)
    hojas_no_clasificadas: List[str] = field(default_factory=list)


def _header_map(header_row) -> dict:
    mapping = {}
    for idx, h in enumerate(header_row):
        if h is None:
            continue
        key = str(h).strip().lower()
        if key in _COLS_PRECIO_CANDIDATAS:
            mapping[_COLS_PRECIO_CANDIDATAS[key]] = idx
    return mapping


def _parse_hoja_catalogo(ws, archivo: str) -> List[FilaCatalogo]:
    filas: List[FilaCatalogo] = []
    rows_iter = ws.iter_rows(values_only=True)
    header = None
    for row in rows_iter:
        if header is None:
            mapping = _header_map(row)
            if "clave" in mapping and "descripcion" in mapping and "precio" in mapping:
                header = mapping
            continue
        try:
            clave = row[header["clave"]]
            desc = row[header["descripcion"]]
            precio = row[header["precio"]]
            if clave is None or desc is None or precio is None:
                continue
            unidad = row[header["unidad"]] if "unidad" in header else ""
            seccion = row[header["seccion"]] if "seccion" in header else ""
            pagina = row[header["pagina"]] if "pagina" in header else None
            filas.append(FilaCatalogo(
                clave=str(clave).strip(),
                descripcion=str(desc).strip(),
                unidad=str(unidad or "").strip(),
                precio=float(precio),
                seccion=str(seccion or "").strip(),
                pagina=int(pagina) if isinstance(pagina, (int, float)) else None,
                archivo_fuente=archivo,
                confianza="ALTA",
            ))
        except (ValueError, TypeError, KeyError):
            continue
    return filas


_PESO_HEADERS = {"peso (kg) x pza", "peso (kg) x ml", "peso kg/m", "peso kg/ml", "peso unitario", "kg./m", "kg/m"}


def _hoja_parece_peso_materiales(ws) -> bool:
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i > 6:
            break
        for cell in row:
            if isinstance(cell, str) and any(p in cell.lower() for p in _PESO_HEADERS):
                return True
    return False


def _parse_hoja_peso(ws, categoria: str) -> List[FilaPesoMaterial]:
    filas: List[FilaPesoMaterial] = []
    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    headers = []
    for i, row in enumerate(rows[:8]):
        texts = [str(c).strip().lower() if isinstance(c, str) else "" for c in row]
        if any(t in _PESO_HEADERS or "producto" in t or "perfil" in t for t in texts):
            header_idx = i
            headers = row
            break
    if header_idx is None:
        return filas
    col_producto = next((i for i, h in enumerate(headers) if isinstance(h, str) and
                          ("producto" in h.lower() or "perfil" in h.lower() or "tipo" in h.lower())), None)
    col_pza = next((i for i, h in enumerate(headers) if isinstance(h, str) and "x pza" in h.lower()), None)
    col_ml = next((i for i, h in enumerate(headers) if isinstance(h, str) and
                   ("x ml" in h.lower() or h.strip().lower() in ("kg/m", "kg./m", "peso kg/m"))), None)
    for row in rows[header_idx + 1:]:
        if col_producto is None or col_producto >= len(row):
            continue
        producto = row[col_producto]
        if producto is None or str(producto).strip() == "":
            continue
        peso_pza = row[col_pza] if col_pza is not None and col_pza < len(row) else None
        peso_ml = row[col_ml] if col_ml is not None and col_ml < len(row) else None
        try:
            peso_pza = float(peso_pza) if isinstance(peso_pza, (int, float)) else None
        except (ValueError, TypeError):
            peso_pza = None
        try:
            peso_ml = float(peso_ml) if isinstance(peso_ml, (int, float)) else None
        except (ValueError, TypeError):
            peso_ml = None
        especificacion = {str(headers[i]): row[i] for i in range(len(row))
                           if i < len(headers) and headers[i] is not None and row[i] is not None}
        filas.append(FilaPesoMaterial(
            categoria=categoria,
            producto=str(producto).strip(),
            peso_kg_pza=peso_pza,
            peso_kg_ml=peso_ml,
            especificacion=especificacion,
        ))
    return filas


def parse_catalogo_excel(path: Path) -> ResultadoCatalogoExcel:
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    resultado = ResultadoCatalogoExcel(archivo=path.name, nombre_catalogo=path.stem)
    for sheet_name in wb.sheetnames:
        if sheet_name.lower() in ("resumen", "summary"):
            continue
        ws = wb[sheet_name]
        filas_cat = _parse_hoja_catalogo(ws, path.name)
        if filas_cat:
            resultado.filas_catalogo.extend(filas_cat)
            continue
        if _hoja_parece_peso_materiales(ws):
            resultado.filas_peso.extend(_parse_hoja_peso(ws, categoria=sheet_name))
            continue
        resultado.hojas_no_clasificadas.append(sheet_name)
    return resultado
