"""
etl/parsers/referencias_docx.py — extrae texto narrativo y, cuando aplica,
tablas de costo paramétrico por m2 (rangos "$X - $Y") tipo
'1045336630-Costos-Construccion-Mexico-2026.docx'.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import docx

_RANGO_RE = re.compile(r"\$\s?([\d,]+)\s*[-–—]\s*\$?\s?([\d,]+)")


@dataclass
class FilaCostoParametrico:
    tipo_obra: str
    costo_min: float
    costo_max: float
    caracteristicas: str
    tiempo_estimado: str


@dataclass
class ResultadoDocx:
    archivo: str
    titulo: str
    texto_completo: str
    tablas_crudas: List[List[List[str]]] = field(default_factory=list)
    costos_parametricos: List[FilaCostoParametrico] = field(default_factory=list)


def _to_float(s: str) -> Optional[float]:
    try:
        return float(s.replace(",", "").replace("$", "").strip())
    except ValueError:
        return None


def parse_docx(path: Path) -> ResultadoDocx:
    d = docx.Document(str(path))
    parrafos = [p.text for p in d.paragraphs if p.text.strip()]
    titulo = parrafos[0] if parrafos else path.stem
    texto_completo = "\n".join(parrafos)

    tablas_crudas: List[List[List[str]]] = []
    costos: List[FilaCostoParametrico] = []

    for tabla in d.tables:
        filas = [[c.text.strip() for c in row.cells] for row in tabla.rows]
        tablas_crudas.append(filas)
        if not filas or len(filas) < 2:
            continue
        encabezado = [h.lower() for h in filas[0]]
        idx_tipo = next((i for i, h in enumerate(encabezado) if "tipo" in h or "obra" in h), 0)
        idx_costo = next((i for i, h in enumerate(encabezado) if "costo" in h or "precio" in h or "m²" in h or "m2" in h), None)
        idx_carac = next((i for i, h in enumerate(encabezado) if "caracter" in h), None)
        idx_tiempo = next((i for i, h in enumerate(encabezado) if "tiempo" in h or "plazo" in h), None)
        if idx_costo is None:
            continue
        for fila in filas[1:]:
            if idx_costo >= len(fila):
                continue
            m = _RANGO_RE.search(fila[idx_costo])
            if not m:
                continue
            cmin, cmax = _to_float(m.group(1)), _to_float(m.group(2))
            if cmin is None or cmax is None:
                continue
            costos.append(FilaCostoParametrico(
                tipo_obra=fila[idx_tipo] if idx_tipo < len(fila) else "",
                costo_min=cmin,
                costo_max=cmax,
                caracteristicas=fila[idx_carac] if (idx_carac is not None and idx_carac < len(fila)) else "",
                tiempo_estimado=fila[idx_tiempo] if (idx_tiempo is not None and idx_tiempo < len(fila)) else "",
            ))

    return ResultadoDocx(
        archivo=path.name,
        titulo=titulo,
        texto_completo=texto_completo,
        tablas_crudas=tablas_crudas,
        costos_parametricos=costos,
    )
