"""etl/config.py — configuración central del pipeline ETL Megalodon Costos."""
from __future__ import annotations
import os
from pathlib import Path

# Carpeta raíz con los documentos fuente (la carpeta 'txtmd' descomprimida)
SOURCE_DIR = Path(os.environ.get("ETL_SOURCE_DIR", "./txtmd")).resolve()

# Carpeta de trabajo temporal (conversión de .doc/.xls legacy, extracción de zips anidados)
WORK_DIR = Path(os.environ.get("ETL_WORK_DIR", "./_etl_work")).resolve()

# Si es True, no escribe en la base de datos: solo recorre/clasifica/parsea y
# reporta conteos. Útil para validar antes de apuntar a una BD real.
DRY_RUN = os.environ.get("ETL_DRY_RUN", "false").lower() == "true"

# Tamaño máximo de texto (caracteres) que se guarda íntegro en documentos_referencia.texto_extraido
# Para libros muy grandes se trunca el texto íntegro pero se generan fragmentos completos igualmente.
MAX_TEXTO_COMPLETO_CHARS = int(os.environ.get("ETL_MAX_TEXTO_CHARS", "2_000_000".replace("_", "")))

# Tamaño de cada fragmento (para documento_referencia_fragmentos / búsqueda)
FRAGMENTO_CHARS = int(os.environ.get("ETL_FRAGMENTO_CHARS", "1800"))

# Ruta al binario de LibreOffice para convertir .doc/.xls legacy (requerido para esos formatos)
SOFFICE_BIN = os.environ.get("SOFFICE_BIN", "soffice")

# Extensiones que el pipeline sabe procesar
EXTENSIONES_SOPORTADAS = {
    ".txt", ".md", ".pdf", ".xlsx", ".xls", ".docx", ".doc", ".zip",
}

LOG_LEVEL = os.environ.get("ETL_LOG_LEVEL", "INFO")
