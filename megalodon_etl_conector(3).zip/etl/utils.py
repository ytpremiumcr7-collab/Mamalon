"""etl/utils.py — utilidades comunes para el pipeline ETL."""
from __future__ import annotations
import hashlib
import re
import unicodedata
from pathlib import Path
from typing import Iterator


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


_WATERMARK_VERTICAL_RE = re.compile(
    r"\n\s*([A-Za-zÁÉÍÓÚÑáéíóúñ]\s*\n){3,}", re.MULTILINE
)


def limpiar_texto_ocr_basico(texto: str) -> str:
    """
    Limpieza heurística y conservadora de texto extraído por OCR/extracción
    de PDF con artefactos típicos de marcas de agua verticales (una letra
    por línea, repetida muchas líneas) y exceso de saltos de línea/espacios.
    No intenta reconstruir tablas: eso se deja a los parsers especializados.
    """
    if not texto:
        return ""
    # colapsa form-feeds de fin de página en marcador legible
    texto = texto.replace("\f", "\n\n--- [salto de página] ---\n\n")
    # colapsa 3+ líneas consecutivas de un solo carácter (marcas de agua verticales)
    texto = _WATERMARK_VERTICAL_RE.sub("\n", texto)
    # colapsa espacios/saltos excesivos
    texto = re.sub(r"[ \t]+", " ", texto)
    texto = re.sub(r"\n{3,}", "\n\n", texto)
    return texto.strip()


def normalizar_clave(s: str) -> str:
    s = s.strip().upper()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s


_MONEY_RE = re.compile(r"\$?\s*([\d]{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)")


def parse_monto(texto: str) -> float | None:
    """Convierte '$862,500.00' / '8 673.96' / '12,759.10' a float. None si no aplica."""
    if texto is None:
        return None
    texto = str(texto).strip()
    m = _MONEY_RE.search(texto)
    if not m:
        return None
    raw = m.group(1)
    # formato MX: coma=miles, punto=decimal
    raw = raw.replace(",", "")
    try:
        return float(raw)
    except ValueError:
        return None


def chunk_text(texto: str, size: int) -> Iterator[str]:
    texto = texto.strip()
    if not texto:
        return
    # corta en límites de párrafo cuando es posible para no partir frases a la mitad
    parrafos = re.split(r"\n\s*\n", texto)
    buf = ""
    for p in parrafos:
        if len(buf) + len(p) + 2 <= size:
            buf = f"{buf}\n\n{p}" if buf else p
        else:
            if buf:
                yield buf
            if len(p) <= size:
                buf = p
            else:
                for i in range(0, len(p), size):
                    yield p[i:i + size]
                buf = ""
    if buf:
        yield buf


def safe_str(v, default: str = "") -> str:
    if v is None:
        return default
    return str(v)
