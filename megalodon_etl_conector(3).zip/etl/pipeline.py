"""
etl/pipeline.py — orquestador del pipeline ETL Megalodon Costos.

Flujo por archivo:
  1. Calcula hash SHA-256. Si ya existe en `etl_archivos_procesados` con el
     mismo hash y estado PROCESADO, se omite (idempotencia: re-correr el
     ETL no duplica datos ni vuelve a parsear archivos sin cambios).
  2. Clasifica el archivo (etl.classify).
  3. Despacha al parser correspondiente.
  4. Carga los registros resultantes a PostgreSQL (o solo cuenta, en DRY_RUN).
  5. Registra el resultado en `etl_archivos_procesados` y acumula métricas
     en `etl_runs`.

Modo DRY_RUN (sin PostgreSQL): se ejecuta exactamente la misma lógica de
clasificación y parsing, pero los pasos de carga se omiten y en su lugar
se acumulan conteos en memoria. Esto permite validar el pipeline completo
contra el corpus real sin necesitar credenciales de base de datos.
"""
from __future__ import annotations
import logging
import time
import traceback
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from . import config
from .classify import clasificar
from .utils import sha256_file, sha256_text
from .parsers import leyes, catalogos_excel, catalogos_ocr_txt, referencias_pdf, referencias_md, referencias_docx
from .parsers import legacy_office, nested_zip, catalogos_pdf_nativo

log = logging.getLogger("megalodon.etl")


@dataclass
class ResumenArchivo:
    archivo: str
    tipo_detectado: str
    estado: str
    registros: int = 0
    confianza: str = ""
    error: str = ""
    detalle: dict = field(default_factory=dict)


@dataclass
class ResumenRun:
    total_archivos: int = 0
    ok: int = 0
    parcial: int = 0
    error: int = 0
    omitidos: int = 0
    registros_totales: int = 0
    por_tipo: Counter = field(default_factory=Counter)
    resultados: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Capa de persistencia (se omite por completo en DRY_RUN)
# ---------------------------------------------------------------------------

class Persistencia:
    """Encapsula todas las escrituras a PostgreSQL. En DRY_RUN no se importa
    psycopg2 ni se abre ninguna conexión."""

    def __init__(self, dry_run: bool):
        self.dry_run = dry_run
        if not dry_run:
            from db.connector import pooled_cursor, bulk_upsert  # import diferido
            self._pooled_cursor = pooled_cursor
            self._bulk_upsert = bulk_upsert

    def ya_procesado(self, hash_sha256: str) -> bool:
        if self.dry_run:
            return False
        with self._pooled_cursor() as cur:
            cur.execute(
                "SELECT 1 FROM etl_archivos_procesados WHERE hash_sha256=%s AND estado='PROCESADO'",
                (hash_sha256,),
            )
            return cur.fetchone() is not None

    def registrar_archivo(self, **kwargs) -> None:
        if self.dry_run:
            return
        import json
        with self._pooled_cursor(commit=True) as cur:
            cur.execute(
                """
                INSERT INTO etl_archivos_procesados
                    (ruta_relativa, nombre_archivo, extension, hash_sha256, tamano_bytes,
                     tipo_detectado, estrategia_aplicada, estado, registros_generados,
                     confianza_promedio, error_text, duracion_ms, metadata_jsonb)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (hash_sha256) DO UPDATE SET
                    estado=EXCLUDED.estado, registros_generados=EXCLUDED.registros_generados,
                    confianza_promedio=EXCLUDED.confianza_promedio, error_text=EXCLUDED.error_text,
                    duracion_ms=EXCLUDED.duracion_ms, procesado_en=NOW()
                """,
                (
                    kwargs["ruta_relativa"], kwargs["nombre_archivo"], kwargs["extension"],
                    kwargs["hash_sha256"], kwargs["tamano_bytes"], kwargs["tipo_detectado"],
                    kwargs.get("estrategia_aplicada", ""), kwargs["estado"], kwargs.get("registros", 0),
                    kwargs.get("confianza", ""), kwargs.get("error", ""), kwargs.get("duracion_ms", 0),
                    json.dumps(kwargs.get("metadata", {})),
                ),
            )

    # ---- catálogos de costos (xlsx limpio + OCR best-effort) --------------

    def cargar_catalogo_fuente(self, nombre_catalogo: str, fuente: str, tipo_catalogo: str,
                                archivo_origen: str, hash_archivo: str, ocr_status: str = "NO_REQUIERE") -> str:
        with self._pooled_cursor(commit=True) as cur:
            cur.execute(
                """
                INSERT INTO catalogos_fuente (nombre_catalogo, fuente, tipo_catalogo, archivo_origen, hash_archivo, ocr_status)
                VALUES (%s,%s,%s,%s,%s,%s)
                ON CONFLICT (hash_archivo) WHERE hash_archivo <> '' DO NOTHING
                RETURNING id
                """,
                (nombre_catalogo, fuente, tipo_catalogo, archivo_origen, hash_archivo, ocr_status),
            )
            row = cur.fetchone()
            if row:
                return row["id"]
            cur.execute("SELECT id FROM catalogos_fuente WHERE hash_archivo=%s", (hash_archivo,))
            row = cur.fetchone()
            return row["id"]

    def cargar_catalogo_fuente_v2(self, cfg: dict, archivo_origen: str, hash_archivo: str, calidad: str,
                                   vigencia_real=None) -> str:
        """Variante dirigida por FUENTES_CONFIG (etl/parsers/catalogos_pdf_nativo.py):
        registra también categoria_sector/codigo_fuente/es_historico/zona_economica.
        Si `vigencia_real` viene poblado (fecha encontrada en el propio texto del
        documento), se usa en vez de la fecha estática adivinada en FUENTES_CONFIG —
        evita que todo termine fechado "2026" solo porque ese fue el año en que se
        armó el catálogo de patrones."""
        vigencia = vigencia_real or cfg.get("vigencia_desde")
        ocr_status = "APLICADO" if calidad == "OCR_EN" else "NO_REQUIERE"
        with self._pooled_cursor(commit=True) as cur:
            cur.execute(
                """
                INSERT INTO catalogos_fuente
                    (nombre_catalogo, fuente, tipo_catalogo, archivo_origen, hash_archivo, ocr_status,
                     categoria_sector, codigo_fuente, vigencia_desde, es_historico)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (hash_archivo) WHERE hash_archivo <> '' DO UPDATE SET
                    categoria_sector=EXCLUDED.categoria_sector, ocr_status=EXCLUDED.ocr_status,
                    vigencia_desde=EXCLUDED.vigencia_desde
                RETURNING id
                """,
                (cfg["nombre_catalogo"], cfg["fuente"], cfg["tipo_catalogo"], archivo_origen, hash_archivo, ocr_status,
                 cfg.get("categoria_sector", ""), cfg.get("codigo_fuente", ""), vigencia,
                 cfg.get("es_historico", False)),
            )
            row = cur.fetchone()
            if row:
                return row["id"]
            cur.execute("SELECT id FROM catalogos_fuente WHERE hash_archivo=%s", (hash_archivo,))
            return cur.fetchone()["id"]

    def cargar_conceptos_apu(self, catalogo_fuente_id: str, registros) -> int:
        """Carga RegistroConceptoAPU -> apu_conceptos (+ catalogo_insumos / apu_concepto_insumos si trae desglose)."""
        total = 0
        with self._pooled_cursor(commit=True) as cur:
            for r in registros:
                cur.execute(
                    """
                    INSERT INTO apu_conceptos (catalogo_fuente_id, clave, descripcion, unidad, metadata_jsonb)
                    VALUES (%s,%s,%s,%s,%s)
                    ON CONFLICT (catalogo_fuente_id, clave) DO UPDATE SET
                        descripcion=EXCLUDED.descripcion, unidad=EXCLUDED.unidad
                    RETURNING id
                    """,
                    (catalogo_fuente_id, r.clave[:120], r.descripcion[:2000], r.unidad[:30] or "PZA",
                     __import__("json").dumps({"costo_directo": r.costo_directo, "linea_num": r.linea_num}, default=str)),
                )
                concepto_id = cur.fetchone()["id"]
                total += 1
                for orden, ins in enumerate(r.insumos or []):
                    cur.execute(
                        """
                        INSERT INTO catalogo_insumos (catalogo_fuente_id, clave, descripcion, unidad, precio, fuente_catalogo)
                        VALUES (%s,%s,%s,%s,%s,%s)
                        ON CONFLICT (catalogo_fuente_id, clave) DO UPDATE SET precio=EXCLUDED.precio
                        RETURNING id
                        """,
                        (catalogo_fuente_id, (ins.get("clave") or f"INS-{concepto_id}-{orden}")[:120],
                         ins.get("descripcion", "")[:2000], ins.get("unidad", "")[:30] or "PZA",
                         ins.get("precio_unitario", 0), "APU"),
                    )
                    insumo_id = cur.fetchone()["id"]
                    componente = ins.get("tipo", "material")
                    if componente not in ("material", "mano_obra", "equipo", "otro"):
                        componente = "otro"
                    cur.execute(
                        """
                        INSERT INTO apu_concepto_insumos (concepto_id, insumo_id, componente, cantidad, orden)
                        VALUES (%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING
                        """,
                        (concepto_id, insumo_id, componente, ins.get("cantidad", 0), orden),
                    )
        return total

    def cargar_maquinaria(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.clave[:120], r.descripcion[:300], r.tipo[:60], r.marca[:80],
                  r.hp, r.costo_horario) for r in registros]
        return self._bulk_upsert(
            table="maquinaria_catalogo",
            columns=["catalogo_fuente_id", "clave", "descripcion", "tipo", "marca", "hp", "costo_horario"],
            rows=rows, conflict_cols=["catalogo_fuente_id", "clave"],
            update_cols=["descripcion", "costo_horario", "marca", "hp"],
        )

    def cargar_salarios(self, catalogo_fuente_id: str, registros, tipo_personal: str = "EJECUCION") -> int:
        rows = [(catalogo_fuente_id, r.categoria[:200], tipo_personal, r.salario_base,
                  r.factor_imss, r.factor_imss_total, r.salario_real) for r in registros]
        return self._bulk_upsert(
            table="mano_obra_salarios",
            columns=["catalogo_fuente_id", "categoria", "tipo_personal", "salario_base_diario",
                     "factor_imss", "factor_imss_total", "salario_real_diario"],
            rows=rows, conflict_cols=["catalogo_fuente_id", "categoria", "tipo_personal"],
            update_cols=["salario_base_diario", "factor_imss", "factor_imss_total", "salario_real_diario"],
        )

    def cargar_indices(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.insumo[:200], r.familia[:60], r.variacion_pct, r.periodo_inicio, r.periodo_fin)
                for r in registros]
        return self._bulk_upsert(
            table="indices_precios_materiales",
            columns=["catalogo_fuente_id", "insumo", "familia", "variacion_pct", "periodo_inicio", "periodo_fin"],
            rows=rows, conflict_cols=["catalogo_fuente_id", "insumo", "periodo_inicio"],
            update_cols=["variacion_pct", "periodo_fin", "familia"],
        )

    def cargar_factores_indirectos(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.convocante[:120], r.tipo_obra[:120], r.factor_indirecto,
                  r.factor_utilidad, r.mes_anio) for r in registros]
        return self._bulk_upsert(
            table="factores_indirectos",
            columns=["catalogo_fuente_id", "convocante", "tipo_obra", "factor_indirecto", "factor_utilidad", "mes_anio"],
            rows=rows, conflict_cols=["convocante", "tipo_obra", "mes_anio", "catalogo_fuente_id"],
            update_cols=["factor_indirecto", "factor_utilidad"],
        )

    def cargar_parametricos_obra(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.tipo_obra[:120], r.descripcion[:500], r.unidad[:30],
                  r.costo, r.costo_min, r.costo_max) for r in registros]
        return self._bulk_upsert(
            table="costos_parametricos_obra",
            columns=["catalogo_fuente_id", "tipo_obra", "descripcion", "unidad_parametro", "costo", "costo_min", "costo_max"],
            rows=rows,
        )

    def cargar_costos_m2_historico(self, catalogo_fuente_id: str, registros) -> int:
        import json
        rows = []
        for r in registros:
            rows.append((catalogo_fuente_id, r.tipo_espacio[:200], r.uso[:60] or "GENERAL",
                         r.precio_m2, r.precio_m2,
                         json.dumps({"categoria": r.categoria, "historico_periodos": r.historico_periodos,
                                     "variacion_pct_periodo": r.variacion_pct_periodo}, default=str)))
        return self._bulk_upsert(
            table="costos_parametricos_m2",
            columns=["catalogo_fuente_id", "tipo_obra", "zona", "costo_min_mxn_m2", "costo_max_mxn_m2", "metadata_jsonb"],
            rows=rows,
        )

    def cargar_rendimientos(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.actividad[:300], r.unidad_trabajo[:60], r.rendimiento_minimo,
                  r.rendimiento_medio, r.rendimiento_maximo) for r in registros]
        return self._bulk_upsert(
            table="rendimientos_mano_obra",
            columns=["catalogo_fuente_id", "actividad", "unidad_trabajo", "rendimiento_minimo",
                     "rendimiento_medio", "rendimiento_maximo"],
            rows=rows,
        )

    def cargar_materiales_simples(self, catalogo_fuente_id: str, registros) -> int:
        rows = [(catalogo_fuente_id, r.clave[:120], r.descripcion[:2000], r.unidad[:30] or "PZA",
                  r.precio, "MATERIAL_PDF", "ALTA", getattr(r, "zona", "")[:200], getattr(r, "tipo_recurso", "material"))
                 for r in registros]
        return self._bulk_upsert(
            table="catalogo_insumos",
            columns=["catalogo_fuente_id", "clave", "descripcion", "unidad", "precio", "fuente_catalogo",
                     "confianza_extraccion", "zona", "tipo_recurso"],
            rows=rows, conflict_cols=["catalogo_fuente_id", "clave"],
            update_cols=["descripcion", "unidad", "precio", "zona", "tipo_recurso"],
        )

    def cargar_filas_catalogo_insumo(self, catalogo_fuente_id: str, filas) -> int:
        rows = []
        for i, f in enumerate(filas):
            clave = f.clave.strip() if getattr(f, "clave", "").strip() else f"AUTO-{i:06d}"
            rows.append((
                catalogo_fuente_id, clave[:120], f.descripcion[:2000], f.unidad[:30] or "PZA",
                f.precio, f.archivo_fuente, f.confianza, f.pagina, f.seccion[:300],
            ))
        return self._bulk_upsert(
            table="catalogo_insumos",
            columns=["catalogo_fuente_id", "clave", "descripcion", "unidad", "precio",
                     "fuente_catalogo", "confianza_extraccion", "pagina_origen", "seccion"],
            rows=rows,
            conflict_cols=["catalogo_fuente_id", "clave"],
            update_cols=["descripcion", "unidad", "precio", "confianza_extraccion", "pagina_origen", "seccion"],
        )

    def cargar_filas_peso(self, filas) -> int:
        import json
        rows = [
            (f.categoria[:120], f.producto[:300], f.peso_kg_pza, f.peso_kg_ml, json.dumps(f.especificacion, default=str))
            for f in filas
        ]
        return self._bulk_upsert(
            table="materiales_pesos_referencia",
            columns=["categoria", "producto", "peso_kg_pza", "peso_kg_ml", "especificacion_jsonb"],
            rows=rows,
            conflict_cols=["categoria", "producto"],
            update_cols=["peso_kg_pza", "peso_kg_ml", "especificacion_jsonb"],
        )

    # ---- leyes --------------------------------------------------------------

    def cargar_ley(self, ley) -> str:
        with self._pooled_cursor(commit=True) as cur:
            cur.execute(
                """
                INSERT INTO leyes (clave, nombre_completo, jurisdiccion, archivo_origen, texto_completo,
                                    total_articulos, ultima_reforma_dof)
                VALUES (%s,%s,%s,%s,%s,%s, to_date(%s,'DD-MM-YYYY'))
                ON CONFLICT (clave) DO UPDATE SET
                    archivo_origen=EXCLUDED.archivo_origen, texto_completo=EXCLUDED.texto_completo,
                    total_articulos=EXCLUDED.total_articulos, ultima_reforma_dof=EXCLUDED.ultima_reforma_dof,
                    updated_at=NOW()
                RETURNING id
                """,
                (ley.clave, ley.nombre_completo, ley.jurisdiccion, ley.archivo_origen,
                 ley.texto_completo[:config.MAX_TEXTO_COMPLETO_CHARS], len(ley.articulos), ley.ultima_reforma_dof),
            )
            ley_id = cur.fetchone()["id"]
            cur.execute("DELETE FROM ley_articulos WHERE ley_id=%s", (ley_id,))
        rows = [
            (ley_id, a.numero_articulo[:50], a.titulo[:200], a.capitulo[:200], a.titulo_seccion[:200],
             a.texto, a.orden, a.es_transitorio, a.reformas_dof)
            for a in ley.articulos
        ]
        if rows:
            self._bulk_upsert(
                table="ley_articulos",
                columns=["ley_id", "numero_articulo", "titulo", "capitulo", "titulo_seccion",
                         "texto", "orden", "es_transitorio", "reformas_dof"],
                rows=rows,
            )
        return ley_id

    # ---- documentos de referencia (PDF/DOCX/MD narrativo) -------------------

    def cargar_documento_referencia(self, titulo: str, categoria: str, archivo_origen: str,
                                     formato_origen: str, hash_archivo: str, texto_extraido: str,
                                     paginas: Optional[int] = None, calidad: str = "ALTA", metadata: dict = None) -> str:
        import json
        with self._pooled_cursor(commit=True) as cur:
            cur.execute(
                """
                INSERT INTO documentos_referencia
                    (titulo, categoria, archivo_origen, formato_origen, hash_archivo,
                     paginas, texto_extraido, calidad_extraccion, metadata_jsonb)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (hash_archivo) DO UPDATE SET
                    texto_extraido=EXCLUDED.texto_extraido, calidad_extraccion=EXCLUDED.calidad_extraccion,
                    updated_at=NOW()
                RETURNING id
                """,
                (titulo[:500], categoria, archivo_origen, formato_origen, hash_archivo, paginas,
                 texto_extraido[:config.MAX_TEXTO_COMPLETO_CHARS], calidad, json.dumps(metadata or {}, default=str)),
            )
            return cur.fetchone()["id"]

    def cargar_fragmentos(self, documento_id: str, fragmentos) -> int:
        rows = [(documento_id, getattr(f, "pagina", None), f.orden, f.contenido) for f in fragmentos]
        if not rows:
            return 0
        with self._pooled_cursor(commit=True) as cur:
            cur.execute("DELETE FROM documento_referencia_fragmentos WHERE documento_id=%s", (documento_id,))
        return self._bulk_upsert(
            table="documento_referencia_fragmentos",
            columns=["documento_id", "pagina", "orden", "contenido"],
            rows=rows,
        )

    # ---- catálogos genéricos (markdown) -------------------------------------

    def cargar_filas_genericas(self, filas) -> int:
        rows = [(f.catalogo_nombre[:200], f.clave[:120], f.descripcion[:500], f.valor_adicional[:200], f.catalogo_nombre)
                for f in filas]
        return self._bulk_upsert(
            table="catalogos_referencia_generica",
            columns=["catalogo_nombre", "clave", "descripcion", "valor_adicional", "archivo_origen"],
            rows=rows,
            conflict_cols=["catalogo_nombre", "clave"],
            update_cols=["descripcion", "valor_adicional"],
        )

    # ---- costos paramétricos -------------------------------------------------

    def cargar_costos_parametricos(self, filas, documento_referencia_id: str) -> int:
        rows = [
            (f.tipo_obra[:200], f.costo_min, f.costo_max, f.caracteristicas[:500], f.tiempo_estimado[:100],
             documento_referencia_id)
            for f in filas
        ]
        with self._pooled_cursor(commit=True) as cur:
            cur.execute("DELETE FROM costos_parametricos_m2 WHERE documento_referencia_id=%s", (documento_referencia_id,))
        if not rows:
            return 0
        return self._bulk_upsert(
            table="costos_parametricos_m2",
            columns=["tipo_obra", "costo_min_mxn_m2", "costo_max_mxn_m2", "caracteristicas",
                     "tiempo_estimado", "documento_referencia_id"],
            rows=rows,
        )


# ---------------------------------------------------------------------------
# Procesamiento de un archivo individual
# ---------------------------------------------------------------------------

UMBRAL_RENDIMIENTO_BAJO = 5  # menos de N registros en un catálogo se reporta como PARCIAL, no como éxito


def _procesar_catalogo_pdf_nativo(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str) -> ResumenArchivo:
    from .parsers.catalogos_pdf_nativo import fuente_para_archivo, parse_catalogo_pdf_nativo
    cfg = fuente_para_archivo(path.name)
    r = parse_catalogo_pdf_nativo(path, cfg)
    n = len(r.registros)
    detalle = {"tipo_registro": r.tipo_registro, "calidad": r.calidad, "fuente": cfg.get("fuente"),
               "categoria_sector": cfg.get("categoria_sector"), "codigo_fuente": cfg.get("codigo_fuente"),
               "vigencia_detectada_en_contenido": str(r.vigencia_real) if r.vigencia_real else None}

    if n == 0:
        # El extractor de alta confianza no encontró filas estructuradas (ej. el
        # patrón de la familia editorial no aplica a este archivo en particular).
        # Para que el archivo NUNCA quede sin indexar, se cae al mismo camino
        # genérico de texto completo que usaría sin coincidir con FUENTES_CONFIG.
        # El tipo_detectado original se conserva (con sufijo) para que el reporte
        # nunca oculte que la ruta de alta confianza falló en este archivo.
        detalle["fallback_de"] = "CATALOGO_PDF_NATIVO"
        sufijo = path.suffix.lower()
        if sufijo == ".pdf":
            fr = _procesar_pdf(path, persist, dry_run, hash_archivo, cfg.get("categoria_sector", "COSTOS") or "COSTOS")
        elif sufijo == ".txt":
            fr = _procesar_catalogo_ocr(path, persist, dry_run, hash_archivo)
        else:  # .md
            fr = _procesar_md(path, persist, dry_run, hash_archivo, con_tablas=False)
        fr.detalle.update(detalle)
        fr.tipo_detectado = f"{fr.tipo_detectado}_FALLBACK"
        return fr

    estado = "PROCESADO" if n >= UMBRAL_RENDIMIENTO_BAJO else "PARCIAL"
    if estado == "PARCIAL":
        detalle["advertencia"] = f"Solo {n} registros extraídos — revisar manualmente, puede ser un falso positivo parcial"

    if dry_run:
        return ResumenArchivo(path.name, "CATALOGO_PDF_NATIVO", estado, n,
                               "ALTA" if r.calidad == "NATIVO" else "MEDIA", detalle=detalle)

    cat_id = persist.cargar_catalogo_fuente_v2(cfg, path.name, hash_archivo, r.calidad, vigencia_real=r.vigencia_real)
    tipo = r.tipo_registro
    if tipo == "RegistroConceptoAPU":
        persist.cargar_conceptos_apu(cat_id, r.registros)
    elif tipo == "RegistroMaquinaria":
        persist.cargar_maquinaria(cat_id, r.registros)
    elif tipo == "RegistroSalario":
        persist.cargar_salarios(cat_id, r.registros, tipo_personal=cfg.get("tipo_personal", "EJECUCION"))
    elif tipo == "RegistroIndice":
        persist.cargar_indices(cat_id, r.registros)
    elif tipo == "RegistroFactor":
        persist.cargar_factores_indirectos(cat_id, r.registros)
    elif tipo == "RegistroParametrico":
        persist.cargar_parametricos_obra(cat_id, r.registros)
    elif tipo == "RegistroCostoM2":
        persist.cargar_costos_m2_historico(cat_id, r.registros)
    elif tipo == "RegistroRendimiento":
        persist.cargar_rendimientos(cat_id, r.registros)
    elif tipo == "RegistroMaterialSimple":
        persist.cargar_materiales_simples(cat_id, r.registros)

    return ResumenArchivo(path.name, "CATALOGO_PDF_NATIVO", estado, n,
                           "ALTA" if r.calidad == "NATIVO" else "MEDIA", detalle=detalle)


def _procesar_ley_txt(path: Path, persist: Persistencia, dry_run: bool) -> ResumenArchivo:
    ley = leyes.parse_ley(path)
    if not dry_run:
        persist.cargar_ley(ley)
    return ResumenArchivo(path.name, "LEY_TXT", "PROCESADO", len(ley.articulos), "ALTA",
                           detalle={"clave": ley.clave, "articulos": len(ley.articulos)})


def _procesar_catalogo_xlsx(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str) -> ResumenArchivo:
    r = catalogos_excel.parse_catalogo_excel(path)
    total = len(r.filas_catalogo) + len(r.filas_peso)
    if not dry_run and r.filas_catalogo:
        cat_id = persist.cargar_catalogo_fuente(r.nombre_catalogo, "EXTRACCION_LIMPIA", "APU", path.name, hash_archivo)
        persist.cargar_filas_catalogo_insumo(cat_id, r.filas_catalogo)
    if not dry_run and r.filas_peso:
        persist.cargar_filas_peso(r.filas_peso)
    return ResumenArchivo(path.name, "CATALOGO_XLSX_LIMPIO", "PROCESADO" if total else "PARCIAL", total, "ALTA",
                           detalle={"filas_catalogo": len(r.filas_catalogo), "filas_peso": len(r.filas_peso),
                                    "hojas_no_clasificadas": r.hojas_no_clasificadas})


def _procesar_catalogo_ocr(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str) -> ResumenArchivo:
    r = catalogos_ocr_txt.parse_catalogo_ocr(path)
    if not dry_run:
        doc_id = persist.cargar_documento_referencia(
            titulo=path.stem, categoria="COSTOS", archivo_origen=path.name, formato_origen="txt",
            hash_archivo=hash_archivo, texto_extraido=r.texto_limpio, calidad="OCR_DEGRADADO",
            metadata={"candidatos_precio": len(r.candidatos)},
        )
        cat_id = persist.cargar_catalogo_fuente(path.stem, "OCR_CMIC_CEICO", "APU", path.name, hash_archivo, ocr_status="APLICADO")
        if r.candidatos:
            class _F:
                __slots__ = ("clave", "descripcion", "unidad", "precio", "archivo_fuente", "confianza", "pagina", "seccion")
            filas = []
            for c in r.candidatos:
                f = _F(); f.clave = ""; f.descripcion = c.descripcion; f.unidad = c.unidad
                f.precio = c.precio; f.archivo_fuente = path.name; f.confianza = "BAJA"; f.pagina = None; f.seccion = "OCR_BEST_EFFORT"
                filas.append(f)
            persist.cargar_filas_catalogo_insumo(cat_id, filas)
    return ResumenArchivo(path.name, "CATALOGO_OCR_TXT", "PARCIAL", len(r.candidatos), "BAJA",
                           detalle={"candidatos_precio": len(r.candidatos), "texto_indexado_chars": len(r.texto_limpio)})


def _procesar_pdf(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str, categoria: str,
                   max_paginas_pdf: Optional[int] = None) -> ResumenArchivo:
    r = referencias_pdf.parse_pdf(path, max_paginas=max_paginas_pdf)
    if not dry_run:
        doc_id = persist.cargar_documento_referencia(
            titulo=path.stem, categoria=categoria, archivo_origen=path.name, formato_origen="pdf",
            hash_archivo=hash_archivo, texto_extraido=r.texto_completo, paginas=r.paginas, calidad=r.calidad_extraccion,
        )
        persist.cargar_fragmentos(doc_id, r.fragmentos)
    return ResumenArchivo(path.name, "REFERENCIA_PDF", "PROCESADO", len(r.fragmentos), r.calidad_extraccion,
                           detalle={"paginas": r.paginas, "calidad": r.calidad_extraccion})


def _procesar_md(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str, con_tablas: bool) -> ResumenArchivo:
    r = referencias_md.parse_markdown(path)
    registros = len(r.filas_genericas)
    if not dry_run:
        doc_id = persist.cargar_documento_referencia(
            titulo=r.titulo, categoria="SECTORIAL" if con_tablas else "NORMATIVA", archivo_origen=path.name,
            formato_origen="md", hash_archivo=hash_archivo, texto_extraido=r.texto_completo, calidad="ALTA",
        )
        if r.filas_genericas:
            persist.cargar_filas_genericas(r.filas_genericas)
        registros = 1 + len(r.filas_genericas)
    return ResumenArchivo(path.name, "REFERENCIA_MD", "PROCESADO", registros, "ALTA",
                           detalle={"tiene_tablas": r.tiene_tablas, "filas_genericas": len(r.filas_genericas)})


def _procesar_docx(path: Path, persist: Persistencia, dry_run: bool, hash_archivo: str) -> ResumenArchivo:
    r = referencias_docx.parse_docx(path)
    registros = len(r.costos_parametricos)
    if not dry_run:
        doc_id = persist.cargar_documento_referencia(
            titulo=r.titulo, categoria="COSTOS", archivo_origen=path.name, formato_origen="docx",
            hash_archivo=hash_archivo, texto_extraido=r.texto_completo, calidad="ALTA",
            metadata={"tablas_crudas_no_clasificadas": r.tablas_crudas if not r.costos_parametricos else []},
        )
        if r.costos_parametricos:
            persist.cargar_costos_parametricos(r.costos_parametricos, doc_id)
        registros = 1 + len(r.costos_parametricos)
    return ResumenArchivo(path.name, "REFERENCIA_DOCX", "PROCESADO", registros, "ALTA",
                           detalle={"costos_parametricos": len(r.costos_parametricos), "tablas_totales": len(r.tablas_crudas)})


# ---------------------------------------------------------------------------
# Despachador principal (recursivo para zips anidados y conversión legacy)
# ---------------------------------------------------------------------------

def procesar_archivo(path: Path, persist: Persistencia, dry_run: bool, work_dir: Path,
                      max_paginas_pdf: Optional[int] = None) -> list:
    """Devuelve una lista de ResumenArchivo (normalmente 1, más de 1 si es un zip anidado)."""
    resultados = []
    try:
        clasif = clasificar(path)
        hash_archivo = sha256_file(path)

        if not dry_run and persist.ya_procesado(hash_archivo):
            resultados.append(ResumenArchivo(path.name, clasif.tipo_detectado, "OMITIDO", 0, "",
                                              detalle={"motivo": "ya procesado (hash sin cambios)"}))
            return resultados

        t0 = time.time()

        if clasif.tipo_detectado == "CATALOGO_PDF_NATIVO":
            resultados.append(_procesar_catalogo_pdf_nativo(path, persist, dry_run, hash_archivo))

        elif clasif.tipo_detectado == "ZIP_ANIDADO":
            extraidos = nested_zip.extraer_zip(path, work_dir)
            for sub in extraidos:
                if sub.is_file() and sub.suffix.lower() in config.EXTENSIONES_SOPORTADAS:
                    resultados.extend(procesar_archivo(sub, persist, dry_run, work_dir, max_paginas_pdf))
            resumen = ResumenArchivo(path.name, "ZIP_ANIDADO", "PROCESADO", len(extraidos), "ALTA",
                                      detalle={"archivos_extraidos": len(extraidos)})
            resultados.append(resumen)

        elif clasif.tipo_detectado == "LEGACY_XLS":
            convertido = legacy_office.convertir(path, work_dir / "convertidos", "xlsx")
            resultados.append(_procesar_catalogo_xlsx(convertido, persist, dry_run, hash_archivo))

        elif clasif.tipo_detectado == "LEGACY_DOC":
            convertido = legacy_office.convertir(path, work_dir / "convertidos", "docx")
            import re as _re
            from .classify import _PATRONES_LEY_RE
            if _PATRONES_LEY_RE.search(path.name):
                texto = "\n".join(p.text for p in __import__("docx").Document(str(convertido)).paragraphs)
                ley = leyes.parse_ley_texto(texto, path.name)
                if not dry_run:
                    persist.cargar_ley(ley)
                resultados.append(ResumenArchivo(path.name, "LEGACY_DOC_LEY", "PROCESADO", len(ley.articulos), "MEDIA",
                                                  detalle={"clave": ley.clave, "articulos": len(ley.articulos)}))
            else:
                resultados.append(_procesar_docx(convertido, persist, dry_run, hash_archivo))

        elif clasif.tipo_detectado == "LEY_TXT":
            resultados.append(_procesar_ley_txt(path, persist, dry_run))

        elif clasif.tipo_detectado == "CATALOGO_XLSX_LIMPIO":
            resultados.append(_procesar_catalogo_xlsx(path, persist, dry_run, hash_archivo))

        elif clasif.tipo_detectado == "CATALOGO_OCR_TXT":
            resultados.append(_procesar_catalogo_ocr(path, persist, dry_run, hash_archivo))

        elif clasif.tipo_detectado == "REFERENCIA_PDF":
            resultados.append(_procesar_pdf(path, persist, dry_run, hash_archivo, clasif.categoria_documental, max_paginas_pdf))

        elif clasif.tipo_detectado in ("REFERENCIA_MD_TABLAS", "REFERENCIA_MD_NARRATIVA"):
            resultados.append(_procesar_md(path, persist, dry_run, hash_archivo, clasif.tipo_detectado == "REFERENCIA_MD_TABLAS"))

        elif clasif.tipo_detectado == "REFERENCIA_DOCX":
            resultados.append(_procesar_docx(path, persist, dry_run, hash_archivo))

        else:  # OMITIDO
            resultados.append(ResumenArchivo(path.name, "OMITIDO", "OMITIDO", 0, "", detalle={"motivo": clasif.motivo}))

        duracion_ms = int((time.time() - t0) * 1000)
        if not dry_run:
            for r in resultados:
                if r.archivo == path.name:
                    persist.registrar_archivo(
                        ruta_relativa=str(path), nombre_archivo=path.name, extension=path.suffix.lower(),
                        hash_sha256=hash_archivo, tamano_bytes=path.stat().st_size, tipo_detectado=r.tipo_detectado,
                        estado=r.estado, registros=r.registros, confianza=r.confianza or "", duracion_ms=duracion_ms,
                        metadata=r.detalle,
                    )
                    break

    except Exception as e:  # noqa: BLE001
        log.error("Error procesando %s: %s", path, e)
        resultados.append(ResumenArchivo(path.name, "ERROR", "ERROR", 0, "", error=f"{e}\n{traceback.format_exc()[-1000:]}"))
    return resultados


# ---------------------------------------------------------------------------
# Punto de entrada de la corrida completa
# ---------------------------------------------------------------------------

def ejecutar(source_dir: Optional[Path] = None, dry_run: Optional[bool] = None,
             max_paginas_pdf: Optional[int] = None) -> ResumenRun:
    source_dir = source_dir or config.SOURCE_DIR
    dry_run = config.DRY_RUN if dry_run is None else dry_run
    work_dir = config.WORK_DIR
    work_dir.mkdir(parents=True, exist_ok=True)

    persist = Persistencia(dry_run)
    resumen = ResumenRun()

    # Orden: primero archivos "planos", luego variantes _ESTRUCTURADO (para
    # que, al hacer upsert por clave de ley, la versión estructurada quede
    # como definitiva al ser la última en escribirse).
    archivos = sorted(
        (p for p in source_dir.rglob("*") if p.is_file() and p.suffix.lower() in config.EXTENSIONES_SOPORTADAS),
        key=lambda p: ("ESTRUCTURADO" in p.name.upper(), p.name.lower()),
    )

    for path in archivos:
        for r in procesar_archivo(path, persist, dry_run, work_dir, max_paginas_pdf):
            resumen.total_archivos += 1
            resumen.por_tipo[r.tipo_detectado] += 1
            resumen.registros_totales += r.registros
            resumen.resultados.append(r)
            if r.estado == "PROCESADO":
                resumen.ok += 1
            elif r.estado == "PARCIAL":
                resumen.parcial += 1
            elif r.estado == "ERROR":
                resumen.error += 1
            else:
                resumen.omitidos += 1
            log.info("[%s] %-22s %-18s registros=%-5d %s", r.estado, r.archivo[:50], r.tipo_detectado, r.registros, r.error[:80])

    return resumen
