"""
etl/classify.py — Clasificador de archivos fuente.

Determina, para cada archivo del ZIP de insumos, qué estrategia de
ingestión aplicar. La clasificación combina: extensión, nombre de archivo
(patrones conocidos) y, para .txt, una inspección ligera del contenido
(texto legal limpio vs. catálogo OCR con artefactos de marca de agua).

Categorías (tipo_detectado):
  CATALOGO_PDF_NATIVO      -> parsers.catalogos_pdf_nativo (PDF nativo/MD/TXT de una familia editorial conocida:
                              SICT/CMIC/CFE/CONAGUA/CDMX/CEICO/salarios/maquinaria — máxima prioridad de
                              clasificación porque la extracción es de mucha mayor confianza que las rutas genéricas)
  LEY_TXT                  -> parsers.leyes
  CATALOGO_XLSX_LIMPIO     -> parsers.catalogos_excel (ya extraído, columnas tabulares limpias)
  CATALOGO_OCR_TXT         -> parsers.catalogos_ocr_txt (texto de catálogo CMIC con OCR degradado)
  REFERENCIA_PDF           -> parsers.referencias_pdf (libros/manuales/informes)
  REFERENCIA_MD_TABLAS     -> parsers.referencias_md (catálogos genéricos clave/valor en markdown)
  REFERENCIA_MD_NARRATIVA  -> parsers.referencias_md (texto narrativo normativo)
  REFERENCIA_DOCX          -> parsers.referencias_docx (tablas de costo paramétrico / texto)
  LEGACY_XLS               -> parsers.legacy_office -> reclasifica como CATALOGO_XLSX_LIMPIO
  LEGACY_DOC               -> parsers.legacy_office -> reclasifica como REFERENCIA_DOCX
  ZIP_ANIDADO              -> parsers.nested_zip (recursivo)
  OMITIDO                  -> binarios no soportados (imágenes sueltas, etc.)
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path

from .parsers.catalogos_pdf_nativo import fuente_para_archivo

# Extensiones para las que tiene sentido buscar un patrón de familia editorial
# conocida. xlsx/xls/docx ya tienen su propia ruta limpia y NUNCA deben pasar
# por aquí (evita intentar correr pdftotext/OCR sobre un spreadsheet).
_EXTENSIONES_CATALOGO_NATIVO = {".pdf", ".md", ".txt"}

# Nombres/patrones de leyes y reglamentos conocidos (texto limpio, no OCR)
_PATRONES_LEY = [
    r"LOPSRM", r"LAASSP", r"^LGA\b", r"LGA[._]", r"LGPDPPSO", r"Ley_de_Fiscalizacion",
    r"Reg_LOPSRM", r"Reg_LAASSP", r"RLAASSP", r"Ley-de-Contratacion-Publica",
    r"Ley.*Obras.*Publicas.*Tlaxcala", r"^Ley\b", r"^Reglamento\b",
]
_PATRONES_LEY_RE = re.compile("|".join(_PATRONES_LEY), re.IGNORECASE)

# Marcadores típicos de OCR degradado de catálogos CMIC/CEICO (marca de agua vertical)
_OCR_WATERMARK_RE = re.compile(r"(?:\n\s*[A-Za-zÁÉÍÓÚÑáéíóúñ]\s*){4,}\n")


@dataclass
class Clasificacion:
    tipo_detectado: str
    categoria_documental: str  # para documentos_referencia.categoria
    confianza: str = "ALTA"
    motivo: str = ""


def _peek_text(path: Path, max_bytes: int = 8000) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(max_bytes)
    except Exception:
        return ""


def _peek_md_has_table(path: Path, max_bytes: int = 20000) -> bool:
    txt = _peek_text(path, max_bytes)
    return bool(re.search(r"^\|.+\|.*\n\|[-:| ]+\|", txt, re.MULTILINE))


def clasificar(path: Path) -> Clasificacion:
    ext = path.suffix.lower()
    name = path.name

    if ext in _EXTENSIONES_CATALOGO_NATIVO:
        cfg = fuente_para_archivo(name)
        if cfg:
            return Clasificacion("CATALOGO_PDF_NATIVO", "COSTOS", "ALTA",
                                  f"Coincide con familia editorial conocida: {cfg.get('fuente')} / {cfg.get('codigo_fuente', cfg.get('nombre_catalogo'))}")

    if ext == ".zip":
        return Clasificacion("ZIP_ANIDADO", "OTRO", "ALTA", "Archivo zip anidado: se extrae y reclasifica recursivamente")

    if ext == ".txt":
        if _PATRONES_LEY_RE.search(name):
            return Clasificacion("LEY_TXT", "NORMATIVA", "ALTA", "Nombre coincide con patrón de ley/reglamento")
        sample = _peek_text(path, 6000)
        if _OCR_WATERMARK_RE.search(sample):
            return Clasificacion("CATALOGO_OCR_TXT", "COSTOS", "BAJA",
                                  "Se detectó patrón de marca de agua vertical típico de OCR de catálogo CMIC/CEICO")
        # heurística adicional: requiere VARIOS artículos numerados distintos (no solo una cita
        # aislada a "Artículo 1") para evitar falsos positivos en documentos técnicos que solo
        # mencionan un artículo de pasada (ej. definiciones de metrados, manuales de cuantificación)
        articulos_distintos = {m.group(1) for m in re.finditer(r"Art[íi]culo\s+(\d+)\b", sample)}
        if len(articulos_distintos) >= 4:
            return Clasificacion("LEY_TXT", "NORMATIVA", "MEDIA",
                                  "Contiene múltiples 'Artículo N' distintos aunque el nombre no coincide con patrón de ley")
        return Clasificacion("CATALOGO_OCR_TXT", "COSTOS", "MEDIA", "Archivo txt de catálogo sin marca de agua detectada, tratado como OCR por defecto")

    if ext == ".md":
        if _peek_md_has_table(path):
            return Clasificacion("REFERENCIA_MD_TABLAS", "SECTORIAL", "ALTA", "Markdown con tablas clave/descripción")
        return Clasificacion("REFERENCIA_MD_NARRATIVA", "NORMATIVA", "ALTA", "Markdown narrativo")

    if ext == ".xlsx":
        return Clasificacion("CATALOGO_XLSX_LIMPIO", "COSTOS", "ALTA", "Spreadsheet xlsx")

    if ext == ".xls":
        return Clasificacion("LEGACY_XLS", "COSTOS", "MEDIA", "Excel legado .xls, requiere conversión vía LibreOffice")

    if ext == ".docx":
        return Clasificacion("REFERENCIA_DOCX", "COSTOS", "ALTA", "Documento Word moderno")

    if ext == ".doc":
        return Clasificacion("LEGACY_DOC", "FORMULARIOS", "MEDIA", "Word legado .doc, requiere conversión vía LibreOffice")

    if ext == ".pdf":
        categoria = "COSTOS" if re.search(r"catalogo|costo|precio|tabulador|tcd_cons|tcmaquinaria|tcparametricos|tservicio", name, re.IGNORECASE) else \
                    "NORMATIVA" if re.search(r"ley|reglamento|lineamiento|anexo|rmf|fiscaliz", name, re.IGNORECASE) else \
                    "LICITACIONES" if re.search(r"licitacion|dictamen|pemex", name, re.IGNORECASE) else \
                    "GEOTECNIA" if re.search(r"geotecnia|suelos|geofisica|cimentacion", name, re.IGNORECASE) else \
                    "TOPOGRAFIA" if re.search(r"topograf", name, re.IGNORECASE) else \
                    "ESTRUCTURAS" if re.search(r"estructura|matricial|cimbra", name, re.IGNORECASE) else "OTRO"
        return Clasificacion("REFERENCIA_PDF", categoria, "MEDIA", "PDF: se extrae texto; calidad depende de si el PDF es nativo u OCR")

    return Clasificacion("OMITIDO", "OTRO", "BAJA", f"Extensión no soportada: {ext}")
