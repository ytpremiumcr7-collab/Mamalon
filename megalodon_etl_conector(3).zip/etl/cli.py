"""
etl/cli.py — punto de entrada de línea de comandos del ETL.

Uso:
    # Carga real a PostgreSQL (requiere DATABASE_URL y psycopg2 instalado)
    DATABASE_URL=postgresql://user:pass@host:5432/db \
    ETL_SOURCE_DIR=/ruta/a/txtmd \
    python -m etl.cli

    # Validar el pipeline sin tocar la base de datos (recomendado primero)
    ETL_DRY_RUN=true ETL_SOURCE_DIR=/ruta/a/txtmd python -m etl.cli

    # Limitar a un subconjunto de archivos para pruebas rápidas
    ETL_DRY_RUN=true ETL_SOURCE_DIR=/ruta/a/txtmd python -m etl.cli --solo-tipo LEY_TXT
"""
from __future__ import annotations
import argparse
import json
import logging
import sys
from pathlib import Path

from . import config
from . import pipeline


def main():
    parser = argparse.ArgumentParser(description="ETL Megalodon Costos")
    parser.add_argument("--source", type=str, default=None, help="Carpeta fuente (override de ETL_SOURCE_DIR)")
    parser.add_argument("--dry-run", action="store_true", help="No escribe en la base de datos, solo reporta")
    parser.add_argument("--reporte", type=str, default=None, help="Ruta de archivo .json para guardar el reporte detallado")
    parser.add_argument("--max-paginas-pdf", type=int, default=None,
                         help="Límite de páginas por PDF (solo para pruebas rápidas; omitir en producción para procesar el PDF completo)")
    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO),
                         format="%(asctime)s %(levelname)-7s %(message)s")

    source_dir = Path(args.source).resolve() if args.source else config.SOURCE_DIR
    dry_run = args.dry_run or config.DRY_RUN

    if not source_dir.exists():
        print(f"❌ La carpeta fuente no existe: {source_dir}")
        sys.exit(1)

    print(f"📂 Fuente: {source_dir}")
    print(f"🧪 Modo: {'DRY-RUN (sin escritura en BD)' if dry_run else 'CARGA REAL A POSTGRESQL'}")
    print("-" * 70)

    resumen = pipeline.ejecutar(source_dir=source_dir, dry_run=dry_run, max_paginas_pdf=args.max_paginas_pdf)

    print("-" * 70)
    print(f"✅ Procesados OK  : {resumen.ok}")
    print(f"🟡 Parciales      : {resumen.parcial}  (extrajeron algo, pero menos de lo esperado — revisar)")
    print(f"❌ Errores        : {resumen.error}")
    print(f"⏭️  Omitidos      : {resumen.omitidos}")
    print(f"📊 Registros tot. : {resumen.registros_totales}")
    print("Por tipo de archivo:")
    for tipo, n in resumen.por_tipo.most_common():
        print(f"   {tipo:25s} {n}")

    if args.reporte:
        data = {
            "total_archivos": resumen.total_archivos,
            "ok": resumen.ok,
            "parcial": resumen.parcial,
            "error": resumen.error,
            "omitidos": resumen.omitidos,
            "registros_totales": resumen.registros_totales,
            "por_tipo": dict(resumen.por_tipo),
            "detalle": [
                {"archivo": r.archivo, "tipo": r.tipo_detectado, "estado": r.estado,
                 "registros": r.registros, "confianza": r.confianza, "error": r.error, **r.detalle}
                for r in resumen.resultados
            ],
        }
        Path(args.reporte).write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        print(f"📄 Reporte detallado guardado en: {args.reporte}")

    parciales = [r for r in resumen.resultados if r.estado == "PARCIAL"]
    if parciales:
        print(f"\n🟡 {len(parciales)} archivo(s) con extracción PARCIAL (revisar manualmente):")
        for r in parciales[:30]:
            motivo = r.detalle.get("advertencia") or r.detalle.get("fallback_de") or ""
            print(f"   - {r.archivo} ({r.registros} registros) {motivo}")

    errores = [r for r in resumen.resultados if r.estado == "ERROR"]
    if errores:
        print(f"\n⚠️  {len(errores)} archivo(s) con error:")
        for r in errores[:20]:
            print(f"   - {r.archivo}: {r.error.splitlines()[0] if r.error else ''}")
        sys.exit(2)


if __name__ == "__main__":
    main()
