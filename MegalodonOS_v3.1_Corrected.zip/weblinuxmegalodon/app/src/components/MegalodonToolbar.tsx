import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Hammer, Building2, Mountain, Calculator, Dices,
  FileSpreadsheet, Scale, TrendingUp, FlaskConical,
  ArrowLeftRight, Table2, Activity, Download, X, GripVertical
} from 'lucide-react';
import { useWindowManager } from '@/stores/useWindowManager';

interface ToolbarTool {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
  appId: string;
  color: string;
}

const DEFAULT_TOOLS: ToolbarTool[] = [
  { id: 'megalodon-costos', name: 'Megalodon CostOS', icon: Hammer, appId: 'megalodon-costos', color: '#C9A84C' },
  { id: 'bim-calculator', name: 'Calculadora BIM', icon: Building2, appId: 'bim-calculator', color: '#5A9E6F' },
  { id: 'topography', name: 'Topografia', icon: Mountain, appId: 'topography', color: '#8B6914' },
  { id: 'calculator', name: 'Calculadora', icon: Calculator, appId: 'calculator', color: '#5A8AB8' },
  { id: 'monte-carlo', name: 'Monte Carlo', icon: Dices, appId: 'monte-carlo', color: '#B84A4A' },
  { id: 'spreadsheet', name: 'Hoja de Calculo', icon: FileSpreadsheet, appId: 'spreadsheet', color: '#7B6FB8' },
  { id: 'scientific-calc', name: 'Calculadora Cientifica', icon: FlaskConical, appId: 'scientific-calc', color: '#D4953A' },
  { id: 'unit-converter', name: 'Conversor de Unidades', icon: ArrowLeftRight, appId: 'unit-converter', color: '#6AAF7F' },
  { id: 'graphing-calc', name: 'Calculadora Grafica', icon: TrendingUp, appId: 'graphing-calc', color: '#C9A84C' },
  { id: 'periodic-table', name: 'Tabla Periodica', icon: Table2, appId: 'periodic-table', color: '#5A9E6F' },
  { id: 'system-monitor', name: 'Monitor de Sistema', icon: Activity, appId: 'system-monitor', color: '#5A8AB8' },
];

export default function MegalodonToolbar() {
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [hoverTimeout, setHoverTimeout] = useState<ReturnType<typeof setTimeout> | null>(null);
  const [tools, setTools] = useState<ToolbarTool[]>(DEFAULT_TOOLS);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const toolbarRef = useRef<HTMLDivElement>(null);
  const openWindow = useWindowManager(s => s.openWindow);

  // Persist tool order
  useEffect(() => {
    const saved = localStorage.getItem('megalodon-toolbar-order');
    if (saved) {
      try {
        const order = JSON.parse(saved) as string[];
        const ordered = order.map(id => DEFAULT_TOOLS.find(t => t.id === id)).filter(Boolean) as ToolbarTool[];
        const remaining = DEFAULT_TOOLS.filter(t => !order.includes(t.id));
        setTools([...ordered, ...remaining]);
      } catch { /* ignore */ }
    }
  }, []);

  const saveOrder = useCallback((newTools: ToolbarTool[]) => {
    setTools(newTools);
    localStorage.setItem('megalodon-toolbar-order', JSON.stringify(newTools.map(t => t.id)));
  }, []);

  const handleMouseEnter = useCallback(() => {
    if (hoverTimeout) clearTimeout(hoverTimeout);
    setIsVisible(true);
    setIsExpanded(true);
  }, [hoverTimeout]);

  const handleMouseLeave = useCallback(() => {
    const timeout = setTimeout(() => {
      setIsVisible(false);
      setIsExpanded(false);
    }, 800);
    setHoverTimeout(timeout);
  }, []);

  const handleToolClick = useCallback((appId: string) => {
    const tool = tools.find(t => t.appId === appId);
    if (tool) {
      openWindow(appId, tool.name, { width: 900, height: 600 }, { width: 400, height: 300 });
    }
  }, [openWindow, tools]);

  // Drag and drop handlers
  const handleDragStart = useCallback((index: number) => {
    if (!isEditMode) return;
    setDraggedIndex(index);
  }, [isEditMode]);

  const handleDragOver = useCallback((e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;
    const newTools = [...tools];
    const [removed] = newTools.splice(draggedIndex, 1);
    newTools.splice(index, 0, removed);
    setDraggedIndex(index);
    saveOrder(newTools);
  }, [draggedIndex, tools, saveOrder]);

  const handleDragEnd = useCallback(() => {
    setDraggedIndex(null);
  }, []);

  return (
    <>
      {/* Hover trigger zone - thin strip at top */}
      <div
        className="fixed top-0 left-0 right-0 h-1 z-[49999]"
        onMouseEnter={handleMouseEnter}
      />

      <AnimatePresence>
        {isVisible && (
          <motion.div
            ref={toolbarRef}
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -80, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            className="fixed top-3 left-1/2 -translate-x-1/2 z-[50001]"
          >
            <div
              className="flex items-center gap-1 px-2 py-2 rounded-xl"
              style={{
                background: 'rgba(10,10,15,0.95)',
                backdropFilter: 'blur(20px) saturate(1.2)',
                border: '1px solid #2A2A3E',
                boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
              }}
            >
              {/* Edit mode toggle */}
              <button
                onClick={() => setIsEditMode(!isEditMode)}
                className={`w-7 h-7 flex items-center justify-center rounded-lg transition-all mr-1 ${
                  isEditMode ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'text-[#4D4A42] hover:text-[#8A8578]'
                }`}
                title={isEditMode ? 'Listo' : 'Mover herramientas'}
              >
                {isEditMode ? <X size={14} /> : <GripVertical size={14} />}
              </button>

              <div className="w-px h-6 bg-[#2A2A3E] mx-1" />

              {/* Tools */}
              {tools.map((tool, index) => {
                const Icon = tool.icon;
                return (
                  <motion.button
                    key={tool.id}
                    draggable={isEditMode}
                    onDragStart={() => handleDragStart(index)}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDragEnd={handleDragEnd}
                    onClick={() => !isEditMode && handleToolClick(tool.appId)}
                    whileHover={{ scale: isEditMode ? 1 : 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className={`relative w-9 h-9 flex items-center justify-center rounded-lg transition-all group ${
                      isEditMode ? 'cursor-move bg-[#1A1A26] border border-dashed border-[#2A2A3E]' : 'hover:bg-[#1A1A26] cursor-pointer'
                    }`}
                    title={isEditMode ? `Arrastra: ${tool.name}` : tool.name}
                  >
                    <Icon
                      size={18}
                      className="transition-colors"
                      style={{ color: tool.color }}
                    />
                    {/* Tooltip */}
                    {!isEditMode && (
                      <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-[#1A1A26] text-[10px] text-[#E8E4DC] rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none border border-[#2A2A3E] z-50">
                        {tool.name}
                      </span>
                    )}
                    {isEditMode && (
                      <span className="absolute -top-1 -right-1 w-3 h-3 bg-[#C9A84C] rounded-full flex items-center justify-center">
                        <span className="text-[6px] text-[#030305] font-bold">{index + 1}</span>
                      </span>
                    )}
                  </motion.button>
                );
              })}

              <div className="w-px h-6 bg-[#2A2A3E] mx-1" />

              {/* Quick actions */}
              <button
                onClick={() => handleToolClick('megalodon-costos')}
                className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#1A1A26] transition-colors group"
                title="Abrir Megalodon CostOS"
              >
                <Download size={16} className="text-[#5A9E6F]" />
                <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-[#1A1A26] text-[10px] text-[#E8E4DC] rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none border border-[#2A2A3E] z-50">
                  Abrir Megalodon
                </span>
              </button>
            </div>

            {/* Subtle hint when in edit mode */}
            {isEditMode && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center text-[10px] text-[#8A8578] mt-2 bg-[#0A0A0F]/80 px-3 py-1 rounded-full mx-auto w-fit"
              >
                Arrastra las herramientas para reordenarlas
              </motion.p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
