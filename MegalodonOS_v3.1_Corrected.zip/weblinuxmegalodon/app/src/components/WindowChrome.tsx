import { useRef, useCallback, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Minus, Square, X } from 'lucide-react';
import { useWindowManager } from '@/stores/useWindowManager';

interface WindowChromeProps {
  windowId: string;
  appId: string;
  title: string;
  icon: string;
  children: React.ReactNode;
  isActive: boolean;
  initialX: number;
  initialY: number;
  width: number;
  height: number;
  minWidth?: number;
  minHeight?: number;
  isMaximized: boolean;
  isMinimized: boolean;
}

const APP_ICONS: Record<string, string> = {
  'file-manager': '\u{1F4C1}',
  'terminal': '>$_',
  'text-editor': '\u{1F4DD}',
  'system-monitor': '\u{1F4CA}',
  'settings': '\u2699',
  'calculator': '\u{1F5A9}',
  'calendar': '\u{1F4C5}',
  'clock': '\u23F0',
  'trash': '\u{1F5D1}',
  'megalodon-costos': '\u{1F528}',
  'star-map': '\u2728',
  'code-editor': '\u{1F4BB}',
  'spreadsheet': '\u{1F4C8}',
};

export default function WindowChrome({
  windowId,
  appId,
  title,
  isActive,
  children,
  initialX,
  initialY,
  width,
  height,
  minWidth = 320,
  minHeight = 200,
  isMaximized,
  isMinimized,
}: WindowChromeProps) {
  const { focusWindow, closeWindow, minimizeWindow, maximizeWindow, restoreWindow, setWindowPosition, setWindowSize, windows } = useWindowManager();
  const dragRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, winX: 0, winY: 0 });
  const resizeStart = useRef({ x: 0, y: 0, w: width, h: height });
  const [pos, setPos] = useState({ x: initialX, y: initialY });
  const [size, setSize] = useState({ w: width, h: height });

  // Sync with store when not dragging/resizing
  useEffect(() => {
    const w = windows.find(wd => wd.id === windowId);
    if (w && !isDragging && !isResizing) {
      setPos({ x: w.x, y: w.y });
      setSize({ w: w.width, h: w.height });
    }
  }, [windows, windowId, isDragging, isResizing]);

  const handleMouseDown = useCallback(() => {
    focusWindow(windowId);
  }, [focusWindow, windowId]);

  // Get pointer position from mouse or touch event
  const getPointerPos = useCallback((e: MouseEvent | TouchEvent): { clientX: number; clientY: number } => {
    if ('touches' in e) {
      return { clientX: e.touches[0]?.clientX ?? 0, clientY: e.touches[0]?.clientY ?? 0 };
    }
    return { clientX: e.clientX, clientY: e.clientY };
  }, []);

  const handleDragStart = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (isMaximized) return;
    e.preventDefault();
    setIsDragging(true);
    const clientX = 'touches' in e ? e.touches[0]?.clientX ?? 0 : e.clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY ?? 0 : e.clientY;
    dragStart.current = { x: clientX, y: clientY, winX: pos.x, winY: pos.y };
  }, [isMaximized, pos.x, pos.y]);

  const handleResizeStart = useCallback((e: React.MouseEvent | React.TouchEvent, corner: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    const clientX = 'touches' in e ? e.touches[0]?.clientX ?? 0 : e.clientX;
    const clientY = 'touches' in e ? e.touches[0]?.clientY ?? 0 : e.clientY;
    resizeStart.current = { x: clientX, y: clientY, w: size.w, h: size.h };
    (e.target as HTMLElement).dataset.resizeCorner = corner;
  }, [size.w, size.h]);

  useEffect(() => {
    if (!isDragging && !isResizing) return;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const { clientX, clientY } = getPointerPos(e);
      if (isDragging) {
        const dx = clientX - dragStart.current.x;
        const dy = clientY - dragStart.current.y;
        const newX = Math.max(-size.w + 80, Math.min(window.innerWidth - 40, dragStart.current.winX + dx));
        const newY = Math.max(0, Math.min(window.innerHeight - 60, dragStart.current.winY + dy));
        setPos({ x: newX, y: newY });
      }
      if (isResizing) {
        const dx = clientX - resizeStart.current.x;
        const dy = clientY - resizeStart.current.y;
        const newW = Math.max(minWidth, resizeStart.current.w + dx);
        const newH = Math.max(minHeight, resizeStart.current.h + dy);
        setSize({ w: newW, h: newH });
      }
    };

    const handlePointerUp = () => {
      if (isDragging) {
        setIsDragging(false);
        setWindowPosition(windowId, pos.x, pos.y);
      }
      if (isResizing) {
        setIsResizing(false);
        setWindowSize(windowId, size.w, size.h);
      }
    };

    // Mouse events
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    // Touch events
    window.addEventListener('touchmove', handlePointerMove, { passive: false });
    window.addEventListener('touchend', handlePointerUp);
    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
    };
  }, [isDragging, isResizing, size.w, size.h, pos.x, pos.y, minWidth, minHeight, windowId, setWindowPosition, setWindowSize, getPointerPos]);

  if (isMinimized) return null;

  return (
    <motion.div
      initial={{ scale: 0.85, opacity: 0 }}
      animate={{
        scale: 1,
        opacity: 1,
        x: isMaximized ? 0 : pos.x,
        y: isMaximized ? 0 : pos.y,
        width: isMaximized ? window.innerWidth : size.w,
        height: isMaximized ? window.innerHeight - 48 : size.h,
      }}
      exit={{ scale: 0.9, opacity: 0 }}
      transition={{
        duration: 0.3,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      }}
      onMouseDown={handleMouseDown}
      className="absolute flex flex-col rounded-lg overflow-hidden"
      style={{
        zIndex: windows.find(w => w.id === windowId)?.zIndex ?? 100,
        boxShadow: isActive ? 'var(--shadow-window-active)' : 'var(--shadow-window)',
        border: isActive ? '1px solid rgba(201,168,76,0.3)' : '1px solid var(--border-subtle)',
        opacity: isActive ? 1 : 0.9,
        filter: isActive ? 'none' : 'brightness(0.95)',
      }}
    >
      {/* Title bar */}
      <div
        ref={dragRef}
        onMouseDown={handleDragStart}
        onTouchStart={handleDragStart}
        className="h-9 flex items-center justify-between px-3 select-none cursor-grab active:cursor-grabbing touch-none"
        style={{ background: isActive ? '#1A1A26' : '#12121A' }}
      >
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="text-sm">{APP_ICONS[appId] || '\u{1F4E6}'}</span>
          <span className={`text-xs font-medium truncate max-w-[200px] ${isActive ? 'text-[#E8E4DC]' : 'text-[#8A8578]'}`}>
            {title}
          </span>
        </div>
        <div className="flex items-center gap-0.5">
          <button
            onClick={(e) => { e.stopPropagation(); minimizeWindow(windowId); }}
            className="w-7 h-7 flex items-center justify-center rounded hover:bg-[#2A2A3E] transition-colors text-[#8A8578] hover:text-[#E8E4DC]"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); isMaximized ? restoreWindow(windowId) : maximizeWindow(windowId); }}
            className="w-7 h-7 flex items-center justify-center rounded hover:bg-[#2A2A3E] transition-colors text-[#8A8578] hover:text-[#E8E4DC]"
          >
            <Square className="w-3 h-3" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); closeWindow(windowId); }}
            className="w-7 h-7 flex items-center justify-center rounded hover:bg-[#B84A4A] transition-colors text-[#8A8578] hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Window body */}
      <div className="flex-1 overflow-hidden relative"
        style={{
          background: 'var(--glass-bg-heavy)',
          backdropFilter: 'var(--backdrop-blur)',
        }}
      >
        {children}
      </div>

      {/* Resize handles */}
      {!isMaximized && (
        <>
          <div onMouseDown={(e) => handleResizeStart(e, 'se')} onTouchStart={(e) => handleResizeStart(e, 'se')} className="absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize z-10 touch-none" />
          <div onMouseDown={(e) => handleResizeStart(e, 'e')} onTouchStart={(e) => handleResizeStart(e, 'e')} className="absolute top-9 right-0 bottom-4 w-2 cursor-ew-resize z-10 touch-none" />
          <div onMouseDown={(e) => handleResizeStart(e, 's')} onTouchStart={(e) => handleResizeStart(e, 's')} className="absolute left-0 right-4 bottom-0 h-2 cursor-ns-resize z-10 touch-none" />
        </>
      )}
    </motion.div>
  );
}
