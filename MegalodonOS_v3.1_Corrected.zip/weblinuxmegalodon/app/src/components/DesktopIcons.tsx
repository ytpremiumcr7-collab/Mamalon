import { motion } from 'framer-motion';
import * as Icons from 'lucide-react';
import { useDesktopStore } from '@/stores/useDesktopStore';
import { useAppRegistry } from '@/stores/useAppRegistry';
import { useWindowManager } from '@/stores/useWindowManager';

const DEFAULT_ICONS = [
  { appId: 'file-manager', label: 'Home', x: 16, y: 16 },
  { appId: 'megalodon-costos', label: 'Megalodon', x: 16, y: 112 },
  { appId: 'star-map', label: 'Star Map', x: 16, y: 208 },
  { appId: 'terminal', label: 'Terminal', x: 16, y: 304 },
  { appId: 'text-editor', label: 'Text Editor', x: 16, y: 400 },
  { appId: 'settings', label: 'Settings', x: 120, y: 16 },
  { appId: 'calculator', label: 'Calculator', x: 120, y: 112 },
  { appId: 'calendar', label: 'Calendar', x: 120, y: 208 },
  { appId: 'system-monitor', label: 'System', x: 120, y: 304 },
  { appId: 'trash', label: 'Trash', x: 120, y: 400 },
  { appId: 'snake', label: 'Games', x: 224, y: 16 },
  { appId: 'web-browser', label: 'Browser', x: 224, y: 112 },
];

// Map app IDs to lucide icons
const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  'file-manager': Icons.FolderOpen,
  'megalodon-costos': Icons.Hammer,
  'star-map': Icons.Star,
  'terminal': Icons.Terminal,
  'text-editor': Icons.FileText,
  'settings': Icons.Settings,
  'calculator': Icons.Calculator,
  'calendar': Icons.Calendar,
  'system-monitor': Icons.Activity,
  'trash': Icons.Trash2,
  'snake': Icons.Gamepad2,
  'web-browser': Icons.Globe,
};

export default function DesktopIcons() {
  const { selectedIconId, setSelectedIconId } = useDesktopStore();
  const { getApp } = useAppRegistry();
  const openWindow = useWindowManager(s => s.openWindow);

  const handleIconClick = (appId: string) => {
    setSelectedIconId(appId);
  };

  const handleIconDoubleClick = (appId: string) => {
    const app = getApp(appId);
    if (app) {
      openWindow(appId, app.name, app.defaultSize, app.minSize);
    }
  };

  return (
    <div className="absolute inset-0" style={{ zIndex: 'var(--z-desktop-icons)' }}>
      {DEFAULT_ICONS.map((icon, index) => {
        const IconComponent = ICON_MAP[icon.appId] || Icons.AppWindow;
        const isSelected = selectedIconId === icon.appId;

        return (
          <motion.div
            key={icon.appId}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              delay: index * 0.05,
              duration: 0.3,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            onClick={(e) => { e.stopPropagation(); handleIconClick(icon.appId); }}
            onDoubleClick={(e) => { e.stopPropagation(); handleIconDoubleClick(icon.appId); }}
            className="absolute flex flex-col items-center gap-1 cursor-pointer group w-[84px]"
            style={{ left: icon.x, top: icon.y }}
          >
            <motion.div
              whileHover={{ scale: 1.08 }}
              transition={{ duration: 0.15, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
              className={`w-12 h-12 flex items-center justify-center rounded-xl transition-colors ${
                isSelected ? 'scale-105' : ''
              }`}
            >
              <IconComponent className={`w-8 h-8 transition-colors ${
                isSelected ? 'text-[#C9A84C]' : 'text-[#E8E4DC] group-hover:text-[#C9A84C]'
              }`} />
            </motion.div>
            <div className={`text-center px-1.5 py-0.5 rounded text-[11px] leading-tight max-w-[80px] transition-colors ${
              isSelected
                ? 'bg-[rgba(201,168,76,0.15)] text-[#C9A84C]'
                : 'text-[#E8E4DC] group-hover:text-[#C9A84C]'
            }`}
              style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
            >
              <span className="line-clamp-2">{icon.label}</span>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
