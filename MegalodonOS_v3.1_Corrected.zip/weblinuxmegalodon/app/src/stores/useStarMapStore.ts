import { create } from 'zustand';

interface StarMapState {
  cameraPosition: [number, number, number];
  cameraTarget: [number, number, number] | null;
  selectedNode: string | null;
  activeCommunity: string | null;
  visibleCommunities: string[];
  setCameraPosition: (pos: [number, number, number]) => void;
  setCameraTarget: (target: [number, number, number]) => void;
  setSelectedNode: (id: string | null) => void;
  setActiveCommunity: (id: string | null) => void;
  toggleCommunity: (id: string) => void;
  resetSelection: () => void;
  resetView: () => void;
}

export const useStarMapStore = create<StarMapState>((set, get) => ({
  cameraPosition: [0, 0, 80],
  cameraTarget: null,
  selectedNode: null,
  activeCommunity: null,
  visibleCommunities: [
    'motor-control',
    'visual-cortex',
    'memory-learning',
    'decision-making',
    'neural-oscillations',
    'computational',
    'clinical',
  ],
  setCameraPosition: (pos) => set({ cameraPosition: pos }),
  setCameraTarget: (target) => set({ cameraTarget: target }),
  setSelectedNode: (id) => set({ selectedNode: id }),
  setActiveCommunity: (id) => set({ activeCommunity: id }),
  toggleCommunity: (id) => {
    const state = get();
    set({
      visibleCommunities: state.visibleCommunities.includes(id)
        ? state.visibleCommunities.filter((c) => c !== id)
        : [...state.visibleCommunities, id],
    });
  },
  resetSelection: () => set({ selectedNode: null, cameraTarget: null }),
  resetView: () => set({ selectedNode: null, cameraTarget: null, activeCommunity: null, cameraPosition: [0, 0, 80] }),
}));
