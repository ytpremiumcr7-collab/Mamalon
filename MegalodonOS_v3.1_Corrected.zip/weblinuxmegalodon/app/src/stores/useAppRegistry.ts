import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppDefinition } from '@/types';

const ALL_APPS: AppDefinition[] = [
  // System
  { id: 'file-manager', name: 'Administrador de Archivos', icon: 'FolderOpen', category: 'system', component: 'FileManager', defaultSize: { width: 900, height: 600 }, minSize: { width: 400, height: 300 }, pinned: true },
  { id: 'terminal', name: 'Terminal', icon: 'Terminal', category: 'system', component: 'Terminal', defaultSize: { width: 700, height: 450 }, minSize: { width: 400, height: 250 }, pinned: true },
  { id: 'text-editor', name: 'Editor de Texto', icon: 'FileText', category: 'system', component: 'TextEditor', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 300 }, pinned: true },
  { id: 'system-monitor', name: 'Monitor de Sistema', icon: 'Activity', category: 'system', component: 'SystemMonitor', defaultSize: { width: 800, height: 550 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'settings', name: 'Configuraci&oacute;n', icon: 'Settings', category: 'system', component: 'Settings', defaultSize: { width: 700, height: 500 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'calculator', name: 'Calculadora', icon: 'Calculator', category: 'system', component: 'Calculator', defaultSize: { width: 340, height: 500 }, minSize: { width: 280, height: 400 }, pinned: true },
  { id: 'calendar', name: 'Calendario', icon: 'Calendar', category: 'system', component: 'Calendar', defaultSize: { width: 500, height: 450 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'clock', name: 'Reloj', icon: 'Clock', category: 'system', component: 'Clock', defaultSize: { width: 320, height: 200 }, minSize: { width: 200, height: 150 }, pinned: false },
  { id: 'trash', name: 'Basura', icon: 'Trash2', category: 'system', component: 'Trash', defaultSize: { width: 600, height: 400 }, minSize: { width: 400, height: 300 }, pinned: false },
  // Productivity
  { id: 'spreadsheet', name: 'Hoja de C&aacute;lculo', icon: 'Table2', category: 'productivity', component: 'Spreadsheet', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'presentation', name: 'Presentaciones', icon: 'Presentation', category: 'productivity', component: 'Presentation', defaultSize: { width: 900, height: 600 }, minSize: { width: 600, height: 450 }, pinned: false },
  { id: 'pdf-viewer', name: 'Visor de PDF', icon: 'FileType', category: 'productivity', component: 'PdfViewer', defaultSize: { width: 800, height: 600 }, minSize: { width: 400, height: 500 }, pinned: false },
  { id: 'notes', name: 'Notas', icon: 'StickyNote', category: 'productivity', component: 'Notes', defaultSize: { width: 500, height: 500 }, minSize: { width: 300, height: 300 }, pinned: false },
  { id: 'task-manager', name: 'Gestor de Tareas', icon: 'CheckSquare', category: 'productivity', component: 'TaskManager', defaultSize: { width: 550, height: 500 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'password-manager', name: 'Gestor de Contrase&ntilde;as', icon: 'KeyRound', category: 'productivity', component: 'PasswordManager', defaultSize: { width: 500, height: 450 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'whiteboard', name: 'Pizarra', icon: 'Pencil', category: 'productivity', component: 'Whiteboard', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Development
  { id: 'code-editor', name: 'Editor de C&oacute;digo', icon: 'Code2', category: 'development', component: 'CodeEditor', defaultSize: { width: 1000, height: 650 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'json-viewer', name: 'Visor de JSON', icon: 'Braces', category: 'development', component: 'JsonViewer', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'regex-tester', name: 'Probador de Regex', icon: 'Search', category: 'development', component: 'RegexTester', defaultSize: { width: 650, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'base64-encoder', name: 'Codificador Base64', icon: 'Hash', category: 'development', component: 'Base64Encoder', defaultSize: { width: 550, height: 450 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'api-client', name: 'Cliente API', icon: 'Globe', category: 'development', component: 'ApiClient', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'color-picker', name: 'Selector de Color', icon: 'Palette', category: 'development', component: 'ColorPicker', defaultSize: { width: 450, height: 400 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'diff-tool', name: 'Comparador de Diff', icon: 'GitCompare', category: 'development', component: 'DiffTool', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'git-dashboard', name: 'Panel de Git', icon: 'GitBranch', category: 'development', component: 'GitDashboard', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Media
  { id: 'image-editor', name: 'Editor de Imagenes', icon: 'Image', category: 'media', component: 'ImageEditor', defaultSize: { width: 900, height: 650 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'music-player', name: 'Reproductor de M&uacute;sica', icon: 'Music', category: 'media', component: 'MusicPlayer', defaultSize: { width: 400, height: 550 }, minSize: { width: 300, height: 400 }, pinned: false },
  { id: 'video-player', name: 'Reproductor de Video', icon: 'PlayCircle', category: 'media', component: 'VideoPlayer', defaultSize: { width: 800, height: 500 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'paint', name: 'Dibujo', icon: 'Paintbrush', category: 'media', component: 'Paint', defaultSize: { width: 800, height: 600 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'svg-editor', name: 'Editor de SVG', icon: 'PenTool', category: 'media', component: 'SvgEditor', defaultSize: { width: 800, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'ascii-art', name: 'Arte ASCII', icon: 'Type', category: 'media', component: 'AsciiArt', defaultSize: { width: 650, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'chart-maker', name: 'Creador de Gr&aacute;ficas', icon: 'BarChart3', category: 'media', component: 'ChartMaker', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Communication
  { id: 'web-browser', name: 'Navegador', icon: 'Globe', category: 'communication', component: 'WebBrowser', defaultSize: { width: 1000, height: 650 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'email-client', name: 'Correo', icon: 'Mail', category: 'communication', component: 'EmailClient', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'chat', name: 'Chat', icon: 'MessageSquare', category: 'communication', component: 'Chat', defaultSize: { width: 500, height: 550 }, minSize: { width: 350, height: 400 }, pinned: false },
  { id: 'rss-reader', name: 'Lector de RSS', icon: 'Rss', category: 'communication', component: 'RssReader', defaultSize: { width: 700, height: 550 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'network-scanner', name: 'Esc&aacute;ner de Red', icon: 'ScanLine', category: 'communication', component: 'NetworkScanner', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  // Science
  { id: 'bim-calculator', name: 'Calculadora BIM', icon: 'Building2', category: 'science', component: 'BimCalculator', defaultSize: { width: 550, height: 450 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'unit-converter', name: 'Conversor de Unidades', icon: 'ArrowLeftRight', category: 'science', component: 'UnitConverter', defaultSize: { width: 450, height: 500 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'scientific-calc', name: 'Calculadora Cient&iacute;fica', icon: 'FlaskConical', category: 'science', component: 'ScientificCalc', defaultSize: { width: 500, height: 550 }, minSize: { width: 350, height: 400 }, pinned: false },
  { id: 'periodic-table', name: 'Tabla Peri&oacute;dica', icon: 'Atom', category: 'science', component: 'PeriodicTable', defaultSize: { width: 900, height: 550 }, minSize: { width: 600, height: 400 }, pinned: false },
  { id: 'graphing-calc', name: 'Calculadora Gr&aacute;fica', icon: 'TrendingUp', category: 'science', component: 'GraphingCalc', defaultSize: { width: 700, height: 550 }, minSize: { width: 450, height: 400 }, pinned: false },
  { id: 'monte-carlo', name: 'Monte Carlo', icon: 'Dices', category: 'science', component: 'MonteCarlo', defaultSize: { width: 700, height: 500 }, minSize: { width: 450, height: 350 }, pinned: false },
  { id: 'topography', name: 'Topograf&iacute;a', icon: 'Mountain', category: 'science', component: 'Topography', defaultSize: { width: 800, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Games
  { id: 'snake', name: 'Serpiente', icon: 'SnakeIcon', category: 'games', component: 'Snake', defaultSize: { width: 500, height: 520 }, minSize: { width: 400, height: 420 }, pinned: false },
  { id: 'tetris', name: 'Tetris', icon: 'Grid3X3', category: 'games', component: 'Tetris', defaultSize: { width: 400, height: 560 }, minSize: { width: 320, height: 480 }, pinned: false },
  { id: 'chess', name: 'Ajedrez', icon: 'Crown', category: 'games', component: 'Chess', defaultSize: { width: 520, height: 560 }, minSize: { width: 400, height: 440 }, pinned: false },
  { id: 'solitaire', name: 'Solitario', icon: 'Layers', category: 'games', component: 'Solitaire', defaultSize: { width: 750, height: 550 }, minSize: { width: 600, height: 450 }, pinned: false },
  { id: 'minesweeper', name: 'Buscaminas', icon: 'Bomb', category: 'games', component: 'Minesweeper', defaultSize: { width: 400, height: 480 }, minSize: { width: 300, height: 380 }, pinned: false },
  // Flagship
  { id: 'megalodon-costos', name: 'Megalodon CostOS', icon: 'Hammer', category: 'flagship', component: 'MegalodonCostos', defaultSize: { width: 1100, height: 700 }, minSize: { width: 600, height: 450 }, pinned: true },
  { id: 'star-map', name: 'Mapa Estelar', icon: 'Star', category: 'flagship', component: 'StarMap', defaultSize: { width: 1000, height: 700 }, minSize: { width: 600, height: 450 }, pinned: true },
];

interface AppRegistryState {
  apps: AppDefinition[];
  getApp: (id: string) => AppDefinition | undefined;
  pinApp: (id: string) => void;
  unpinApp: (id: string) => void;
  getPinnedApps: () => AppDefinition[];
  getAppsByCategory: (category: string) => AppDefinition[];
}

export const useAppRegistry = create<AppRegistryState>()(
  persist(
    (set, get) => ({
      apps: ALL_APPS,
      getApp: (id) => get().apps.find((a) => a.id === id),
      pinApp: (id) => {
        set({
          apps: get().apps.map((a) => (a.id === id ? { ...a, pinned: true } : a)),
        });
      },
      unpinApp: (id) => {
        set({
          apps: get().apps.map((a) => (a.id === id ? { ...a, pinned: false } : a)),
        });
      },
      getPinnedApps: () => get().apps.filter((a) => a.pinned),
      getAppsByCategory: (category) => get().apps.filter((a) => a.category === category),
    }),
    {
      name: 'cornstone-apps',
      partialize: (state) => ({ apps: state.apps.map(a => ({ id: a.id, pinned: a.pinned })) }),
      merge: (persisted, current) => {
        const p = persisted as { apps?: { id: string; pinned: boolean }[] } | undefined;
        const pinnedMap = new Map(p?.apps?.map(a => [a.id, Boolean(a.pinned)]) ?? []);
        return {
          ...current,
          apps: current.apps.map(a => ({
            ...a,
            pinned: pinnedMap.has(a.id) ? pinnedMap.get(a.id)! : a.pinned,
          })),
        };
      },
    }
  )
);

export { ALL_APPS };
