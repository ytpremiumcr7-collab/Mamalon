import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { FileSystemNode } from '@/types';

interface FileSystemState {
  nodes: FileSystemNode[];
  clipboard: FileSystemNode | null;
  clipboardAction: 'copy' | 'cut' | null;
  expandedFolders: string[];
  selectedNodeId: string | null;
  currentPath: string[];

  addNode: (node: Omit<FileSystemNode, 'id' | 'createdAt' | 'modifiedAt'>) => string;
  deleteNode: (id: string) => void;
  renameNode: (id: string, newName: string) => void;
  moveNode: (id: string, newParentId: string | null) => void;
  copyToClipboard: (node: FileSystemNode, action: 'copy' | 'cut') => void;
  pasteFromClipboard: (parentId: string | null) => void;
  toggleFolder: (id: string) => void;
  setSelectedNode: (id: string | null) => void;
  setCurrentPath: (path: string[]) => void;
  getChildren: (parentId: string | null) => FileSystemNode[];
  getNodePath: (nodeId: string) => FileSystemNode[];
}

const DEFAULT_NODES: FileSystemNode[] = [
  { id: 'root-desktop', name: 'Desktop', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'root-documents', name: 'Documents', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'root-downloads', name: 'Downloads', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'root-music', name: 'Music', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'root-pictures', name: 'Pictures', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'root-videos', name: 'Videos', type: 'folder', parentId: null, createdAt: Date.now(), modifiedAt: Date.now() },
  { id: 'file-readme', name: 'README.md', type: 'file', parentId: null, content: '# Welcome to Cornstone OS\n\nYour web-based Linux desktop environment.\n\n## Getting Started\n\nExplore the desktop by double-clicking icons or opening the Start Menu.\n', createdAt: Date.now(), modifiedAt: Date.now(), size: 120 },
];

export const useFileSystem = create<FileSystemState>()(
  persist(
    (set, get) => ({
      nodes: DEFAULT_NODES,
      clipboard: null,
      clipboardAction: null,
      expandedFolders: ['root-desktop', 'root-documents'],
      selectedNodeId: null,
      currentPath: [],

      addNode: (node) => {
        const id = `fs-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
        const newNode: FileSystemNode = {
          ...node,
          id,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        };
        set({ nodes: [...get().nodes, newNode] });
        return id;
      },

      deleteNode: (id) => {
        const state = get();
        const toDelete = [id];
        const collectChildren = (parentId: string) => {
          state.nodes.forEach((n) => {
            if (n.parentId === parentId) {
              toDelete.push(n.id);
              if (n.type === 'folder') collectChildren(n.id);
            }
          });
        };
        collectChildren(id);
        set({ nodes: state.nodes.filter((n) => !toDelete.includes(n.id)) });
      },

      renameNode: (id, newName) => {
        set({
          nodes: get().nodes.map((n) =>
            n.id === id ? { ...n, name: newName, modifiedAt: Date.now() } : n
          ),
        });
      },

      moveNode: (id, newParentId) => {
        set({
          nodes: get().nodes.map((n) =>
            n.id === id ? { ...n, parentId: newParentId, modifiedAt: Date.now() } : n
          ),
        });
      },

      copyToClipboard: (node, action) => {
        set({ clipboard: { ...node }, clipboardAction: action });
      },

      pasteFromClipboard: (parentId) => {
        const state = get();
        if (!state.clipboard) return;
        const id = `fs-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
        const newNode: FileSystemNode = {
          ...state.clipboard,
          id,
          name: state.clipboardAction === 'copy' ? `${state.clipboard.name} (copy)` : state.clipboard.name,
          parentId,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        };
        set({ nodes: [...state.nodes, newNode] });
        if (state.clipboardAction === 'cut') {
          set({ clipboard: null, clipboardAction: null });
        }
      },

      toggleFolder: (id) => {
        const state = get();
        set({
          expandedFolders: state.expandedFolders.includes(id)
            ? state.expandedFolders.filter((f) => f !== id)
            : [...state.expandedFolders, id],
        });
      },

      setSelectedNode: (id) => set({ selectedNodeId: id }),
      setCurrentPath: (path) => set({ currentPath: path }),

      getChildren: (parentId) => {
        return get().nodes.filter((n) => n.parentId === parentId);
      },

      getNodePath: (nodeId) => {
        const state = get();
        const path: FileSystemNode[] = [];
        let current = state.nodes.find((n) => n.id === nodeId);
        while (current) {
          path.unshift(current);
          if (current.parentId) {
            current = state.nodes.find((n) => n.id === current!.parentId);
          } else {
            break;
          }
        }
        return path;
      },
    }),
    {
      name: 'cornstone-filesystem',
      partialize: (state) => ({
        nodes: state.nodes,
        expandedFolders: state.expandedFolders,
      }),
    }
  )
);
