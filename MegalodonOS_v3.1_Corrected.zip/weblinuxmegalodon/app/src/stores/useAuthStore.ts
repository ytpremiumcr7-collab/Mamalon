import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isBootComplete: boolean;
  login: (username: string, _password?: string) => void;
  logout: () => void;
  setBootComplete: (complete: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isBootComplete: false,
      login: (username, password) => {
        // Validación básica - en producción esto irá contra el backend
        if (!username || username.trim().length < 2) {
          throw new Error('El usuario debe tener al menos 2 caracteres');
        }
        const user: User = {
          id: `user-${Date.now()}`,
          name: username === 'Invitado' ? 'Usuario Invitado' : username,
          username: username || 'usuario',
          isGuest: username === 'Invitado',
        };
        set({ user, isAuthenticated: true, isBootComplete: false });
      },
      logout: () => {
        set({ user: null, isAuthenticated: false, isBootComplete: false });
      },
      setBootComplete: (complete) => set({ isBootComplete: complete }),
    }),
    {
      name: 'megalodon-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
