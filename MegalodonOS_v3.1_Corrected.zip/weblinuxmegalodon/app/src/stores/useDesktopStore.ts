import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
}

interface DesktopState {
  wallpaper: string;
  selectedIconId: string | null;
  iconPositions: Record<string, { x: number; y: number }>;
  contextMenu: ContextMenuState;
  setWallpaper: (wallpaper: string) => void;
  setSelectedIconId: (id: string | null) => void;
  setContextMenu: (menu: ContextMenuState) => void;
  setIconPosition: (id: string, x: number, y: number) => void;
}

// Responsive desktop icon positioning
const DEFAULT_DESKTOP_ICONS = [
  'file-manager', 'megalodon-costos', 'star-map', 'terminal', 'text-editor',
  'settings', 'calculator', 'calendar', 'system-monitor', 'trash',
  'snake', 'web-browser',
];

function getResponsivePositions(): Record<string, { x: number; y: number }> {
  const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
  const isMobile = vw < 768;
  const iconSpacingX = isMobile ? 72 : 100;
  const iconSpacingY = isMobile ? 80 : 96;
  const iconsPerColumn = isMobile ? 5 : 6;
  const maxColumns = isMobile ? 2 : 3;

  const positions: Record<string, { x: number; y: number }> = {};
  DEFAULT_DESKTOP_ICONS.forEach((id, i) => {
    const col = Math.floor(i / iconsPerColumn);
    const row = i % iconsPerColumn;
    // Clamp to max columns to prevent overflow
    const safeCol = Math.min(col, maxColumns - 1);
    positions[id] = {
      x: 16 + safeCol * iconSpacingX,
      y: 16 + row * iconSpacingY,
    };
  });
  return positions;
}

const DEFAULT_POSITIONS: Record<string, { x: number; y: number }> = getResponsivePositions();

export const useDesktopStore = create<DesktopState>()(
  persist(
    (set) => ({
      wallpaper: '/desktop-bg.jpg',
      selectedIconId: null,
      iconPositions: DEFAULT_POSITIONS,
      contextMenu: { visible: false, x: 0, y: 0 },
      setWallpaper: (wallpaper) => set({ wallpaper }),
      setSelectedIconId: (id) => set({ selectedIconId: id }),
      setContextMenu: (menu) => set({ contextMenu: menu }),
      setIconPosition: (id, x, y) =>
        set((state) => ({
          iconPositions: { ...state.iconPositions, [id]: { x, y } },
        })),
    }),
    {
      name: 'megalodon-desktop',
      partialize: (state) => ({
        wallpaper: state.wallpaper,
        iconPositions: state.iconPositions,
      }),
    }
  )
);
