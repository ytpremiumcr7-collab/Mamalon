import { AnimatePresence, motion } from 'framer-motion';
import { useAuthStore } from '@/stores/useAuthStore';
import LoginScreen from '@/components/LoginScreen';
import BootSequence from '@/components/BootSequence';
import Desktop from '@/components/Desktop';

export default function App() {
  const { isAuthenticated, isBootComplete } = useAuthStore();

  return (
    <div className="w-full h-full overflow-hidden bg-[#030305]">
      <AnimatePresence mode="wait">
        {!isAuthenticated && (
          <motion.div
            key="login"
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.4 }}
            className="w-full h-full"
          >
            <LoginScreen />
          </motion.div>
        )}

        {isAuthenticated && !isBootComplete && (
          <motion.div
            key="boot"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full"
          >
            <BootSequence />
          </motion.div>
        )}

        {isAuthenticated && isBootComplete && (
          <motion.div
            key="desktop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full h-full"
          >
            <Desktop />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
