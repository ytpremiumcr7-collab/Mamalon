import { useState, useEffect, useRef, useCallback } from 'react';
import { LayoutGrid, Play, Pause, RotateCcw } from 'lucide-react';

const COLS = 10;
const ROWS = 20;

const COLORS: Record<string, string> = {
  I: '#4A9E9E', O: '#C9A84C', T: '#7B6FB8', S: '#5A9E6F', Z: '#B84A4A', J: '#5A8AB8', L: '#D4953A',
};

const SHAPES: Record<string, number[][]> = {
  I: [[1, 1, 1, 1]],
  O: [[1, 1], [1, 1]],
  T: [[0, 1, 0], [1, 1, 1]],
  S: [[0, 1, 1], [1, 1, 0]],
  Z: [[1, 1, 0], [0, 1, 1]],
  J: [[1, 0, 0], [1, 1, 1]],
  L: [[0, 0, 1], [1, 1, 1]],
};

type Cell = { color: string } | null;

function randomPiece(): string {
  const keys = Object.keys(SHAPES);
  return keys[Math.floor(Math.random() * keys.length)];
}

function rotate(shape: number[][]): number[][] {
  const rows = shape.length;
  const cols = shape[0].length;
  const result: number[][] = [];
  for (let c = 0; c < cols; c++) {
    result[c] = [];
    for (let r = 0; r < rows; r++) {
      result[c][rows - 1 - r] = shape[r][c];
    }
  }
  return result;
}

function wallKick(shape: number[][], x: number, y: number, board: Cell[][]): { x: number; y: number } | null {
  const kicks = [0, -1, 1, -2, 2];
  for (const kx of kicks) {
    for (const ky of kicks) {
      if (isValidPosition(shape, x + kx, y + ky, board)) return { x: x + kx, y: y + ky };
    }
  }
  return null;
}

function isValidPosition(shape: number[][], x: number, y: number, board: Cell[][]): boolean {
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c]) {
        const nx = x + c;
        const ny = y + r;
        if (nx < 0 || nx >= COLS || ny >= ROWS) return false;
        if (ny >= 0 && board[ny][nx]) return false;
      }
    }
  }
  return true;
}

function placePiece(shape: number[][], x: number, y: number, color: string, board: Cell[][]): Cell[][] {
  const newBoard = board.map((row) => [...row]);
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c]) {
        const ny = y + r;
        if (ny >= 0) newBoard[ny][x + c] = { color };
      }
    }
  }
  return newBoard;
}

function clearLines(board: Cell[][]): { board: Cell[][]; lines: number } {
  let lines = 0;
  const newBoard = board.filter((row) => {
    if (row.every((c) => c !== null)) {
      lines++;
      return false;
    }
    return true;
  });
  while (newBoard.length < ROWS) {
    newBoard.unshift(Array(COLS).fill(null));
  }
  return { board: newBoard, lines };
}

export default function Tetris() {
  const [board, setBoard] = useState<Cell[][]>(() => Array.from({ length: ROWS }, () => Array(COLS).fill(null)));
  const [currentPiece, setCurrentPiece] = useState<string>('');
  const [currentShape, setCurrentShape] = useState<number[][]>([]);
  const [pos, setPos] = useState({ x: 3, y: 0 });
  const [nextPiece, setNextPiece] = useState<string>('');
  const [holdPiece, setHoldPiece] = useState<string>('');
  const [canHold, setCanHold] = useState(true);
  const [score, setScore] = useState(0);
  const [lines, setLines] = useState(0);
  const [level, setLevel] = useState(1);
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused' | 'gameover'>('menu');

  const boardRef = useRef(board);
  boardRef.current = board;
  const posRef = useRef(pos);
  posRef.current = pos;
  const shapeRef = useRef(currentShape);
  shapeRef.current = currentShape;
  const pieceRef = useRef(currentPiece);
  pieceRef.current = currentPiece;
  const canHoldRef = useRef(canHold);
  canHoldRef.current = canHold;

  const spawnPiece = useCallback((pieceName?: string) => {
    const piece = pieceName || nextPiece || randomPiece();
    const shape = SHAPES[piece].map((r) => [...r]);
    const startX = Math.floor((COLS - shape[0].length) / 2);
    if (!isValidPosition(shape, startX, 0, boardRef.current)) {
      setGameState('gameover');
      return;
    }
    setCurrentPiece(piece);
    setCurrentShape(shape);
    setPos({ x: startX, y: 0 });
    if (!pieceName) setNextPiece(randomPiece());
    setCanHold(true);
  }, [nextPiece]);

  const resetGame = useCallback(() => {
    const newBoard = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
    setBoard(newBoard);
    boardRef.current = newBoard;
    setScore(0);
    setLines(0);
    setLevel(1);
    setHoldPiece('');
    setCanHold(true);
    setNextPiece(randomPiece());
    setGameState('playing');
    setTimeout(() => {
      const piece = randomPiece();
      setCurrentPiece(piece);
      setCurrentShape(SHAPES[piece].map((r) => [...r]));
      setPos({ x: 3, y: 0 });
      setNextPiece(randomPiece());
    }, 0);
  }, []);

  const lockPiece = useCallback(() => {
    const newBoard = placePiece(shapeRef.current, posRef.current.x, posRef.current.y, COLORS[pieceRef.current], boardRef.current);
    const { board: clearedBoard, lines: cleared } = clearLines(newBoard);
    if (cleared > 0) {
      const points = cleared === 1 ? 100 : cleared === 2 ? 300 : cleared === 3 ? 500 : 800;
      setScore((s) => s + points * level);
      setLines((l) => {
        const newLines = l + cleared;
        setLevel(Math.floor(newLines / 10) + 1);
        return newLines;
      });
    }
    setBoard(clearedBoard);
    boardRef.current = clearedBoard;
    spawnPiece();
  }, [level, spawnPiece]);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;
    const speed = Math.max(100, 1000 * Math.pow(0.85, level - 1));
    const interval = setInterval(() => {
      const { x, y } = posRef.current;
      const shape = shapeRef.current;
      if (isValidPosition(shape, x, y + 1, boardRef.current)) {
        setPos({ x, y: y + 1 });
      } else {
        lockPiece();
      }
    }, speed);
    return () => clearInterval(interval);
  }, [gameState, level, lockPiece]);

  // Keyboard
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'p' || e.key === 'P') {
        setGameState((s) => s === 'playing' ? 'paused' : s === 'paused' ? 'playing' : s);
        return;
      }
      if (gameState !== 'playing') return;
      const { x, y } = posRef.current;
      const shape = shapeRef.current;

      switch (e.key) {
        case 'ArrowLeft':
        case 'a': case 'A':
          e.preventDefault();
          if (isValidPosition(shape, x - 1, y, boardRef.current)) setPos({ x: x - 1, y });
          break;
        case 'ArrowRight':
        case 'd': case 'D':
          e.preventDefault();
          if (isValidPosition(shape, x + 1, y, boardRef.current)) setPos({ x: x + 1, y });
          break;
        case 'ArrowDown':
        case 's': case 'S':
          e.preventDefault();
          if (isValidPosition(shape, x, y + 1, boardRef.current)) setPos({ x, y: y + 1 });
          else lockPiece();
          break;
        case 'ArrowUp':
        case 'w': case 'W':
          e.preventDefault();
          { const rotated = rotate(shape);
            const kick = wallKick(rotated, x, y, boardRef.current);
            if (kick) { setCurrentShape(rotated); setPos(kick); } }
          break;
        case ' ':
          e.preventDefault();
          { let dropY = y;
            while (isValidPosition(shape, x, dropY + 1, boardRef.current)) dropY++;
            setPos({ x, y: dropY }); }
          break;
        case 'c': case 'C':
          e.preventDefault();
          if (canHoldRef.current) {
            const held = holdPiece;
            setHoldPiece(pieceRef.current);
            if (held) {
              spawnPiece(held);
            } else {
              spawnPiece();
            }
            setCanHold(false);
          }
          break;
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState, holdPiece, lockPiece, spawnPiece]);

  // Ghost piece position
  const ghostY = (() => {
    let gy = pos.y;
    while (isValidPosition(currentShape, pos.x, gy + 1, board)) gy++;
    return gy;
  })();

  const renderBoard = () => {
    const display = board.map((row) => [...row]);
    // Ghost
    for (let r = 0; r < currentShape.length; r++) {
      for (let c = 0; c < currentShape[r].length; c++) {
        if (currentShape[r][c]) {
          const ny = ghostY + r;
          const nx = pos.x + c;
          if (ny >= 0 && ny < ROWS && nx >= 0 && nx < COLS && !display[ny][nx]) {
            display[ny][nx] = { color: COLORS[currentPiece] + '30' };
          }
        }
      }
    }
    // Current
    for (let r = 0; r < currentShape.length; r++) {
      for (let c = 0; c < currentShape[r].length; c++) {
        if (currentShape[r][c]) {
          const ny = pos.y + r;
          const nx = pos.x + c;
          if (ny >= 0 && ny < ROWS && nx >= 0 && nx < COLS) {
            display[ny][nx] = { color: COLORS[currentPiece] };
          }
        }
      }
    }
    return display;
  };

  const displayBoard = renderBoard();
  const cellSize = Math.min(24, Math.floor(360 / COLS));

  return (
    <div className="w-full h-full flex flex-col items-center justify-center select-none" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center gap-4 mb-2">
        <div className="flex items-center gap-1.5">
          <LayoutGrid size={14} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-xs font-medium">Tetris</span>
        </div>
        <span className="text-xs font-mono" style={{ color: 'var(--accent-gold)' }}>Score: {score}</span>
        <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>Lv: {level}</span>
        <span className="text-xs font-mono" style={{ color: 'var(--info)' }}>Lines: {lines}</span>
        {gameState === 'playing' && (
          <button onClick={() => setGameState('paused')} className="p-1 rounded hover:bg-[#222235]"><Pause size={12} /></button>
        )}
      </div>

      <div className="flex gap-3">
        {/* Hold */}
        <div className="flex flex-col gap-2">
          <div className="text-[10px] text-center" style={{ color: 'var(--text-muted)' }}>HOLD</div>
          <div className="rounded-md p-1" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', width: 4 * cellSize, height: 4 * cellSize }}>
            {holdPiece && (
              <div className="grid gap-px" style={{ gridTemplateColumns: `repeat(${SHAPES[holdPiece][0].length}, 1fr)` }}>
                {SHAPES[holdPiece].flat().map((cell, i) => (
                  <div key={i} style={{ width: cellSize - 2, height: cellSize - 2, background: cell ? COLORS[holdPiece] : 'transparent', borderRadius: '2px' }} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Board */}
        <div className="relative" style={{ border: '2px solid var(--border-subtle)', borderRadius: '4px', overflow: 'hidden' }}>
          {gameState === 'menu' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 z-10" style={{ background: 'rgba(3,3,5,0.85)' }}>
              <LayoutGrid size={28} style={{ color: 'var(--accent-gold)' }} />
              <span className="text-lg font-bold" style={{ fontFamily: 'Cinzel, Georgia, serif', color: 'var(--accent-gold)' }}>Tetris</span>
              <span className="text-[10px]" style={{ color: 'var(--text-secondary)' }}>Arrows: Move  Up: Rotate  Space: Hard Drop  C: Hold</span>
              <button onClick={resetGame} className="flex items-center gap-1 px-4 py-1.5 rounded-md text-xs font-medium mt-1" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
                <Play size={12} /> Start
              </button>
            </div>
          )}
          {gameState === 'paused' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 z-10" style={{ background: 'rgba(3,3,5,0.75)' }}>
              <span className="text-lg font-bold" style={{ color: 'var(--accent-gold)' }}>Paused</span>
              <button onClick={() => setGameState('playing')} className="px-4 py-1.5 rounded-md text-xs font-medium" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>Resume</button>
            </div>
          )}
          {gameState === 'gameover' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 z-10" style={{ background: 'rgba(184,74,74,0.2)' }}>
              <span className="text-lg font-bold" style={{ color: 'var(--danger)' }}>GAME OVER</span>
              <span className="text-sm font-mono" style={{ color: 'var(--accent-gold)' }}>Score: {score}</span>
              <button onClick={resetGame} className="flex items-center gap-1 px-4 py-1.5 rounded-md text-xs font-medium" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
                <RotateCcw size={12} /> Retry
              </button>
            </div>
          )}

          <div className="grid" style={{ gridTemplateColumns: `repeat(${COLS}, ${cellSize}px)`, gridTemplateRows: `repeat(${ROWS}, ${cellSize}px)` }}>
            {displayBoard.flat().map((cell, i) => (
              <div
                key={i}
                style={{
                  width: cellSize,
                  height: cellSize,
                  background: cell ? cell.color : (Math.floor(i / COLS) % 2 === i % 2 ? 'rgba(18,18,26,0.8)' : 'rgba(22,22,34,0.8)'),
                  border: `1px solid ${cell ? cell.color + '80' : 'rgba(42,42,62,0.2)'}`,
                  boxShadow: cell && !cell.color.includes('30') ? 'inset 2px 2px 0 rgba(255,255,255,0.2), inset -1px -1px 0 rgba(0,0,0,0.3)' : 'none',
                }}
              />
            ))}
          </div>
        </div>

        {/* Next */}
        <div className="flex flex-col gap-2">
          <div className="text-[10px] text-center" style={{ color: 'var(--text-muted)' }}>NEXT</div>
          <div className="rounded-md p-1" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', width: 4 * cellSize, height: 4 * cellSize }}>
            {nextPiece && (
              <div className="grid gap-px" style={{ gridTemplateColumns: `repeat(${SHAPES[nextPiece][0].length}, 1fr)` }}>
                {SHAPES[nextPiece].flat().map((cell, i) => (
                  <div key={i} style={{ width: cellSize - 2, height: cellSize - 2, background: cell ? COLORS[nextPiece] : 'transparent', borderRadius: '2px' }} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile controls */}
      <div className="flex gap-1 mt-3 md:hidden">
        <button onClick={() => { const { x, y } = pos; if (isValidPosition(currentShape, x - 1, y, board)) setPos({ x: x - 1, y }); }} className="p-2 rounded-lg text-xs" style={{ background: 'var(--surface)' }}>←</button>
        <button onClick={() => { const { x, y } = pos; if (isValidPosition(currentShape, x + 1, y, board)) setPos({ x: x + 1, y }); }} className="p-2 rounded-lg text-xs" style={{ background: 'var(--surface)' }}>→</button>
        <button onClick={() => { const rotated = rotate(currentShape); const kick = wallKick(rotated, pos.x, pos.y, board); if (kick) { setCurrentShape(rotated); setPos(kick); } }} className="p-2 rounded-lg text-xs" style={{ background: 'var(--surface)' }}>↻</button>
        <button onClick={() => { let dropY = pos.y; while (isValidPosition(currentShape, pos.x, dropY + 1, board)) dropY++; setPos({ x: pos.x, y: dropY }); }} className="p-2 rounded-lg text-xs" style={{ background: 'var(--surface)' }}>⤓</button>
      </div>
    </div>
  );
}
