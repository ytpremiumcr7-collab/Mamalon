import { Trash2 } from 'lucide-react'

export default function Trash() {
  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col items-center justify-center p-6">
      <Trash2 className="w-12 h-12 text-[#8A8578] mb-3 opacity-40" />
      <p className="text-sm text-[#8A8578]">Trash — Coming Soon</p>
    </div>
  )
}
