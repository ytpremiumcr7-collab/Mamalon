import { useState, useEffect, useRef, useCallback } from 'react';
import { Gamepad2, Play, Pause, RotateCcw, ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

interface Position {
  x: number;
  y: number;
}

const GRID_SIZE = 20;
const INITIAL_SPEED = 150;
const SPEED_DECREASE = 8;
const MIN_SPEED = 60;

function randomPosition(exclude: Position[]): Position {
  let pos: Position;
  do {
    pos = { x: Math.floor(Math.random() * GRID_SIZE), y: Math.floor(Math.random() * GRID_SIZE) };
  } while (exclude.some((e) => e.x === pos.x && e.y === pos.y));
  return pos;
}

export default function Snake() {
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }]);
  const [food, setFood] = useState<Position>(() => randomPosition([{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }]));
  const [specialFood, setSpecialFood] = useState<Position | null>(null);
  const [specialTimer, setSpecialTimer] = useState(0);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    try { return Number(localStorage.getItem('cs-snake-hs')) || 0; } catch { return 0; }
  });
  const [level, setLevel] = useState(1);
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused' | 'gameover'>('menu');
  const [scorePopups, setScorePopups] = useState<{ id: number; x: number; y: number; points: number }[]>([]);
  const directionRef = useRef<Direction>('RIGHT');
  const gameLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const foodsEaten = useRef(0);

  const speed = Math.max(MIN_SPEED, INITIAL_SPEED - (level - 1) * SPEED_DECREASE);

  const resetGame = useCallback(() => {
    const initialSnake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
    setSnake(initialSnake);
    directionRef.current = 'RIGHT';
    setFood(randomPosition(initialSnake));
    setSpecialFood(null);
    setSpecialTimer(0);
    setScore(0);
    setLevel(1);
    setGameState('playing');
    foodsEaten.current = 0;
  }, []);

  const gameOver = useCallback(() => {
    setGameState('gameover');
    setHighScore((prev) => {
      const newHs = Math.max(prev, score);
      localStorage.setItem('cs-snake-hs', String(newHs));
      return newHs;
    });
  }, [score]);

  // Main game loop
  useEffect(() => {
    if (gameState !== 'playing') {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      return;
    }

    gameLoopRef.current = setInterval(() => {
      setSnake((prevSnake) => {
        const head = prevSnake[0];
        const dir = directionRef.current;
        let newHead: Position;
        switch (dir) {
          case 'UP': newHead = { x: head.x, y: head.y - 1 }; break;
          case 'DOWN': newHead = { x: head.x, y: head.y + 1 }; break;
          case 'LEFT': newHead = { x: head.x - 1, y: head.y }; break;
          case 'RIGHT': newHead = { x: head.x + 1, y: head.y }; break;
        }

        // Wall collision
        if (newHead.x < 0 || newHead.x >= GRID_SIZE || newHead.y < 0 || newHead.y >= GRID_SIZE) {
          gameOver();
          return prevSnake;
        }

        // Self collision
        if (prevSnake.some((s) => s.x === newHead.x && s.y === newHead.y)) {
          gameOver();
          return prevSnake;
        }

        const newSnake = [newHead, ...prevSnake];

        // Check food
        setFood((currentFood) => {
          setSpecialFood((currentSpecial) => {
            // Check special food
            if (currentSpecial && newHead.x === currentSpecial.x && newHead.y === currentSpecial.y) {
              setScore((s) => s + 30);
              setScorePopups((popups) => [...popups, { id: Date.now(), x: newHead.x, y: newHead.y, points: 30 }]);
              foodsEaten.current += 1;
              if (foodsEaten.current % 5 === 0) {
                setLevel((l) => l + 1);
              }
              newSnake.push(prevSnake[prevSnake.length - 1]);
              setTimeout(() => setScorePopups((p) => p.filter((popup) => popup.id !== Date.now())), 800);
              return null;
            }
            return currentSpecial;
          });

          if (newHead.x === currentFood.x && newHead.y === currentFood.y) {
            setScore((s) => s + 10);
            setScorePopups((popups) => [...popups, { id: Date.now(), x: newHead.x, y: newHead.y, points: 10 }]);
            foodsEaten.current += 1;
            if (foodsEaten.current % 5 === 0) {
              setLevel((l) => l + 1);
            }
            // Spawn special food every 5
            if (foodsEaten.current % 5 === 0) {
              const sf = randomPosition(newSnake);
              setSpecialFood(sf);
              setSpecialTimer(8);
            }
            return randomPosition(newSnake);
          }
          return currentFood;
        });

        // Actually we need to handle this differently - check if we grew
        return newSnake.length > prevSnake.length + 1 ? newSnake : newSnake.slice(0, -1);
      });
    }, speed);

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    };
  }, [gameState, speed, gameOver]);

  // Special food timer
  useEffect(() => {
    if (specialFood && gameState === 'playing') {
      const interval = setInterval(() => {
        setSpecialTimer((t) => {
          if (t <= 1) {
            setSpecialFood(null);
            return 0;
          }
          return t - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [specialFood, gameState]);

  // Keyboard controls
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (gameState === 'gameover' && e.key === ' ') {
        e.preventDefault();
        resetGame();
        return;
      }
      if (e.key === ' ' || e.key === 'p' || e.key === 'P') {
        e.preventDefault();
        setGameState((s) => s === 'playing' ? 'paused' : s === 'paused' ? 'playing' : s);
        return;
      }

      if (gameState !== 'playing') return;

      const currentDir = directionRef.current;
      let newDir: Direction | null = null;
      switch (e.key) {
        case 'ArrowUp': case 'w': case 'W': newDir = 'UP'; break;
        case 'ArrowDown': case 's': case 'S': newDir = 'DOWN'; break;
        case 'ArrowLeft': case 'a': case 'A': newDir = 'LEFT'; break;
        case 'ArrowRight': case 'd': case 'D': newDir = 'RIGHT'; break;
      }
      if (newDir) {
        e.preventDefault();
        const opposites: Record<Direction, Direction> = { UP: 'DOWN', DOWN: 'UP', LEFT: 'RIGHT', RIGHT: 'LEFT' };
        if (opposites[currentDir] !== newDir) {
          directionRef.current = newDir;
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState, resetGame]);

  const cellSize = Math.min(360, Math.min(window.innerWidth - 40, window.innerHeight - 200)) / GRID_SIZE;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center select-none" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* HUD */}
      <div className="flex items-center justify-between w-full max-w-[400px] px-2 mb-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <Gamepad2 size={14} style={{ color: 'var(--accent-gold)' }} />
            <span className="text-xs font-medium">Snake</span>
          </div>
          <span className="text-xs font-mono" style={{ color: 'var(--accent-gold)' }}>Score: {score}</span>
          <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>High: {highScore}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono" style={{ color: 'var(--info)' }}>Lv {level}</span>
          {gameState === 'playing' && (
            <button onClick={() => setGameState('paused')} className="p-1 rounded hover:bg-[#222235]">
              <Pause size={14} />
            </button>
          )}
          {gameState === 'paused' && (
            <button onClick={() => setGameState('playing')} className="p-1 rounded hover:bg-[#222235]">
              <Play size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Game board */}
      <div
        className="relative"
        style={{
          width: GRID_SIZE * cellSize,
          height: GRID_SIZE * cellSize,
          border: '2px solid var(--accent-gold)',
          borderRadius: '4px',
          overflow: 'hidden',
        }}
      >
        {gameState === 'menu' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 z-10" style={{ background: 'rgba(3,3,5,0.85)' }}>
            <Gamepad2 size={32} style={{ color: 'var(--accent-gold)' }} />
            <span className="text-xl font-bold" style={{ fontFamily: 'Cinzel, Georgia, serif', color: 'var(--accent-gold)' }}>Snake</span>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>Arrow keys or WASD to move</span>
            <button
              onClick={resetGame}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-medium mt-2"
              style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
            >
              <Play size={14} /> Start Game
            </button>
          </div>
        )}

        {gameState === 'paused' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 z-10" style={{ background: 'rgba(3,3,5,0.75)' }}>
            <span className="text-lg font-bold" style={{ color: 'var(--accent-gold)' }}>Paused</span>
            <button
              onClick={() => setGameState('playing')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-medium"
              style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
            >
              <Play size={14} /> Resume
            </button>
          </div>
        )}

        {gameState === 'gameover' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 z-10" style={{ background: 'rgba(184,74,74,0.2)' }}>
            <span className="text-lg font-bold" style={{ color: 'var(--danger)' }}>GAME OVER</span>
            <span className="text-sm font-mono" style={{ color: 'var(--accent-gold)' }}>Score: {score}</span>
            <button
              onClick={resetGame}
              className="flex items-center gap-1.5 px-4 py-2 rounded-md text-xs font-medium"
              style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
            >
              <RotateCcw size={14} /> Try Again
            </button>
          </div>
        )}

        {/* Grid cells */}
        <div className="grid" style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`, width: '100%', height: '100%' }}>
          {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
            const x = i % GRID_SIZE;
            const y = Math.floor(i / GRID_SIZE);
            const isSnake = snake.some((s) => s.x === x && s.y === y);
            const isHead = snake[0].x === x && snake[0].y === y;
            const isFood = food.x === x && food.y === y;
            const isSpecial = specialFood?.x === x && specialFood?.y === y;

            return (
              <div
                key={i}
                className="relative flex items-center justify-center"
                style={{
                  width: cellSize,
                  height: cellSize,
                }}
              >
                {isSnake && (
                  <div
                    className="rounded-sm"
                    style={{
                      width: cellSize - 1,
                      height: cellSize - 1,
                      background: isHead ? 'var(--accent-gold-bright)' : 'var(--accent-gold)',
                      boxShadow: isHead ? '0 0 6px rgba(201,168,76,0.5)' : 'inset 0 1px 2px rgba(255,255,255,0.1)',
                    }}
                  />
                )}
                {isFood && !isSnake && (
                  <div
                    className="rounded-full"
                    style={{
                      width: cellSize * 0.6,
                      height: cellSize * 0.6,
                      background: 'var(--danger)',
                      animation: 'pulse 1s infinite',
                    }}
                  />
                )}
                {isSpecial && !isSnake && (
                  <div
                    className="rounded-full"
                    style={{
                      width: cellSize * 0.5,
                      height: cellSize * 0.5,
                      background: 'var(--success)',
                      animation: 'pulse 0.5s infinite',
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>

        {/* Score popups */}
        {scorePopups.map((popup) => (
          <div
            key={popup.id}
            className="absolute text-xs font-bold pointer-events-none"
            style={{
              left: popup.x * cellSize,
              top: popup.y * cellSize - 20,
              color: popup.points > 10 ? 'var(--success)' : 'var(--accent-gold)',
              animation: 'floatUp 0.8s ease-out forwards',
            }}
          >
            +{popup.points}
          </div>
        ))}

        {/* Special food timer */}
        {specialFood && specialTimer > 0 && (
          <div
            className="absolute top-1 right-1 px-1.5 py-0.5 rounded text-[9px] font-mono"
            style={{ background: 'rgba(90,158,111,0.3)', color: 'var(--success)' }}
          >
            {specialTimer}s
          </div>
        )}
      </div>

      {/* Mobile controls */}
      <div className="flex flex-col items-center gap-1 mt-3 md:hidden">
        <button onClick={() => { if (directionRef.current !== 'DOWN') { directionRef.current = 'UP'; } }} className="p-2 rounded-lg" style={{ background: 'var(--surface)' }}><ChevronUp size={20} /></button>
        <div className="flex gap-1">
          <button onClick={() => { if (directionRef.current !== 'RIGHT') { directionRef.current = 'LEFT'; } }} className="p-2 rounded-lg" style={{ background: 'var(--surface)' }}><ChevronLeft size={20} /></button>
          <button onClick={() => { if (directionRef.current !== 'UP') { directionRef.current = 'DOWN'; } }} className="p-2 rounded-lg" style={{ background: 'var(--surface)' }}><ChevronDown size={20} /></button>
          <button onClick={() => { if (directionRef.current !== 'LEFT') { directionRef.current = 'RIGHT'; } }} className="p-2 rounded-lg" style={{ background: 'var(--surface)' }}><ChevronRight size={20} /></button>
        </div>
      </div>

      <style>{`
        @keyframes floatUp {
          0% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(-20px); }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.15); }
        }
      `}</style>
    </div>
  );
}
