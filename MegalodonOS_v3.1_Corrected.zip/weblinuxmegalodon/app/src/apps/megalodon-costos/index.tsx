// =============================================================================
// Megalodon CostOS v3.1 — Main Component (5 Tabs)
// =============================================================================

import { useState, useMemo, useRef, useEffect } from 'react';
import type { CSSProperties } from 'react';
import {
  DollarSign, CheckCircle, AlertTriangle, Clock, Plus, Search,
  Trash2, FileJson, Activity, ShieldCheck,
  Download, Zap, Calculator, X
} from 'lucide-react';
import { useMegalodonStore } from '@/stores/useMegalodonStore';
import { FSR_CONST, determinarProcedimiento, nombreProcedimiento } from './data/legales';
import { runValidacion, computeComplianceScore, getOverallStatus } from './engines/validador';
import { runMonteCarlo, formatMXN, getDefaultSimulationVariables } from './engines/montecarlo';
import { evaluateLegalFramework } from './engines/juridico';
import { generateHospitalElements, quantifyBIM } from './engines/bim';
import type { ValidationInput, ValidationRule } from './engines/validador';
import type { SimulationResult } from './engines/montecarlo';

type TabId = 'resumen' | 'presupuesto' | 'analisis' | 'validacion' | 'reporte';

interface BudgetLine {
  id: string;
  conceptKey: string;
  description: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  status: 'validated' | 'pending' | 'error';
}

const TABS: { id: TabId; label: string }[] = [
  { id: 'resumen', label: 'Resumen' },
  { id: 'presupuesto', label: 'Presupuesto' },
  { id: 'analisis', label: 'Análisis' },
  { id: 'validacion', label: 'Validación' },
  { id: 'reporte', label: 'Reporte' },
];

// ---- Helper: generate budget lines from BIM elements ----
function generateBudgetLines(): BudgetLine[] {
  const bimElements = generateHospitalElements();
  return bimElements.map((el, i) => ({
    id: `BL-${String(i + 1).padStart(3, '0')}`,
    conceptKey: el.conceptKey,
    description: el.description,
    unit: el.unit,
    quantity: el.quantity,
    unitPrice: el.cost / el.quantity,
    amount: el.cost,
    status: 'validated' as const,
  }));
}

// ---- KPI Card ----
function KpiCard({ icon: Icon, label, value, color }: {
  icon: React.ComponentType<{ className?: string; style?: CSSProperties }>;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4 flex items-start gap-3">
      <div className="p-2 rounded-md" style={{ backgroundColor: `${color}15` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div>
        <div className="text-[11px] uppercase tracking-wider text-[#8A8578] mb-1">{label}</div>
        <div className="text-lg font-semibold" style={{ color }}>{value}</div>
      </div>
    </div>
  );
}

// ---- Monte Carlo Histogram (canvas bar chart) ----
function HistogramChart({ result }: { result: SimulationResult | null }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!result || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.scale(dpr, dpr);

    ctx.clearRect(0, 0, w, h);

    const { histogram } = result;
    if (histogram.length === 0) return;

    const maxCount = Math.max(...histogram.map((b) => b.count));
    const barW = (w - 40) / histogram.length;
    const chartH = h - 50;

    // Grid lines
    ctx.strokeStyle = 'rgba(42,42,62,0.5)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 4; i++) {
      const y = 10 + (chartH / 4) * i;
      ctx.beginPath();
      ctx.moveTo(30, y);
      ctx.lineTo(w - 10, y);
      ctx.stroke();
    }

    // Bars
    histogram.forEach((bin, i) => {
      const bh = (bin.count / maxCount) * chartH;
      const x = 30 + i * barW;
      const y = 10 + chartH - bh;

      const gradient = ctx.createLinearGradient(0, y, 0, y + bh);
      gradient.addColorStop(0, '#C9A84C');
      gradient.addColorStop(1, '#8B7340');

      ctx.fillStyle = gradient;
      ctx.fillRect(x + 1, y, barW - 2, bh);
    });

    // Percentile lines
    const percentileX = (p: number) => {
      const range = result.p99 - result.p1 || 1;
      return 30 + ((p - result.p1) / range) * (w - 40);
    };

    const drawLine = (value: number, color: string, label: string, dashed = false) => {
      const x = percentileX(value);
      if (x < 30 || x > w - 10) return;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      if (dashed) ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(x, 10);
      ctx.lineTo(x, 10 + chartH);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = color;
      ctx.font = '10px Inter, sans-serif';
      ctx.fillText(label, x + 2, 8);
    };

    drawLine(result.mean, '#C9A84C', 'Media');
    drawLine(result.p50, '#E8E4DC', 'P50');
    drawLine(result.p95, '#5A9E6F', 'P95', true);

    // Axis labels
    ctx.fillStyle = '#8A8578';
    ctx.font = '10px Inter, sans-serif';
    ctx.fillText(`Min: ${formatMXN(result.p5)}`, 30, h - 8);
    ctx.fillText(`Max: ${formatMXN(result.p95)}`, w - 100, h - 8);
  }, [result]);

  if (!result) return <div className="text-[#8A8578] text-sm">Ejecute la simulación para ver histograma</div>;

  return <canvas ref={canvasRef} className="w-full h-48 rounded-md border border-[#2A2A3E] bg-[#0A0A0F]" />;
}

// ---- Tornado Chart ----
function TornadoChart({ sensitivity }: { sensitivity: SimulationResult['sensitivity'] }) {
  if (!sensitivity || sensitivity.length === 0) return null;
  const maxImpact = Math.max(...sensitivity.map((s) => s.impact));

  return (
    <div className="space-y-1.5">
      {sensitivity.map((item) => {
        const width = (item.impact / maxImpact) * 100;
        return (
          <div key={item.variable} className="flex items-center gap-2 text-xs">
            <div className="w-32 text-right text-[#8A8578] truncate">{item.variable}</div>
            <div className="flex-1 h-5 bg-[#0A0A0F] rounded-sm overflow-hidden relative">
              <div
                className="h-full rounded-sm transition-all"
                style={{ width: `${width}%`, backgroundColor: width > 70 ? '#D4953A' : width > 40 ? '#C9A84C' : '#8B7340' }}
              />
            </div>
            <div className="w-20 text-[#C9A84C] font-mono">{formatMXN(item.impact)}</div>
          </div>
        );
      })}
    </div>
  );
}

// ---- Budget Grid ----
function BudgetGrid() {
  const [lines, setLines] = useState<BudgetLine[]>(() => generateBudgetLines());
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newLine, setNewLine] = useState({ conceptKey: '', description: '', unit: '', quantity: 0, unitPrice: 0 });

  const filtered = useMemo(() => {
    if (!search) return lines;
    const s = search.toLowerCase();
    return lines.filter((l) => l.description.toLowerCase().includes(s) || l.conceptKey.toLowerCase().includes(s));
  }, [lines, search]);

  const subtotal = useMemo(() => lines.reduce((s, l) => s + l.amount, 0), [lines]);
  const iva = subtotal * 0.16;
  const total = subtotal + iva;

  const addLine = () => {
    if (!newLine.description || newLine.quantity <= 0 || newLine.unitPrice <= 0) return;
    const id = `BL-${String(lines.length + 1).padStart(3, '0')}`;
    setLines([...lines, {
      id,
      conceptKey: newLine.conceptKey || id,
      description: newLine.description,
      unit: newLine.unit || 'm2',
      quantity: newLine.quantity,
      unitPrice: newLine.unitPrice,
      amount: newLine.quantity * newLine.unitPrice,
      status: 'pending',
    }]);
    setNewLine({ conceptKey: '', description: '', unit: '', quantity: 0, unitPrice: 0 });
    setShowAddForm(false);
  };

  const removeLine = (id: string) => setLines(lines.filter((l) => l.id !== id));

  const exportJSON = () => {
    const data = { lines, subtotal, iva, total, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `megalodon-presupuesto-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-3 bg-[#0A0A0F] border-b border-[#2A2A3E]">
        <div className="flex items-center gap-2">
          <button onClick={() => setShowAddForm(!showAddForm)} className="flex items-center gap-1.5 px-3 py-1.5 bg-[#C9A84C] text-[#030305] text-xs font-semibold rounded hover:bg-[#D4B85A] transition-colors">
            <Plus className="w-3.5 h-3.5" /> Concepto
          </button>
          <button onClick={exportJSON} className="flex items-center gap-1.5 px-3 py-1.5 border border-[#2A2A3E] text-[#8A8578] text-xs rounded hover:border-[#C9A84C] hover:text-[#C9A84C] transition-colors">
            <FileJson className="w-3.5 h-3.5" /> Exportar JSON
          </button>
        </div>
        <div className="flex items-center gap-2">
          <Search className="w-3.5 h-3.5 text-[#8A8578]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar concepto..."
            className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] placeholder:text-[#4D4A42] focus:border-[#C9A84C] outline-none w-48"
          />
        </div>
      </div>

      {/* Add form */}
      {showAddForm && (
        <div className="p-3 bg-[#1A1A26] border-b border-[#2A2A3E] grid grid-cols-6 gap-2">
          <input placeholder="Clave" value={newLine.conceptKey} onChange={(e) => setNewLine({ ...newLine, conceptKey: e.target.value })} className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none" />
          <input placeholder="Descripción" value={newLine.description} onChange={(e) => setNewLine({ ...newLine, description: e.target.value })} className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none col-span-2" />
          <input placeholder="Unidad" value={newLine.unit} onChange={(e) => setNewLine({ ...newLine, unit: e.target.value })} className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none" />
          <input type="number" placeholder="Cantidad" value={newLine.quantity || ''} onChange={(e) => setNewLine({ ...newLine, quantity: parseFloat(e.target.value) || 0 })} className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none" />
          <div className="flex items-center gap-1">
            <input type="number" placeholder="Precio unitario" value={newLine.unitPrice || ''} onChange={(e) => setNewLine({ ...newLine, unitPrice: parseFloat(e.target.value) || 0 })} className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none flex-1" />
            <button onClick={addLine} className="px-2 py-1 bg-[#5A9E6F] text-[#030305] text-xs font-semibold rounded hover:bg-[#6AAF7F]"><Plus className="w-3 h-3" /></button>
          </div>
        </div>
      )}

      {/* Grid */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-xs">
          <thead className="sticky top-0 bg-[#1A1A26] z-10">
            <tr className="text-left text-[#8A8578] border-b border-[#2A2A3E]">
              <th className="p-2 w-10">#</th>
              <th className="p-2 w-24">Clave</th>
              <th className="p-2">Descripción</th>
              <th className="p-2 w-14">Unidad</th>
              <th className="p-2 w-20 text-right">Cantidad</th>
              <th className="p-2 w-24 text-right">P. Unitario</th>
              <th className="p-2 w-24 text-right">Importe</th>
              <th className="p-2 w-16">Estado</th>
              <th className="p-2 w-8"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((line, i) => (
              <tr key={line.id} className="border-b border-[#2A2A3E]/50 hover:bg-[#222235]/50 transition-colors">
                <td className="p-2 text-[#4D4A42]">{i + 1}</td>
                <td className="p-2 font-mono text-[#C9A84C]">{line.conceptKey}</td>
                <td className="p-2 text-[#E8E4DC]">{line.description}</td>
                <td className="p-2 text-[#8A8578]">{line.unit}</td>
                <td className="p-2 text-right font-mono text-[#E8E4DC]">{line.quantity.toLocaleString('es-MX', { maximumFractionDigits: 2 })}</td>
                <td className="p-2 text-right font-mono text-[#8A8578]">{formatMXN(line.unitPrice)}</td>
                <td className="p-2 text-right font-mono text-[#C9A84C] font-medium">{formatMXN(line.amount)}</td>
                <td className="p-2">
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                    line.status === 'validated' ? 'bg-[#5A9E6F]/15 text-[#5A9E6F]' :
                    line.status === 'pending' ? 'bg-[#D4953A]/15 text-[#D4953A]' :
                    'bg-[#B84A4A]/15 text-[#B84A4A]'
                  }`}>
                    {line.status === 'validated' ? 'Validado' : line.status === 'pending' ? 'Pendiente' : 'Error'}
                  </span>
                </td>
                <td className="p-2">
                  <button onClick={() => removeLine(line.id)} className="text-[#4D4A42] hover:text-[#B84A4A] transition-colors"><Trash2 className="w-3 h-3" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer totals */}
      <div className="p-3 bg-[#0A0A0F] border-t border-[#2A2A3E] flex justify-end gap-6 text-xs">
        <div className="text-right">
          <div className="text-[#8A8578]">Subtotal</div>
          <div className="font-mono text-[#E8E4DC] font-semibold">{formatMXN(subtotal)}</div>
        </div>
        <div className="text-right">
          <div className="text-[#8A8578]">IVA 16%</div>
          <div className="font-mono text-[#E8E4DC]">{formatMXN(iva)}</div>
        </div>
        <div className="text-right">
          <div className="text-[#C9A84C]">Total</div>
          <div className="font-mono text-[#C9A84C] text-base font-bold">{formatMXN(total)}</div>
        </div>
      </div>
    </div>
  );
}

// ---- Validation Panel ----
function ValidationPanel() {
  const [results, setResults] = useState<ValidationRule[]>([]);
  const [inputs, setInputs] = useState<ValidationInput>({
    rfc: 'ABC010101ABC',
    opinionSAT: 'POSITIVO',
    imssStatus: 'ACTIVO',
    infonavitStatus: 'ACTIVO',
    efirmaValid: true,
    efirmaExpiryDays: 365,
    fsrSeguridadSocial: 0.3056,
    fsrDiasPagados: 365,
    fsrDiasLaborados: 291,
    maquinariaItems: [
      { key: 'EQ-001', description: 'Revolvedora 9ft³', costoAdquisicion: 45000, vidaEconomica: 8, horasAnio: 1200, factorMantenimiento: 0.45, combustibleHora: 25, operadorHora: 85.5, seguroAnual: 900 },
      { key: 'EQ-080', description: 'Retroexcavadora CAT 420E', costoAdquisicion: 2800000, vidaEconomica: 10, horasAnio: 2000, factorMantenimiento: 0.55, combustibleHora: 180, operadorHora: 135, seguroAnual: 56000 },
    ],
    factorIndirectos: 0.125,
    factorFinanciamiento: 0.025,
    utilidad: 0.082,
    costoDirectoPct: 0.684,
    numWorkers: 45,
    hasCFDI: true,
  });

  const run = () => {
    const res = runValidacion(inputs);
    setResults(res);
  };

  const score = useMemo(() => computeComplianceScore(results), [results]);
  const overall = useMemo(() => getOverallStatus(results), [results]);

  const update = (field: keyof ValidationInput, value: unknown) => {
    setInputs((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex flex-col h-full overflow-auto p-4 gap-4">
      {/* Input form */}
      <div className="grid grid-cols-4 gap-3">
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">RFC</label>
          <input value={inputs.rfc} onChange={(e) => update('rfc', e.target.value)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Opinión SAT</label>
          <select value={inputs.opinionSAT} onChange={(e) => update('opinionSAT', e.target.value)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none">
            <option>POSITIVO</option>
            <option>EXTRAVIADA</option>
            <option>NEGATIVO</option>
            <option>DEFINITIVA</option>
          </select>
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">IMSS</label>
          <select value={inputs.imssStatus} onChange={(e) => update('imssStatus', e.target.value)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none">
            <option>ACTIVO</option>
            <option>INACTIVO</option>
          </select>
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">INFONAVIT</label>
          <select value={inputs.infonavitStatus} onChange={(e) => update('infonavitStatus', e.target.value)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none">
            <option>ACTIVO</option>
            <option>INACTIVO</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">e.firma válida</label>
          <select value={inputs.efirmaValid ? 'si' : 'no'} onChange={(e) => update('efirmaValid', e.target.value === 'si')} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none">
            <option value="si">Sí</option>
            <option value="no">No</option>
          </select>
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Días vigencia e.firma</label>
          <input type="number" value={inputs.efirmaExpiryDays} onChange={(e) => update('efirmaExpiryDays', parseInt(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Fracción SS (PS)</label>
          <input type="number" step="0.001" value={inputs.fsrSeguridadSocial} onChange={(e) => update('fsrSeguridadSocial', parseFloat(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Factor indirectos</label>
          <input type="number" step="0.001" value={inputs.factorIndirectos} onChange={(e) => update('factorIndirectos', parseFloat(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Días pagados (TP)</label>
          <input type="number" value={inputs.fsrDiasPagados} onChange={(e) => update('fsrDiasPagados', parseInt(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Días laborados (TL)</label>
          <input type="number" value={inputs.fsrDiasLaborados} onChange={(e) => update('fsrDiasLaborados', parseInt(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Utilidad</label>
          <input type="number" step="0.001" value={inputs.utilidad} onChange={(e) => update('utilidad', parseFloat(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
        <div>
          <label className="text-[10px] uppercase text-[#8A8578] block mb-1">% Costo directo</label>
          <input type="number" step="0.001" value={inputs.costoDirectoPct} onChange={(e) => update('costoDirectoPct', parseFloat(e.target.value) || 0)} className="w-full bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
        </div>
      </div>

      <button onClick={run} className="flex items-center justify-center gap-2 px-4 py-2 bg-[#C9A84C] text-[#030305] text-sm font-semibold rounded hover:bg-[#D4B85A] transition-colors self-start">
        <ShieldCheck className="w-4 h-4" /> Ejecutar Validación
      </button>

      {/* Results */}
      {results.length > 0 && (
        <>
          {/* Score banner */}
          <div className={`p-3 rounded-lg border ${
            overall === 'PASS' ? 'bg-[#5A9E6F]/10 border-[#5A9E6F]/30' :
            overall === 'WARNING' ? 'bg-[#D4953A]/10 border-[#D4953A]/30' :
            'bg-[#B84A4A]/10 border-[#B84A4A]/30'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {overall === 'PASS' ? <CheckCircle className="w-5 h-5 text-[#5A9E6F]" /> :
                 overall === 'WARNING' ? <AlertTriangle className="w-5 h-5 text-[#D4953A]" /> :
                 <X className="w-5 h-5 text-[#B84A4A]" />}
                <span className={`font-semibold ${
                  overall === 'PASS' ? 'text-[#5A9E6F]' : overall === 'WARNING' ? 'text-[#D4953A]' : 'text-[#B84A4A]'
                }`}>
                  {overall === 'PASS' ? 'Todas las validaciones aprobadas' : overall === 'WARNING' ? 'Advertencias detectadas' : 'Validaciones fallidas'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#8A8578] text-xs">Cumplimiento:</span>
                <span className={`text-lg font-bold font-mono ${
                  score >= 80 ? 'text-[#5A9E6F]' : score >= 50 ? 'text-[#D4953A]' : 'text-[#B84A4A]'
                }`}>{score}%</span>
              </div>
            </div>
          </div>

          {/* Rule results */}
          <div className="space-y-2">
            {results.map((rule) => (
              <div key={rule.id} className="bg-[#1A1A26] border border-[#2A2A3E] rounded-md p-3">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {rule.status === 'PASS' ? <CheckCircle className="w-4 h-4 text-[#5A9E6F]" /> :
                     rule.status === 'WARNING' ? <AlertTriangle className="w-4 h-4 text-[#D4953A]" /> :
                     <X className="w-4 h-4 text-[#B84A4A]" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-[#4D4A42] px-1 py-0.5 bg-[#0A0A0F] rounded">{rule.id}</span>
                      <span className="text-xs font-semibold text-[#E8E4DC]">{rule.name}</span>
                    </div>
                    <div className="text-[11px] text-[#8A8578] mt-1">{rule.detail}</div>
                    <div className="text-[10px] text-[#4D4A42] mt-1 font-mono">{rule.evidence}</div>
                    {rule.fixAction && (
                      <div className="text-[11px] text-[#D4953A] mt-1">Acción: {rule.fixAction}</div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ---- Analysis Panel ----
function AnalysisPanel() {
  const [iterations, setIterations] = useState(1000);
  const [confidence, setConfidence] = useState(95);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [running, setRunning] = useState(false);

  const run = () => {
    setRunning(true);
    setTimeout(() => {
      const vars = getDefaultSimulationVariables();
      const simResult = runMonteCarlo({ iterations, confidenceLevel: confidence / 100, variables: vars });
      setResult(simResult);
      setRunning(false);
    }, 300);
  };

  const fsrPS = FSR_CONST.FORMULA.FRACCION_SEGURIDAD_SOCIAL_DEFAULT;
  const fsrTP = FSR_CONST.FORMULA.DIAS_PAGADOS;
  const fsrTL = FSR_CONST.FORMULA.DIAS_LABORADOS;
  const fsrValue = fsrPS * (fsrTP / fsrTL) + (fsrTP / fsrTL);

  return (
    <div className="flex flex-col h-full overflow-auto p-4 gap-4">
      {/* FSR Calculator */}
      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Calculator className="w-4 h-4 text-[#C9A84C]" />
          <h3 className="text-sm font-semibold text-[#E8E4DC]">Calculadora FSR (LAASSP Art. 12)</h3>
        </div>
        <div className="text-[11px] text-[#8A8578] mb-3">
          Fórmula: FSR = PS × (TP/TL) + (TP/TL)
        </div>
        <div className="grid grid-cols-4 gap-4 text-xs">
          <div className="bg-[#0A0A0F] rounded p-2">
            <div className="text-[10px] text-[#8A8578]">PS (Fracción SS)</div>
            <div className="font-mono text-[#C9A84C] font-semibold">{fsrPS.toFixed(4)}</div>
          </div>
          <div className="bg-[#0A0A0F] rounded p-2">
            <div className="text-[10px] text-[#8A8578]">TP (Días pagados)</div>
            <div className="font-mono text-[#C9A84C] font-semibold">{fsrTP}</div>
          </div>
          <div className="bg-[#0A0A0F] rounded p-2">
            <div className="text-[10px] text-[#8A8578]">TL (Días laborados)</div>
            <div className="font-mono text-[#C9A84C] font-semibold">{fsrTL}</div>
          </div>
          <div className="bg-[#0A0A0F] rounded p-2 border border-[#C9A84C]/30">
            <div className="text-[10px] text-[#C9A84C]">FSR</div>
            <div className="font-mono text-[#C9A84C] font-bold text-lg">{fsrValue.toFixed(4)}</div>
          </div>
        </div>
        <div className="mt-2 text-[10px] font-mono text-[#4D4A42]">
          {fsrPS.toFixed(4)} × ({fsrTP}/{fsrTL}) + ({fsrTP}/{fsrTL}) = {fsrValue.toFixed(4)}
        </div>
      </div>

      {/* Monte Carlo Config */}
      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <div className="flex items-center gap-2 mb-3">
          <Activity className="w-4 h-4 text-[#C9A84C]" />
          <h3 className="text-sm font-semibold text-[#E8E4DC]">Simulación Monte Carlo</h3>
        </div>
        <div className="flex items-end gap-4">
          <div>
            <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Iteraciones</label>
            <input type="number" min={100} max={100000} value={iterations} onChange={(e) => setIterations(parseInt(e.target.value) || 1000)} className="w-28 bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] focus:border-[#C9A84C] outline-none font-mono" />
          </div>
          <div>
            <label className="text-[10px] uppercase text-[#8A8578] block mb-1">Confianza {confidence}%</label>
            <input type="range" min={80} max={99} value={confidence} onChange={(e) => setConfidence(parseInt(e.target.value))} className="w-32 accent-[#C9A84C]" />
          </div>
          <button onClick={run} disabled={running} className="flex items-center gap-1.5 px-4 py-1.5 bg-[#C9A84C] text-[#030305] text-xs font-semibold rounded hover:bg-[#D4B85A] transition-colors disabled:opacity-50">
            <Zap className="w-3.5 h-3.5" /> {running ? 'Ejecutando...' : 'Ejecutar'}
          </button>
        </div>
      </div>

      {/* Histogram */}
      {result && (
        <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
          <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Distribución de Costos Simulados</h3>
          <HistogramChart result={result} />
        </div>
      )}

      {/* Statistics */}
      {result && (
        <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
          <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Estadísticas</h3>
          <div className="grid grid-cols-4 gap-2 text-xs">
            {[
              { label: 'Media', value: formatMXN(result.mean) },
              { label: 'Mediana (P50)', value: formatMXN(result.p50) },
              { label: 'Desv. Estándar', value: formatMXN(result.stdDev) },
              { label: 'P5', value: formatMXN(result.p5) },
              { label: 'P25', value: formatMXN(result.p25) },
              { label: 'P75', value: formatMXN(result.p75) },
              { label: 'P95', value: formatMXN(result.p95) },
              { label: 'CV', value: `${result.cv.toFixed(2)}%` },
            ].map((s) => (
              <div key={s.label} className="bg-[#0A0A0F] rounded p-2">
                <div className="text-[10px] text-[#8A8578]">{s.label}</div>
                <div className="font-mono text-[#C9A84C] font-semibold">{s.value}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tornado Chart */}
      {result && result.sensitivity.length > 0 && (
        <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
          <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Análisis de Sensibilidad (Tornado)</h3>
          <TornadoChart sensitivity={result.sensitivity} />
        </div>
      )}
    </div>
  );
}

// ---- Report Panel ----
function ReportPanel() {
  const budgetLines = useMemo(() => generateBudgetLines(), []);
  const bimResult = useMemo(() => quantifyBIM(generateHospitalElements()), []);
  const legal = useMemo(() => evaluateLegalFramework(
    bimResult.totalCost, true, true, true, 0.684, 0.082, 0.125
  ), [bimResult.totalCost]);

  const subtotal = budgetLines.reduce((s, l) => s + l.amount, 0);
  const iva = subtotal * 0.16;
  const total = subtotal + iva;

  const exportReport = () => {
    const lines = [
      '='.repeat(70),
      'MEGALODON COSTOS v3.1 — REPORTE DE ANÁLISIS',
      '='.repeat(70),
      `Fecha: ${new Date().toLocaleString('es-MX')}`,
      `Proyecto: Hospital General Regional`,
      `Procedimiento: ${legal.procedureName}`,
      '-'.repeat(70),
      '',
      'RESUMEN PRESUPUESTAL',
      '-'.repeat(40),
      `Subtotal:          ${formatMXN(subtotal)}`,
      `IVA 16%:           ${formatMXN(iva)}`,
      `TOTAL:             ${formatMXN(total)}`,
      '',
      'DESGLOSE POR NIVEL (BIM)',
      '-'.repeat(40),
      ...Object.entries(bimResult.byLevel).map(([level, cost]) => `  ${level.padEnd(20)} ${formatMXN(cost).padStart(20)}`),
      `  ${'TOTAL'.padEnd(20)} ${formatMXN(bimResult.totalCost).padStart(20)}`,
      '',
      'CUMPLIMIENTO LEGAL',
      '-'.repeat(40),
      ...legal.requirements.map((r) => `[${r.status}] ${r.article} ${r.law}: ${r.description}\n    ${r.detail}`),
      '',
      'RECOMENDACIONES',
      '-'.repeat(40),
      ...legal.recommendations.map((r) => `  • ${r}`),
      '',
      `Generado por Megalodon CostOS v3.1`,
      '='.repeat(70),
    ];

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `megalodon-reporte-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full overflow-auto p-4 gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold text-[#E8E4DC]">Reporte Ejecutivo</h2>
        <button onClick={exportReport} className="flex items-center gap-1.5 px-3 py-1.5 bg-[#C9A84C] text-[#030305] text-xs font-semibold rounded hover:bg-[#D4B85A] transition-colors">
          <Download className="w-3.5 h-3.5" /> Exportar Reporte
        </button>
      </div>

      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Resumen Presupuestal</h3>
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="bg-[#0A0A0F] rounded p-3">
            <div className="text-[10px] text-[#8A8578]">Subtotal</div>
            <div className="font-mono text-[#E8E4DC] text-base font-semibold">{formatMXN(subtotal)}</div>
          </div>
          <div className="bg-[#0A0A0F] rounded p-3">
            <div className="text-[10px] text-[#8A8578]">IVA 16%</div>
            <div className="font-mono text-[#E8E4DC] text-base font-semibold">{formatMXN(iva)}</div>
          </div>
          <div className="bg-[#0A0A0F] rounded p-3 border border-[#C9A84C]/30">
            <div className="text-[10px] text-[#C9A84C]">TOTAL</div>
            <div className="font-mono text-[#C9A84C] text-lg font-bold">{formatMXN(total)}</div>
          </div>
        </div>
      </div>

      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Desglose BIM por Nivel</h3>
        <div className="space-y-1.5 text-xs">
          {Object.entries(bimResult.byLevel).map(([level, cost]) => (
            <div key={level} className="flex items-center justify-between">
              <span className="text-[#8A8578]">{level}</span>
              <span className="font-mono text-[#E8E4DC]">{formatMXN(cost)}</span>
            </div>
          ))}
          <div className="border-t border-[#2A2A3E] pt-1 flex justify-between font-semibold">
            <span className="text-[#C9A84C]">Total BIM</span>
            <span className="font-mono text-[#C9A84C]">{formatMXN(bimResult.totalCost)}</span>
          </div>
        </div>
      </div>

      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Marco Legal Aplicable</h3>
        <div className="mb-3 text-xs">
          <span className="text-[#8A8578]">Procedimiento: </span>
          <span className="text-[#C9A84C] font-medium">{legal.procedureName}</span>
        </div>
        <div className="space-y-2">
          {legal.requirements.map((req) => (
            <div key={`${req.law}-${req.article}`} className="flex items-start gap-2 text-xs">
              {req.status === 'PASS' ? <CheckCircle className="w-3.5 h-3.5 text-[#5A9E6F] mt-0.5 shrink-0" /> :
               <AlertTriangle className="w-3.5 h-3.5 text-[#D4953A] mt-0.5 shrink-0" />}
              <div>
                <span className="font-mono text-[#4D4A42] mr-1">{req.law} {req.article}</span>
                <span className="text-[#E8E4DC]">{req.description}</span>
                <div className="text-[#8A8578] mt-0.5">{req.detail}</div>
              </div>
            </div>
          ))}
        </div>
        {legal.recommendations.length > 0 && (
          <div className="mt-3 pt-3 border-t border-[#2A2A3E]">
            <div className="text-[10px] uppercase text-[#8A8578] mb-1">Recomendaciones</div>
            {legal.recommendations.map((r, i) => (
              <div key={i} className="text-[11px] text-[#D4953A] flex items-start gap-1">
                <span className="mt-0.5">•</span> {r}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ---- Simple SVG Pie Chart ----
function PieChart({ data }: { data: Record<string, number> }) {
  const total = Object.values(data).reduce((s, v) => s + v, 0);
  const colors = ['#C9A84C', '#7B6FB8', '#5A9E6F', '#5A8AB8', '#D4953A'];
  const entries = Object.entries(data);
  let cumulative = 0;

  return (
    <div className="flex items-center gap-4">
      <svg width="120" height="120" viewBox="0 0 120 120">
        {entries.map(([key, value], i) => {
          const startAngle = (cumulative / total) * Math.PI * 2;
          cumulative += value;
          const endAngle = (cumulative / total) * Math.PI * 2;
          const x1 = 60 + 50 * Math.cos(startAngle - Math.PI / 2);
          const y1 = 60 + 50 * Math.sin(startAngle - Math.PI / 2);
          const x2 = 60 + 50 * Math.cos(endAngle - Math.PI / 2);
          const y2 = 60 + 50 * Math.sin(endAngle - Math.PI / 2);
          const largeArc = endAngle - startAngle > Math.PI ? 1 : 0;
          return (
            <path
              key={key}
              d={`M 60 60 L ${x1} ${y1} A 50 50 0 ${largeArc} 1 ${x2} ${y2} Z`}
              fill={colors[i % colors.length]}
              stroke="#1A1A26"
              strokeWidth="1"
            />
          );
        })}
      </svg>
      <div className="space-y-1 text-xs">
        {entries.map(([key, value], i) => (
          <div key={key} className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: colors[i % colors.length] }} />
            <span className="text-[#8A8578] capitalize">{key}</span>
            <span className="font-mono text-[#E8E4DC]">{((value / total) * 100).toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---- Resumen (Dashboard) Tab ----
function ResumenTab() {
  const budgetLines = useMemo(() => generateBudgetLines(), []);
  const bimResult = useMemo(() => quantifyBIM(generateHospitalElements()), []);
  const totalBudget = budgetLines.reduce((s, l) => s + l.amount, 0);
  const validatedCount = budgetLines.filter((l) => l.status === 'validated').length;
  const riskIndex = 12.4;

  // Actividades reales del sistema - se llenan desde el store
  const activities = useMegalodonStore(s => {
    const validations = s.validationResults.slice(-3).map(v => ({
      time: new Date(v.timestamp).toLocaleString('es-MX', { hour: '2-digit', minute: '2-digit' }),
      action: `Validacion ejecutada — ${v.rulesPassed}/${v.rulesChecked} reglas aprobadas`,
      user: 'Sistema',
      type: (v.overall === 'PASS' ? 'success' : v.overall === 'WARNING' ? 'warning' : 'error') as 'success' | 'warning' | 'error' | 'info',
    }));
    const calculations = s.calculationResults.slice(-2).map(c => ({
      time: new Date(c.timestamp).toLocaleString('es-MX', { hour: '2-digit', minute: '2-digit' }),
      action: c.summary,
      user: 'Sistema',
      type: 'info' as const,
    }));
    return [...validations, ...calculations].length > 0
      ? [...validations, ...calculations].slice(0, 6)
      : [{ time: 'Ahora', action: 'Bienvenido a Megalodon CostOS v3.1 — Comienza creando un proyecto', user: 'Sistema', type: 'info' as const }];
  });

  return (
    <div className="flex flex-col h-full overflow-auto p-4 gap-4">
      <div className="grid grid-cols-4 gap-3">
        <KpiCard icon={DollarSign} label="Presupuesto Total" value={formatMXN(totalBudget * 1.16)} color="#C9A84C" />
        <KpiCard icon={CheckCircle} label="Conceptos Validados" value={`${validatedCount} / ${budgetLines.length}`} color="#5A9E6F" />
        <KpiCard icon={AlertTriangle} label="Exposición de Riesgo" value={`${riskIndex}% (Medio)`} color="#D4953A" />
        <KpiCard icon={Clock} label="Días para Entrega" value="45 días" color="#5A8AB8" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
          <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Distribución del Presupuesto</h3>
          <PieChart data={bimResult.byCategory} />
        </div>

        <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
          <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Estado del Proyecto</h3>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[#8A8578]">Procedimiento</span>
              <span className="text-[#C9A84C] font-medium">{nombreProcedimiento(determinarProcedimiento(totalBudget * 1.16))}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8A8578]">FSR Calculado</span>
              <span className="font-mono text-[#C9A84C]">
                {(FSR_CONST.FORMULA.FRACCION_SEGURIDAD_SOCIAL_DEFAULT * (FSR_CONST.FORMULA.DIAS_PAGADOS / FSR_CONST.FORMULA.DIAS_LABORADOS) + (FSR_CONST.FORMULA.DIAS_PAGADOS / FSR_CONST.FORMULA.DIAS_LABORADOS)).toFixed(4)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8A8578]">Elementos BIM</span>
              <span className="font-mono text-[#E8E4DC]">{bimResult.elements.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8A8578]">Costo por m² construcción</span>
              <span className="font-mono text-[#E8E4DC]">{formatMXN(totalBudget / 5300)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#8A8578]">Verificación de precios</span>
              <span className={bimResult.verified ? 'text-[#5A9E6F]' : 'text-[#D4953A]'}>
                {bimResult.verified ? '✓ Verificado' : '⚠ Con discrepancias'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-4">
        <h3 className="text-sm font-semibold text-[#E8E4DC] mb-3">Actividad Reciente</h3>
        <div className="space-y-1.5">
          {activities.map((act, i) => (
            <div key={i} className="flex items-center gap-3 py-1.5 px-2 rounded hover:bg-[#222235]/30 transition-colors text-xs">
              <div className={`w-2 h-2 rounded-full shrink-0 ${
                act.type === 'success' ? 'bg-[#5A9E6F]' : act.type === 'warning' ? 'bg-[#D4953A]' : 'bg-[#5A8AB8]'
              }`} />
              <span className="text-[#4D4A42] w-20 shrink-0">{act.time}</span>
              <span className="text-[#E8E4DC] flex-1">{act.action}</span>
              <span className="text-[#8A8578]">{act.user}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// =============================================================================
// MAIN COMPONENT
// =============================================================================
export default function MegalodonCostos() {
  const [activeTab, setActiveTab] = useState<TabId>('resumen');
  const defaultBudgetLines = useMemo(() => generateBudgetLines(), []);
  const totalBudget = useMemo(() => defaultBudgetLines.reduce((s, l) => s + l.amount, 0) * 1.16, [defaultBudgetLines]);

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col font-sans">
      {/* Menu bar */}
      <div className="h-7 bg-[#0A0A0F] border-b border-[#2A2A3E] flex items-center px-3 gap-4 text-[11px] text-[#8A8578]">
        {['Archivo', 'Proyecto', 'Catálogos', 'Análisis', 'Reportes', 'Herramientas', 'Ayuda'].map((m) => (
          <button key={m} className="hover:text-[#E8E4DC] hover:bg-[#222235] px-2 py-0.5 rounded transition-colors">
            {m}
          </button>
        ))}
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-0 bg-[#0A0A0F] border-b border-[#2A2A3E] px-2">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-[#C9A84C] text-[#C9A84C]'
                : 'border-transparent text-[#8A8578] hover:text-[#E8E4DC] hover:bg-[#222235]/50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'resumen' && <ResumenTab />}
        {activeTab === 'presupuesto' && <BudgetGrid />}
        {activeTab === 'analisis' && <AnalysisPanel />}
        {activeTab === 'validacion' && <ValidationPanel />}
        {activeTab === 'reporte' && <ReportPanel />}
      </div>

      {/* Status bar */}
      <div className="h-6 bg-[#0A0A0F] border-t border-[#2A2A3E] flex items-center justify-between px-3 text-[10px] font-mono text-[#8A8578]">
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-[#5A9E6F]" />
          <span>Validado</span>
        </div>
        <div className="flex items-center gap-4">
          <span>FSR: <span className="text-[#C9A84C]">1.4526</span></span>
          <span>Total: <span className="text-[#C9A84C]">{formatMXN(totalBudget)}</span></span>
        </div>
      </div>
    </div>
  );
}
