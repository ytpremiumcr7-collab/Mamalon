import { useState, useCallback } from 'react';
import {
  Palette, Monitor, Volume2, Wifi, Info,
  Sun, Moon, Sunrise, Check, Play
} from 'lucide-react';
import { useSettingsStore } from '@/stores/useSettingsStore';

const ACCENTS = [
  { name: 'Gold', value: '#C9A84C' },
  { name: 'Cyan', value: '#4A9E9E' },
  { name: 'Purple', value: '#7B6FB8' },
  { name: 'Green', value: '#5A9E6F' },
];

const WALLPAPERS = [
  { name: 'Cosmic Nebula', id: 'nebula', color: '#0A0A0F' },
  { name: 'Amber Void', id: 'amber', color: '#1A0F00' },
  { name: 'Deep Ocean', id: 'ocean', color: '#000A1A' },
];

const RESOLUTIONS = ['1920×1080', '2560×1440', '3840×2160', '1280×720'];
const SCALES = ['100%', '125%', '150%'];

const WIFI_NETWORKS = [
  { name: 'Cornstone-5G', connected: true, strength: 95, secured: true },
  { name: 'Cornstone-2.4G', connected: false, strength: 88, secured: true },
  { name: 'Guest-Network', connected: false, strength: 72, secured: false },
  { name: 'Office-WiFi', connected: false, strength: 60, secured: true },
  { name: 'Neighbor_WiFi', connected: false, strength: 35, secured: true },
];

function Slider({ value, min, max, onChange, label, unit = '' }: {
  value: number; min: number; max: number; onChange: (v: number) => void; label: string; unit?: string;
}) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between">
        <span className="text-xs text-[#8A8578]">{label}</span>
        <span className="text-xs font-mono text-[#E8E4DC]">{value}{unit}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-1.5 bg-[#2A2A3E] rounded-full appearance-none cursor-pointer accent-[#C9A84C]"
        style={{ accentColor: '#C9A84C' }}
      />
    </div>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-[#E8E4DC]">{label}</span>
      <button
        onClick={() => onChange(!checked)}
        className={`w-9 h-5 rounded-full transition-colors relative ${checked ? 'bg-[#C9A84C]' : 'bg-[#2A2A3E]'}`}
      >
        <div className={`w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-transform ${checked ? 'translate-x-[18px]' : 'translate-x-0.5'}`} />
      </button>
    </div>
  );
}

export default function SettingsApp() {
  const settings = useSettingsStore();
  const [activeTab, setActiveTab] = useState('personalization');
  const [brightness, setBrightness] = useState(100);
  const [resolution, setResolution] = useState('1920×1080');
  const [scale, setScale] = useState('100%');
  const [masterVolume, setMasterVolume] = useState(75);
  const [inputVolume, setInputVolume] = useState(50);
  const [outputDevice, setOutputDevice] = useState('Speakers (Built-in)');
  const [inputDevice, setInputDevice] = useState('Microphone (Built-in)');
  const [connectedNetwork, setConnectedNetwork] = useState('Cornstone-5G');
  const [wallpaper, setWallpaper] = useState('nebula');

  const tabs = [
    { id: 'personalization', label: 'Personalization', icon: Palette },
    { id: 'display', label: 'Display', icon: Monitor },
    { id: 'sound', label: 'Sound', icon: Volume2 },
    { id: 'network', label: 'Network', icon: Wifi },
    { id: 'about', label: 'About', icon: Info },
  ];

  const playTestSound = useCallback(() => {
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 440;
      gain.gain.value = 0.1;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch { /* silent fail */ }
  }, []);

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex overflow-hidden">
      {/* Sidebar */}
      <div className="w-48 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col py-2 shrink-0">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-3 px-4 py-2.5 text-sm transition-colors text-left ${
              activeTab === tab.id
                ? 'bg-[#222235] text-[#C9A84C] border-r-2 border-[#C9A84C]'
                : 'text-[#8A8578] hover:text-[#E8E4DC] hover:bg-[#1A1A26]'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'personalization' && (
          <div className="space-y-6 max-w-lg">
            <h2 className="text-lg font-semibold">Personalization</h2>

            {/* Theme */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-[#8A8578]">Theme</h3>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => settings.updateSetting('theme', 'dark')}
                  className={`flex flex-col items-center gap-2 p-3 rounded-lg border transition-all ${
                    settings.theme === 'dark' ? 'border-[#C9A84C] bg-[#222235]' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
                  }`}
                >
                  <Moon className="w-6 h-6 text-[#C9A84C]" />
                  <span className="text-xs">Dark</span>
                </button>
                <button
                  onClick={() => settings.updateSetting('theme', 'light')}
                  className={`flex flex-col items-center gap-2 p-3 rounded-lg border transition-all ${
                    settings.theme === 'light' ? 'border-[#C9A84C] bg-[#222235]' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
                  }`}
                >
                  <Sun className="w-6 h-6 text-[#D4953A]" />
                  <span className="text-xs">Light</span>
                </button>
                <button
                  onClick={() => settings.updateSetting('theme', 'auto')}
                  className={`flex flex-col items-center gap-2 p-3 rounded-lg border transition-all ${
                    settings.theme === 'auto' ? 'border-[#C9A84C] bg-[#222235]' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
                  }`}
                >
                  <Sunrise className="w-6 h-6 text-[#5A8AB8]" />
                  <span className="text-xs">Auto</span>
                </button>
              </div>
            </div>

            {/* Accent Color */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-[#8A8578]">Accent Color</h3>
              <div className="flex gap-3">
                {ACCENTS.map(a => (
                  <button
                    key={a.value}
                    onClick={() => settings.updateSetting('accentColor', a.value)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                      settings.accentColor === a.value ? 'border-[#C9A84C] bg-[#222235]' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
                    }`}
                  >
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: a.value }} />
                    <span className="text-xs">{a.name}</span>
                    {settings.accentColor === a.value && <Check className="w-3 h-3 text-[#C9A84C]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Wallpaper */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-[#8A8578]">Wallpaper</h3>
              <div className="grid grid-cols-3 gap-2">
                {WALLPAPERS.map(wp => (
                  <button
                    key={wp.id}
                    onClick={() => setWallpaper(wp.id)}
                    className={`relative rounded-lg overflow-hidden border-2 transition-all aspect-video ${
                      wallpaper === wp.id ? 'border-[#C9A84C]' : 'border-transparent'
                    }`}
                  >
                    <div className="w-full h-full" style={{ backgroundColor: wp.color }}>
                      {wp.id === 'nebula' && (
                        <div className="w-full h-full" style={{ background: 'radial-gradient(ellipse at 30% 50%, rgba(201,168,76,0.15) 0%, transparent 60%)' }} />
                      )}
                      {wp.id === 'amber' && (
                        <div className="w-full h-full" style={{ background: 'radial-gradient(ellipse at 70% 30%, rgba(212,149,58,0.2) 0%, transparent 50%)' }} />
                      )}
                      {wp.id === 'ocean' && (
                        <div className="w-full h-full" style={{ background: 'radial-gradient(ellipse at 50% 80%, rgba(90,138,184,0.15) 0%, transparent 50%)' }} />
                      )}
                    </div>
                    {wallpaper === wp.id && (
                      <div className="absolute top-1 right-1">
                        <Check className="w-3 h-3 text-[#C9A84C]" />
                      </div>
                    )}
                    <div className="absolute bottom-0 inset-x-0 bg-black/60 px-2 py-1">
                      <span className="text-[10px] text-[#E8E4DC]">{wp.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Transparency */}
            <Toggle
              checked={settings.wallpaperAnimated}
              onChange={(v) => settings.updateSetting('wallpaperAnimated', v)}
              label="Animated wallpaper effects"
            />
          </div>
        )}

        {activeTab === 'display' && (
          <div className="space-y-6 max-w-lg">
            <h2 className="text-lg font-semibold">Display</h2>

            <Slider value={brightness} min={20} max={120} onChange={setBrightness} label="Brightness" unit="%" />

            <div className="space-y-2">
              <span className="text-xs text-[#8A8578]">Resolution</span>
              <select
                value={resolution}
                onChange={e => setResolution(e.target.value)}
                className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
              >
                {RESOLUTIONS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <span className="text-xs text-[#8A8578]">Scale</span>
              <div className="flex gap-2">
                {SCALES.map(s => (
                  <button
                    key={s}
                    onClick={() => setScale(s)}
                    className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                      scale === s ? 'bg-[#222235] text-[#C9A84C] border border-[#C9A84C]' : 'bg-[#0A0A0F] text-[#8A8578] border border-[#2A2A3E] hover:bg-[#1A1A26]'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'sound' && (
          <div className="space-y-6 max-w-lg">
            <h2 className="text-lg font-semibold">Sound</h2>

            <Slider value={masterVolume} min={0} max={100} onChange={setMasterVolume} label="Master Volume" unit="%" />
            <Slider value={inputVolume} min={0} max={100} onChange={setInputVolume} label="Input Volume" unit="%" />

            <div className="space-y-2">
              <span className="text-xs text-[#8A8578]">Output Device</span>
              <select
                value={outputDevice}
                onChange={e => setOutputDevice(e.target.value)}
                className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
              >
                <option>Speakers (Built-in)</option>
                <option>Headphones</option>
                <option>HDMI Output</option>
              </select>
            </div>

            <div className="space-y-2">
              <span className="text-xs text-[#8A8578]">Input Device</span>
              <select
                value={inputDevice}
                onChange={e => setInputDevice(e.target.value)}
                className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
              >
                <option>Microphone (Built-in)</option>
                <option>External Microphone</option>
                <option>Line In</option>
              </select>
            </div>

            <button
              onClick={playTestSound}
              className="flex items-center gap-2 px-4 py-2 bg-[#222235] hover:bg-[#2A2A3E] text-[#C9A84C] rounded-lg text-sm transition-colors border border-[#2A2A3E]"
            >
              <Play className="w-3.5 h-3.5" /> Test Sound
            </button>

            <Toggle
              checked={settings.soundEnabled}
              onChange={(v) => settings.updateSetting('soundEnabled', v)}
              label="System sounds enabled"
            />
          </div>
        )}

        {activeTab === 'network' && (
          <div className="space-y-6 max-w-lg">
            <h2 className="text-lg font-semibold">Network</h2>

            {/* Connection status */}
            <div className="flex items-center gap-3 p-3 bg-[#1A1A26] rounded-lg border border-[#2A2A3E]">
              <Wifi className="w-5 h-5 text-[#5A9E6F]" />
              <div>
                <div className="text-sm text-[#E8E4DC]">Connected to <span className="font-medium">{connectedNetwork}</span></div>
                <div className="text-xs text-[#5A9E6F]">Internet access</div>
              </div>
            </div>

            {/* IP info */}
            <div className="space-y-2 p-3 bg-[#1A1A26] rounded-lg border border-[#2A2A3E]">
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">IP Address</span>
                <span className="text-[#E8E4DC] font-mono">192.168.1.42</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">Subnet Mask</span>
                <span className="text-[#E8E4DC] font-mono">255.255.255.0</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">Gateway</span>
                <span className="text-[#E8E4DC] font-mono">192.168.1.1</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">DNS</span>
                <span className="text-[#E8E4DC] font-mono">1.1.1.1, 8.8.8.8</span>
              </div>
            </div>

            {/* WiFi networks */}
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-[#8A8578]">Available Networks</h3>
              {WIFI_NETWORKS.map(net => (
                <div
                  key={net.name}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                    net.connected ? 'bg-[#222235]/50 border-[#C9A84C]/30' : 'bg-[#1A1A26] border-[#2A2A3E] hover:bg-[#222235]'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Wifi className={`w-4 h-4 ${net.connected ? 'text-[#C9A84C]' : 'text-[#8A8578]'}`} />
                    <div>
                      <div className="text-sm text-[#E8E4DC]">{net.name}</div>
                      <div className="text-[10px] text-[#8A8578]">{net.secured ? 'Secured' : 'Open'} • Signal {net.strength}%</div>
                    </div>
                  </div>
                  {net.connected ? (
                    <span className="text-[10px] text-[#5A9E6F]">Connected</span>
                  ) : (
                    <button
                      onClick={() => setConnectedNetwork(net.name)}
                      className="text-xs px-2 py-1 bg-[#222235] hover:bg-[#2A2A3E] text-[#C9A84C] rounded transition-colors border border-[#2A2A3E]"
                    >
                      Connect
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Data usage */}
            <div className="space-y-2 p-3 bg-[#1A1A26] rounded-lg border border-[#2A2A3E]">
              <h3 className="text-sm font-medium">Data Usage (Session)</h3>
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">Downloaded</span>
                <span className="text-[#E8E4DC] font-mono">1.24 GB</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-[#8A8578]">Uploaded</span>
                <span className="text-[#E8E4DC] font-mono">342 MB</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'about' && (
          <div className="space-y-6 max-w-lg">
            {/* OS Info */}
            <div className="flex flex-col items-center text-center py-4">
              <div className="w-16 h-16 rounded-xl bg-[#1A1A26] border border-[#2A2A3E] flex items-center justify-center mb-3">
                <Sun className="w-8 h-8 text-[#C9A84C]" />
              </div>
              <h2 className="text-2xl font-semibold" style={{ fontFamily: 'Cinzel, Georgia, serif' }}>Cornstone OS</h2>
              <p className="text-sm text-[#8A8578] mt-1 italic">
                "My presence will go with you, and I will give you rest." — Exodus 33:14
              </p>
              <div className="mt-2 px-2 py-1 bg-[#1A1A26] rounded text-xs font-mono text-[#8A8578]">
                Version 1.0 (Build 2026.01)
              </div>
            </div>

            {/* System specs */}
            <div className="space-y-2 p-3 bg-[#1A1A26] rounded-lg border border-[#2A2A3E]">
              <h3 className="text-sm font-medium mb-2">System Specifications</h3>
              {[
                ['Kernel', 'cornstone-6.8.0-generic'],
                ['CPU', 'Virtual 8-Core Processor'],
                ['Memory', '16 GB DDR4'],
                ['Storage', '512 GB SSD (345 GB free)'],
                ['Display', '1920 × 1080 @ 60 Hz'],
                ['Graphics', 'Virtual GPU (LLVM)'],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between text-sm">
                  <span className="text-[#8A8578]">{label}</span>
                  <span className="text-[#E8E4DC] font-mono text-xs">{value}</span>
                </div>
              ))}
            </div>

            {/* Credits */}
            <div className="p-3 bg-[#1A1A26] rounded-lg border border-[#2A2A3E]">
              <h3 className="text-sm font-medium mb-1">Credits</h3>
              <p className="text-xs text-[#8A8578]">
                Built with React, TypeScript, Tailwind CSS, and divine inspiration.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
