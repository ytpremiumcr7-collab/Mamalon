import { useState, useCallback, useMemo } from 'react';
import {
  ArrowRightLeft, Copy, Check, Trash2, Hash,
  FileUp, Shield, Globe
} from 'lucide-react';

/* ── simple MD5 implementation ── */
function md5(input: string): string {
  const txt = utf8Encode(input);
  const k: number[] = [];
  let i = 0;
  for (i = 0; i < 64; i++) k[i] = Math.abs(Math.sin(i + 1)) * 0x100000000 | 0;

  let a = 0x67452301, b = 0xEFCDAB89, c = 0x98BADCFE, d = 0x10325476;

  const msgLen = txt.length * 8;
  const padded = new Uint8Array(((txt.length + 8) >>> 6) * 64 + 64);
  for (let j = 0; j < txt.length; j++) padded[j] = txt.charCodeAt(j);
  padded[txt.length] = 0x80;
  new DataView(padded.buffer).setUint32(padded.length - 8, msgLen, true);

  for (i = 0; i < padded.length; i += 64) {
    const w: number[] = [];
    for (let j = 0; j < 16; j++) {
      w[j] = (padded[i + j * 4] | (padded[i + j * 4 + 1] << 8) | (padded[i + j * 4 + 2] << 16) | (padded[i + j * 4 + 3] << 24)) >>> 0;
    }
    let [aa, bb, cc, dd] = [a, b, c, d];
    for (let j = 0; j < 64; j++) {
      let f: number, g: number;
      if (j < 16) { f = (bb & cc) | (~bb & dd); g = j; }
      else if (j < 32) { f = (dd & bb) | (~dd & cc); g = (5 * j + 1) % 16; }
      else if (j < 48) { f = bb ^ cc ^ dd; g = (3 * j + 5) % 16; }
      else { f = cc ^ (bb | ~dd); g = (7 * j) % 16; }
      const temp = dd;
      dd = cc; cc = bb;
      bb = ((aa + f + k[j] + w[g]) << 0);
      bb = (bb << (j < 16 ? [7, 12, 17, 22][j % 4] : j < 32 ? [5, 9, 14, 20][j % 4] : j < 48 ? [4, 11, 16, 23][j % 4] : [6, 10, 15, 21][j % 4]) | (bb >>> (32 - (j < 16 ? [7, 12, 17, 22][j % 4] : j < 32 ? [5, 9, 14, 20][j % 4] : j < 48 ? [4, 11, 16, 23][j % 4] : [6, 10, 15, 21][j % 4]))));
      bb = ((bb + temp) << 0) >>> 0;
      aa = temp;
    }
    a = ((a + aa) << 0) >>> 0;
    b = ((b + bb) << 0) >>> 0;
    c = ((c + cc) << 0) >>> 0;
    d = ((d + dd) << 0) >>> 0;
  }

  return [a, b, c, d].map(v => ('00000000' + v.toString(16)).slice(-8)).join('');
}

function utf8Encode(str: string): string {
  return unescape(encodeURIComponent(str));
}
/* ── SHA-1 using Web Crypto ── */
async function sha1(input: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function sha256(input: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ── Base64 encode/decode ── */
function base64Encode(str: string, urlSafe: boolean): string {
  try {
    const bytes = new TextEncoder().encode(str);
    let encoded = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
      let i = 0;
      while (i < bytes.length) {
        const b1 = bytes[i++];
        const b2 = i < bytes.length ? bytes[i++] : 0;
        const b3 = i < bytes.length ? bytes[i++] : 0;
        const e1 = b1 >> 2;
        const e2 = ((b1 & 3) << 4) | (b2 >> 4);
        const e3 = ((b2 & 15) << 2) | (b3 >> 6);
        const e4 = b3 & 63;
        encoded += chars[e1] + chars[e2] + (i - 2 < bytes.length ? chars[e3] : '=') + (i - 1 < bytes.length ? chars[e4] : '=');
      }
    if (urlSafe) {
      encoded = encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    }
    return encoded;
  } catch { return 'Error encoding'; }
}

function base64Decode(str: string, urlSafe: boolean): string {
  try {
    let s = str;
    if (urlSafe) {
      s = s.replace(/-/g, '+').replace(/_/g, '/');
      while (s.length % 4) s += '=';
    }
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    const bytes: number[] = [];
    let i = 0;
    while (i < s.length) {
      const e1 = chars.indexOf(s[i++]);
      const e2 = chars.indexOf(s[i++]);
      const e3 = chars.indexOf(s[i++]);
      const e4 = chars.indexOf(s[i++]);
      const b1 = (e1 << 2) | (e2 >> 4);
      const b2 = ((e2 & 15) << 4) | (e3 >> 2);
      const b3 = ((e3 & 3) << 6) | e4;
      bytes.push(b1);
      if (e3 !== 64) bytes.push(b2);
      if (e4 !== 64) bytes.push(b3);
    }
    return new TextDecoder().decode(new Uint8Array(bytes));
  } catch { return 'Error: Invalid Base64 string'; }
}

/* ── URL encode/decode ── */
function urlEncode(str: string, component: boolean): string {
  return component ? encodeURIComponent(str) : encodeURI(str);
}
function urlDecode(str: string, component: boolean): string {
  try {
    return component ? decodeURIComponent(str) : decodeURI(str);
  } catch { return 'Error: Invalid URL encoding'; }
}

type TabMode = 'base64' | 'hash' | 'url';
type Direction = 'encode' | 'decode';

export default function Base64Encoder() {
  const [tab, setTab] = useState<TabMode>('base64');
  const [input, setInput] = useState('Hello, Cornstone OS!');
  const [direction, setDirection] = useState<Direction>('encode');
  const [urlSafe, setUrlSafe] = useState(false);
  const [urlComponent, setUrlComponent] = useState(true);
  const [hashes, setHashes] = useState({ md5: '', sha1: '', sha256: '' });
  const [copiedField, setCopiedField] = useState('');
  const [dragOver, setDragOver] = useState(false);

  /* Compute hashes */
  useMemo(() => {
    if (!input) { setHashes({ md5: '', sha1: '', sha256: '' }); return; }
    const md5Hash = md5(input);
    setHashes({ md5: md5Hash, sha1: 'Computing...', sha256: 'Computing...' });
    sha1(input).then(h => setHashes(prev => ({ ...prev, sha1: h })));
    sha256(input).then(h => setHashes(prev => ({ ...prev, sha256: h })));
  }, [input]);

  /* Derived outputs */
  const output = useMemo(() => {
    if (!input) return '';
    switch (tab) {
      case 'base64':
        return direction === 'encode' ? base64Encode(input, urlSafe) : base64Decode(input, urlSafe);
      case 'url':
        return direction === 'encode' ? urlEncode(input, urlComponent) : urlDecode(input, urlComponent);
      default:
        return '';
    }
  }, [tab, input, direction, urlSafe, urlComponent]);

  const copyText = useCallback(async (text: string, field: string) => {
    try { await navigator.clipboard.writeText(text); setCopiedField(field); setTimeout(() => setCopiedField(''), 2000); } catch { /* noop */ }
  }, []);

  const handleFileDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result === 'string') {
        setInput(result);
      } else if (result instanceof ArrayBuffer) {
        const bytes = new Uint8Array(result);
        let binary = '';
        bytes.forEach(b => binary += String.fromCharCode(b));
        if (tab === 'base64') {
          setInput(btoa(binary));
          setDirection('decode');
        } else {
          setInput(binary);
        }
      }
    };
    reader.readAsText(file);
  }, [tab]);

  const handleDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); setDragOver(true); }, []);
  const handleDragLeave = useCallback(() => setDragOver(false), []);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Tabs */}
      <div className="flex items-center gap-0 bg-[#12121A] border-b border-[#2A2A3E] shrink-0">
        {[
          { key: 'base64' as TabMode, label: 'Base64', icon: ArrowRightLeft },
          { key: 'hash' as TabMode, label: 'Hash', icon: Hash },
          { key: 'url' as TabMode, label: 'URL', icon: Globe },
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs transition-colors border-b-2 ${
              tab === key ? 'border-[#C9A84C] text-[#C9A84C] bg-[#1A1A26]' : 'border-transparent text-[#8A8578] hover:bg-[#1A1A26] hover:text-[#E8E4DC]'
            }`}
            onClick={() => setTab(key)}
          >
            <Icon className="w-3.5 h-3.5" /> {label}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Controls */}
        <div className="flex items-center gap-3 px-3 py-2 border-b border-[#2A2A3E] shrink-0 flex-wrap">
          {tab !== 'hash' && (
            <>
              <div className="flex items-center gap-1 bg-[#12121A] rounded border border-[#2A2A3E]">
                <button
                  className={`px-3 py-1 rounded-l transition-colors ${direction === 'encode' ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235]'}`}
                  onClick={() => setDirection('encode')}
                >
                  Encode
                </button>
                <button
                  className={`px-3 py-1 rounded-r transition-colors ${direction === 'decode' ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235]'}`}
                  onClick={() => setDirection('decode')}
                >
                  Decode
                </button>
              </div>
              {tab === 'base64' && (
                <label className="flex items-center gap-1.5 cursor-pointer select-none">
                  <input type="checkbox" checked={urlSafe} onChange={e => setUrlSafe(e.target.checked)} className="accent-[#C9A84C]" />
                  <span className="text-[#8A8578]">URL-safe</span>
                </label>
              )}
              {tab === 'url' && (
                <label className="flex items-center gap-1.5 cursor-pointer select-none">
                  <input type="checkbox" checked={urlComponent} onChange={e => setUrlComponent(e.target.checked)} className="accent-[#C9A84C]" />
                  <span className="text-[#8A8578]">Component</span>
                </label>
              )}
            </>
          )}
          <div className="flex-1" />
          <button
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E]"
            onClick={() => setInput('')}
          >
            <Trash2 className="w-3 h-3" /> Clear
          </button>
        </div>

        {/* Input area */}
        <div
          className={`flex-1 flex flex-col min-h-0 ${dragOver ? 'bg-[#C9A84C]/10' : ''}`}
          onDrop={handleFileDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          {tab === 'hash' ? (
            /* Hash view */
            <div className="flex flex-col h-full">
              <div className="flex-1 flex flex-col min-h-0">
                <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
                  Input
                </div>
                <textarea
                  className="flex-1 bg-[#030305] p-3 font-mono text-xs resize-none outline-none text-[#E8E4DC] whitespace-pre-wrap overflow-auto"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  placeholder="Enter text to hash..."
                  spellCheck={false}
                />
              </div>
              <div className="shrink-0 border-t border-[#2A2A3E]">
                <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E]">
                  Hash Results
                </div>
                <div className="p-2 flex flex-col gap-1.5">
                  {[
                    { label: 'MD5', value: hashes.md5, color: '#8A8578' },
                    { label: 'SHA-1', value: hashes.sha1, color: '#5A8AB8' },
                    { label: 'SHA-256', value: hashes.sha256, color: '#5A9E6F' },
                  ].map(({ label, value, color }) => (
                    <div key={label} className="flex items-center gap-2 p-2 rounded bg-[#12121A] border border-[#2A2A3E]">
                      <Shield className="w-3.5 h-3.5 shrink-0" style={{ color }} />
                      <span className="text-[10px] text-[#8A8578] w-14 shrink-0">{label}</span>
                      <code className="flex-1 font-mono text-[11px] break-all" style={{ color }}>{value || '—'}</code>
                      <button
                        className="p-1 rounded hover:bg-[#222235] shrink-0"
                        onClick={() => value && copyText(value, label)}
                      >
                        {copiedField === label ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3 text-[#8A8578]" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Base64 / URL encode/decode */
            <div className="flex flex-1 overflow-hidden">
              <div className="flex-1 flex flex-col border-r border-[#2A2A3E] min-w-0">
                <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
                  {direction === 'encode' ? 'Plain Text' : 'Encoded'}
                </div>
                <textarea
                  className="flex-1 bg-[#030305] p-3 font-mono text-xs resize-none outline-none text-[#E8E4DC] whitespace-pre-wrap overflow-auto"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  placeholder={direction === 'encode' ? 'Enter text to encode...' : 'Enter encoded text...'}
                  spellCheck={false}
                />
              </div>
              <div className="flex-1 flex flex-col min-w-0">
                <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0 flex items-center justify-between">
                  <span>{direction === 'encode' ? 'Encoded' : 'Plain Text'}</span>
                  <button
                    className="p-1 rounded hover:bg-[#222235]"
                    onClick={() => output && copyText(output, 'output')}
                  >
                    {copiedField === 'output' ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3 text-[#8A8578]" />}
                  </button>
                </div>
                <div className="flex-1 p-3 font-mono text-xs whitespace-pre-wrap break-all overflow-auto text-[#5A9E6F]">
                  {output}
                </div>
              </div>
            </div>
          )}

          {/* File drop zone */}
          {tab !== 'hash' && (
            <div className="shrink-0 px-3 py-2 border-t border-[#2A2A3E]">
              <label className="flex items-center justify-center gap-2 p-3 rounded border border-dashed border-[#2A2A3E] hover:border-[#C9A84C] hover:bg-[#C9A84C]/5 transition-colors cursor-pointer">
                <FileUp className="w-4 h-4 text-[#8A8578]" />
                <span className="text-[#8A8578]">Drop a file here or click to load</span>
                <input type="file" className="hidden" onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    if (typeof reader.result === 'string') setInput(reader.result);
                  };
                  reader.readAsText(file);
                }} />
              </label>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
