import { useState, useMemo } from 'react';
import { Atom, Search, X } from 'lucide-react';

interface Element {
  n: number; s: string; name: string; m: number; cat: string; config: string; desc: string;
  col: number; row: number;
}

const ELEMENTS: Element[] = [
  { n: 1, s: 'H', name: 'Hydrogen', m: 1.008, cat: 'Nonmetal', config: '1s¹', desc: 'The lightest and most abundant element in the universe.', col: 1, row: 1 },
  { n: 2, s: 'He', name: 'Helium', m: 4.003, cat: 'Noble Gas', config: '1s²', desc: 'A colorless, odorless, tasteless noble gas used in balloons and cooling.', col: 18, row: 1 },
  { n: 3, s: 'Li', name: 'Lithium', m: 6.941, cat: 'Alkali Metal', config: '[He] 2s¹', desc: 'A soft, silvery-white alkali metal used in rechargeable batteries.', col: 1, row: 2 },
  { n: 4, s: 'Be', name: 'Beryllium', m: 9.012, cat: 'Alkaline Earth', config: '[He] 2s²', desc: 'A steel-gray, strong, lightweight metal used in aerospace.', col: 2, row: 2 },
  { n: 5, s: 'B', name: 'Boron', m: 10.81, cat: 'Metalloid', config: '[He] 2s² 2p¹', desc: 'A metalloid essential for plant growth, used in borosilicate glass.', col: 13, row: 2 },
  { n: 6, s: 'C', name: 'Carbon', m: 12.01, cat: 'Nonmetal', config: '[He] 2s² 2p²', desc: 'The basis of all known life. Exists as diamond, graphite, and fullerenes.', col: 14, row: 2 },
  { n: 7, s: 'N', name: 'Nitrogen', m: 14.01, cat: 'Nonmetal', config: '[He] 2s² 2p³', desc: 'Makes up 78% of Earth\'s atmosphere. Essential for proteins and DNA.', col: 15, row: 2 },
  { n: 8, s: 'O', name: 'Oxygen', m: 16.00, cat: 'Nonmetal', config: '[He] 2s² 2p⁴', desc: 'Essential for respiration. Makes up 21% of Earth\'s atmosphere.', col: 16, row: 2 },
  { n: 9, s: 'F', name: 'Fluorine', m: 19.00, cat: 'Halogen', config: '[He] 2s² 2p⁵', desc: 'The most reactive and electronegative element. Used in toothpaste.', col: 17, row: 2 },
  { n: 10, s: 'Ne', name: 'Neon', m: 20.18, cat: 'Noble Gas', config: '[He] 2s² 2p⁶', desc: 'A noble gas that produces a bright reddish-orange light in signs.', col: 18, row: 2 },
  { n: 11, s: 'Na', name: 'Sodium', m: 22.99, cat: 'Alkali Metal', config: '[Ne] 3s¹', desc: 'A soft, highly reactive metal. Essential for nerve function.', col: 1, row: 3 },
  { n: 12, s: 'Mg', name: 'Magnesium', m: 24.31, cat: 'Alkaline Earth', config: '[Ne] 3s²', desc: 'A lightweight metal that burns with a bright white flame.', col: 2, row: 3 },
  { n: 13, s: 'Al', name: 'Aluminium', m: 26.98, cat: 'Post-transition', config: '[Ne] 3s² 3p¹', desc: 'The most abundant metal in Earth\'s crust. Lightweight and corrosion-resistant.', col: 13, row: 3 },
  { n: 14, s: 'Si', name: 'Silicon', m: 28.09, cat: 'Metalloid', config: '[Ne] 3s² 3p²', desc: 'A semiconductor essential for modern electronics and solar cells.', col: 14, row: 3 },
  { n: 15, s: 'P', name: 'Phosphorus', m: 30.97, cat: 'Nonmetal', config: '[Ne] 3s² 3p³', desc: 'Essential for life. Found in DNA, ATP, and bones.', col: 15, row: 3 },
  { n: 16, s: 'S', name: 'Sulfur', m: 32.07, cat: 'Nonmetal', config: '[Ne] 3s² 3p⁴', desc: 'A yellow nonmetal used in fertilizers, gunpowder, and medicines.', col: 16, row: 3 },
  { n: 17, s: 'Cl', name: 'Chlorine', m: 35.45, cat: 'Halogen', config: '[Ne] 3s² 3p⁵', desc: 'A greenish-yellow gas used to disinfect water and bleach.', col: 17, row: 3 },
  { n: 18, s: 'Ar', name: 'Argon', m: 39.95, cat: 'Noble Gas', config: '[Ne] 3s² 3p⁶', desc: 'The third most abundant gas in Earth\'s atmosphere. Used in welding.', col: 18, row: 3 },
  { n: 19, s: 'K', name: 'Potassium', m: 39.10, cat: 'Alkali Metal', config: '[Ar] 4s¹', desc: 'An essential nutrient for plants and animals. Highly reactive.', col: 1, row: 4 },
  { n: 20, s: 'Ca', name: 'Calcium', m: 40.08, cat: 'Alkaline Earth', config: '[Ar] 4s²', desc: 'The fifth most abundant element in Earth\'s crust. Essential for bones.', col: 2, row: 4 },
  { n: 21, s: 'Sc', name: 'Scandium', m: 44.96, cat: 'Transition', config: '[Ar] 3d¹ 4s²', desc: 'A rare, silvery-white metal used in aerospace alloys.', col: 3, row: 4 },
  { n: 22, s: 'Ti', name: 'Titanium', m: 47.87, cat: 'Transition', config: '[Ar] 3d² 4s²', desc: 'Strong, lightweight, corrosion-resistant metal used in aircraft and implants.', col: 4, row: 4 },
  { n: 23, s: 'V', name: 'Vanadium', m: 50.94, cat: 'Transition', config: '[Ar] 3d³ 4s²', desc: 'Used in steel alloys and as a catalyst in chemical reactions.', col: 5, row: 4 },
  { n: 24, s: 'Cr', name: 'Chromium', m: 52.00, cat: 'Transition', config: '[Ar] 3d⁵ 4s¹', desc: 'Provides corrosion resistance and shiny finish to stainless steel.', col: 6, row: 4 },
  { n: 25, s: 'Mn', name: 'Manganese', m: 54.94, cat: 'Transition', config: '[Ar] 3d⁵ 4s²', desc: 'Essential for steel production and biological antioxidant systems.', col: 7, row: 4 },
  { n: 26, s: 'Fe', name: 'Iron', m: 55.85, cat: 'Transition', config: '[Ar] 3d⁶ 4s²', desc: 'The most widely used metal. Essential for blood and industry.', col: 8, row: 4 },
  { n: 27, s: 'Co', name: 'Cobalt', m: 58.93, cat: 'Transition', config: '[Ar] 3d⁷ 4s²', desc: 'Used in magnets, pigments, and lithium-ion battery cathodes.', col: 9, row: 4 },
  { n: 28, s: 'Ni', name: 'Nickel', m: 58.69, cat: 'Transition', config: '[Ar] 3d⁸ 4s²', desc: 'A silvery-white metal used in stainless steel and batteries.', col: 10, row: 4 },
  { n: 29, s: 'Cu', name: 'Copper', m: 63.55, cat: 'Transition', config: '[Ar] 3d¹⁰ 4s¹', desc: 'Excellent conductor of electricity. Used in wiring and plumbing.', col: 11, row: 4 },
  { n: 30, s: 'Zn', name: 'Zinc', m: 65.38, cat: 'Transition', config: '[Ar] 3d¹⁰ 4s²', desc: 'Used to galvanize steel and as an essential trace element.', col: 12, row: 4 },
  { n: 31, s: 'Ga', name: 'Gallium', m: 69.72, cat: 'Post-transition', config: '[Ar] 3d¹⁰ 4s² 4p¹', desc: 'Melts in your hand. Used in LEDs and solar panels.', col: 13, row: 4 },
  { n: 32, s: 'Ge', name: 'Germanium', m: 72.63, cat: 'Metalloid', config: '[Ar] 3d¹⁰ 4s² 4p²', desc: 'A semiconductor used in fiber optics and infrared optics.', col: 14, row: 4 },
  { n: 33, s: 'As', name: 'Arsenic', m: 74.92, cat: 'Metalloid', config: '[Ar] 3d¹⁰ 4s² 4p³', desc: 'A toxic metalloid used in semiconductors and pesticides.', col: 15, row: 4 },
  { n: 34, s: 'Se', name: 'Selenium', m: 78.97, cat: 'Nonmetal', config: '[Ar] 3d¹⁰ 4s² 4p⁴', desc: 'Essential trace element. Used in photocopiers and solar cells.', col: 16, row: 4 },
  { n: 35, s: 'Br', name: 'Bromine', m: 79.90, cat: 'Halogen', config: '[Ar] 3d¹⁰ 4s² 4p⁵', desc: 'A reddish-brown liquid at room temperature. Used in flame retardants.', col: 17, row: 4 },
  { n: 36, s: 'Kr', name: 'Krypton', m: 83.80, cat: 'Noble Gas', config: '[Ar] 3d¹⁰ 4s² 4p⁶', desc: 'A noble gas used in high-performance light bulbs and lasers.', col: 18, row: 4 },
  { n: 37, s: 'Rb', name: 'Rubidium', m: 85.47, cat: 'Alkali Metal', config: '[Kr] 5s¹', desc: 'A soft, silvery-white alkali metal used in atomic clocks.', col: 1, row: 5 },
  { n: 38, s: 'Sr', name: 'Strontium', m: 87.62, cat: 'Alkaline Earth', config: '[Kr] 5s²', desc: 'Produces a brilliant red flame. Used in fireworks and medical imaging.', col: 2, row: 5 },
  { n: 39, s: 'Y', name: 'Yttrium', m: 88.91, cat: 'Transition', config: '[Kr] 4d¹ 5s²', desc: 'Used in LEDs, phosphors, and high-temperature superconductors.', col: 3, row: 5 },
  { n: 40, s: 'Zr', name: 'Zirconium', m: 91.22, cat: 'Transition', config: '[Kr] 4d² 5s²', desc: 'Corrosion-resistant metal used in nuclear reactors and jewelry.', col: 4, row: 5 },
  { n: 41, s: 'Nb', name: 'Niobium', m: 92.91, cat: 'Transition', config: '[Kr] 4d⁴ 5s¹', desc: 'Used in superalloys for jet engines and MRI scanners.', col: 5, row: 5 },
  { n: 42, s: 'Mo', name: 'Molybdenum', m: 95.95, cat: 'Transition', config: '[Kr] 4d⁵ 5s¹', desc: 'High-melting-point metal used in steel alloys and catalysts.', col: 6, row: 5 },
  { n: 43, s: 'Tc', name: 'Technetium', m: 98, cat: 'Transition', config: '[Kr] 4d⁵ 5s²', desc: 'The lightest radioactive element. Used in medical imaging.', col: 7, row: 5 },
  { n: 44, s: 'Ru', name: 'Ruthenium', m: 101.1, cat: 'Transition', config: '[Kr] 4d⁷ 5s¹', desc: 'A rare metal used in electronics and as a chemical catalyst.', col: 8, row: 5 },
  { n: 45, s: 'Rh', name: 'Rhodium', m: 102.9, cat: 'Transition', config: '[Kr] 4d⁸ 5s¹', desc: 'A rare, silvery-white metal used in catalytic converters.', col: 9, row: 5 },
  { n: 46, s: 'Pd', name: 'Palladium', m: 106.4, cat: 'Transition', config: '[Kr] 4d¹⁰', desc: 'Absorbs hydrogen. Used in catalytic converters and electronics.', col: 10, row: 5 },
  { n: 47, s: 'Ag', name: 'Silver', m: 107.9, cat: 'Transition', config: '[Kr] 4d¹⁰ 5s¹', desc: 'The best conductor of electricity. Used in jewelry and electronics.', col: 11, row: 5 },
  { n: 48, s: 'Cd', name: 'Cadmium', m: 112.4, cat: 'Transition', config: '[Kr] 4d¹⁰ 5s²', desc: 'Used in rechargeable batteries and pigments. Toxic in high doses.', col: 12, row: 5 },
  { n: 49, s: 'In', name: 'Indium', m: 114.8, cat: 'Post-transition', config: '[Kr] 4d¹⁰ 5s² 5p¹', desc: 'A soft metal used in touchscreens and LCD displays.', col: 13, row: 5 },
  { n: 50, s: 'Sn', name: 'Tin', m: 118.7, cat: 'Post-transition', config: '[Kr] 4d¹⁰ 5s² 5p²', desc: 'Used since ancient times. Essential for soldering.', col: 14, row: 5 },
  { n: 51, s: 'Sb', name: 'Antimony', m: 121.8, cat: 'Metalloid', config: '[Kr] 4d¹⁰ 5s² 5p³', desc: 'Used in flame retardants, batteries, and semiconductors.', col: 15, row: 5 },
  { n: 52, s: 'Te', name: 'Tellurium', m: 127.6, cat: 'Metalloid', config: '[Kr] 4d¹⁰ 5s² 5p⁴', desc: 'A brittle metalloid used in solar panels and thermoelectric devices.', col: 16, row: 5 },
  { n: 53, s: 'I', name: 'Iodine', m: 126.9, cat: 'Halogen', config: '[Kr] 4d¹⁰ 5s² 5p⁵', desc: 'Essential for thyroid function. Used as an antiseptic.', col: 17, row: 5 },
  { n: 54, s: 'Xe', name: 'Xenon', m: 131.3, cat: 'Noble Gas', config: '[Kr] 4d¹⁰ 5s² 5p⁶', desc: 'A heavy noble gas used in high-intensity lamps and anesthesia.', col: 18, row: 5 },
  { n: 55, s: 'Cs', name: 'Caesium', m: 132.9, cat: 'Alkali Metal', config: '[Xe] 6s¹', desc: 'Used in atomic clocks. The most reactive stable metal.', col: 1, row: 6 },
  { n: 56, s: 'Ba', name: 'Barium', m: 137.3, cat: 'Alkaline Earth', config: '[Xe] 6s²', desc: 'Used in medical imaging and fireworks for green color.', col: 2, row: 6 },
  // Lanthanides placeholder at row 6, col 3-17
  { n: 57, s: 'La', name: 'Lanthanum', m: 138.9, cat: 'Lanthanide', config: '[Xe] 5d¹ 6s²', desc: 'The first lanthanide. Used in camera lenses and hybrid car batteries.', col: 3, row: 9 },
  { n: 58, s: 'Ce', name: 'Cerium', m: 140.1, cat: 'Lanthanide', config: '[Xe] 4f¹ 5d¹ 6s²', desc: 'The most abundant rare earth element. Used in catalytic converters.', col: 4, row: 9 },
  { n: 59, s: 'Pr', name: 'Praseodymium', m: 140.9, cat: 'Lanthanide', config: '[Xe] 4f³ 6s²', desc: 'Used in high-strength magnets and aircraft engines.', col: 5, row: 9 },
  { n: 60, s: 'Nd', name: 'Neodymium', m: 144.2, cat: 'Lanthanide', config: '[Xe] 4f⁴ 6s²', desc: 'Used in the strongest permanent magnets known.', col: 6, row: 9 },
  { n: 61, s: 'Pm', name: 'Promethium', m: 145, cat: 'Lanthanide', config: '[Xe] 4f⁵ 6s²', desc: 'A radioactive rare earth element. Used in nuclear batteries.', col: 7, row: 9 },
  { n: 62, s: 'Sm', name: 'Samarium', m: 150.4, cat: 'Lanthanide', config: '[Xe] 4f⁶ 6s²', desc: 'Used in magnets and as a neutron absorber in nuclear reactors.', col: 8, row: 9 },
  { n: 63, s: 'Eu', name: 'Europium', m: 152.0, cat: 'Lanthanide', config: '[Xe] 4f⁷ 6s²', desc: 'Produces red phosphors in TV and computer screens.', col: 9, row: 9 },
  { n: 64, s: 'Gd', name: 'Gadolinium', m: 157.3, cat: 'Lanthanide', config: '[Xe] 4f⁷ 5d¹ 6s²', desc: 'Used in MRI contrast agents and nuclear reactor control rods.', col: 10, row: 9 },
  { n: 65, s: 'Tb', name: 'Terbium', m: 158.9, cat: 'Lanthanide', config: '[Xe] 4f⁹ 6s²', desc: 'Used in green phosphors and solid-state devices.', col: 11, row: 9 },
  { n: 66, s: 'Dy', name: 'Dysprosium', m: 162.5, cat: 'Lanthanide', config: '[Xe] 4f¹⁰ 6s²', desc: 'Used in high-performance magnets and lasers.', col: 12, row: 9 },
  { n: 67, s: 'Ho', name: 'Holmium', m: 164.9, cat: 'Lanthanide', config: '[Xe] 4f¹¹ 6s²', desc: 'Has the highest magnetic permeability of any element.', col: 13, row: 9 },
  { n: 68, s: 'Er', name: 'Erbium', m: 167.3, cat: 'Lanthanide', config: '[Xe] 4f¹² 6s²', desc: 'Used in fiber optic amplifiers and pink-tinted glass.', col: 14, row: 9 },
  { n: 69, s: 'Tm', name: 'Thulium', m: 168.9, cat: 'Lanthanide', config: '[Xe] 4f¹³ 6s²', desc: 'The rarest stable lanthanide. Used in portable X-ray devices.', col: 15, row: 9 },
  { n: 70, s: 'Yb', name: 'Ytterbium', m: 173.1, cat: 'Lanthanide', config: '[Xe] 4f¹⁴ 6s²', desc: 'Used in atomic clocks and as a doping agent in fiber lasers.', col: 16, row: 9 },
  { n: 71, s: 'Lu', name: 'Lutetium', m: 175.0, cat: 'Lanthanide', config: '[Xe] 4f¹⁴ 5d¹ 6s²', desc: 'The densest and hardest lanthanide. Used in PET scanners.', col: 17, row: 9 },
  // Row 6, columns 4-18 (Hf-Rn) have n shifted
  { n: 72, s: 'Hf', name: 'Hafnium', m: 178.5, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d² 6s²', desc: 'Has a high neutron absorption cross-section. Used in nuclear control rods.', col: 4, row: 6 },
  { n: 73, s: 'Ta', name: 'Tantalum', m: 180.9, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d³ 6s²', desc: 'Highly corrosion-resistant. Used in electronics and medical implants.', col: 5, row: 6 },
  { n: 74, s: 'W', name: 'Tungsten', m: 183.8, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d⁴ 6s²', desc: 'Has the highest melting point of all metals. Used in light bulb filaments.', col: 6, row: 6 },
  { n: 75, s: 'Re', name: 'Rhenium', m: 186.2, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d⁵ 6s²', desc: 'One of the rarest elements. Used in jet engine superalloys.', col: 7, row: 6 },
  { n: 76, s: 'Os', name: 'Osmium', m: 190.2, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d⁶ 6s²', desc: 'The densest naturally occurring element. Used in alloys.', col: 8, row: 6 },
  { n: 77, s: 'Ir', name: 'Iridium', m: 192.2, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d⁷ 6s²', desc: 'One of the rarest and most corrosion-resistant metals.', col: 9, row: 6 },
  { n: 78, s: 'Pt', name: 'Platinum', m: 195.1, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d⁹ 6s¹', desc: 'A precious metal used in jewelry, catalytic converters, and medicine.', col: 10, row: 6 },
  { n: 79, s: 'Au', name: 'Gold', m: 197.0, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s¹', desc: 'A precious metal prized for millennia. Excellent conductor.', col: 11, row: 6 },
  { n: 80, s: 'Hg', name: 'Mercury', m: 200.6, cat: 'Transition', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s²', desc: 'The only metal liquid at room temperature. Used in thermometers.', col: 12, row: 6 },
  { n: 81, s: 'Tl', name: 'Thallium', m: 204.4, cat: 'Post-transition', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p¹', desc: 'A soft, toxic metal once used in rat poison and insecticides.', col: 13, row: 6 },
  { n: 82, s: 'Pb', name: 'Lead', m: 207.2, cat: 'Post-transition', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p²', desc: 'A dense, soft metal used in batteries, radiation shielding, and solder.', col: 14, row: 6 },
  { n: 83, s: 'Bi', name: 'Bismuth', m: 209.0, cat: 'Post-transition', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p³', desc: 'A brittle metal with low toxicity. Used in cosmetics and medicine.', col: 15, row: 6 },
  { n: 84, s: 'Po', name: 'Polonium', m: 209, cat: 'Metalloid', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁴', desc: 'A rare, highly radioactive metalloid discovered by Marie Curie.', col: 16, row: 6 },
  { n: 85, s: 'At', name: 'Astatine', m: 210, cat: 'Halogen', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁵', desc: 'The rarest naturally occurring element. Highly radioactive.', col: 17, row: 6 },
  { n: 86, s: 'Rn', name: 'Radon', m: 222, cat: 'Noble Gas', config: '[Xe] 4f¹⁴ 5d¹⁰ 6s² 6p⁶', desc: 'A radioactive noble gas. Second leading cause of lung cancer.', col: 18, row: 6 },
  { n: 87, s: 'Fr', name: 'Francium', m: 223, cat: 'Alkali Metal', config: '[Rn] 7s¹', desc: 'The most unstable naturally occurring element.', col: 1, row: 7 },
  { n: 88, s: 'Ra', name: 'Radium', m: 226, cat: 'Alkaline Earth', config: '[Rn] 7s²', desc: 'Radioactive. Once used in luminous paint and cancer therapy.', col: 2, row: 7 },
  // Actinides placeholder
  { n: 89, s: 'Ac', name: 'Actinium', m: 227, cat: 'Actinide', config: '[Rn] 6d¹ 7s²', desc: 'A radioactive metal that glows blue in the dark.', col: 3, row: 10 },
  { n: 90, s: 'Th', name: 'Thorium', m: 232.0, cat: 'Actinide', config: '[Rn] 6d² 7s²', desc: 'A fertile material that can be used in nuclear reactors.', col: 4, row: 10 },
  { n: 91, s: 'Pa', name: 'Protactinium', m: 231.0, cat: 'Actinide', config: '[Rn] 5f² 6d¹ 7s²', desc: 'One of the rarest and most expensive naturally occurring elements.', col: 5, row: 10 },
  { n: 92, s: 'U', name: 'Uranium', m: 238.0, cat: 'Actinide', config: '[Rn] 5f³ 6d¹ 7s²', desc: 'The primary fuel for nuclear reactors and atomic weapons.', col: 6, row: 10 },
  { n: 93, s: 'Np', name: 'Neptunium', m: 237, cat: 'Actinide', config: '[Rn] 5f⁴ 6d¹ 7s²', desc: 'The first transuranic element. A byproduct of nuclear reactors.', col: 7, row: 10 },
  { n: 94, s: 'Pu', name: 'Plutonium', m: 244, cat: 'Actinide', config: '[Rn] 5f⁶ 7s²', desc: 'Used in nuclear weapons and as fuel in some reactors.', col: 8, row: 10 },
  { n: 95, s: 'Am', name: 'Americium', m: 243, cat: 'Actinide', config: '[Rn] 5f⁷ 7s²', desc: 'Used in smoke detectors. Named after the Americas.', col: 9, row: 10 },
  { n: 96, s: 'Cm', name: 'Curium', m: 247, cat: 'Actinide', config: '[Rn] 5f⁷ 6d¹ 7s²', desc: 'Named after Marie and Pierre Curie. Used in space probes.', col: 10, row: 10 },
  { n: 97, s: 'Bk', name: 'Berkelium', m: 247, cat: 'Actinide', config: '[Rn] 5f⁹ 7s²', desc: 'Named after Berkeley, California where it was discovered.', col: 11, row: 10 },
  { n: 98, s: 'Cf', name: 'Californium', m: 251, cat: 'Actinide', config: '[Rn] 5f¹⁰ 7s²', desc: 'A strong neutron emitter used in oil well logging.', col: 12, row: 10 },
  { n: 99, s: 'Es', name: 'Einsteinium', m: 252, cat: 'Actinide', config: '[Rn] 5f¹¹ 7s²', desc: 'Named after Albert Einstein. Discovered in nuclear test debris.', col: 13, row: 10 },
  { n: 100, s: 'Fm', name: 'Fermium', m: 257, cat: 'Actinide', config: '[Rn] 5f¹² 7s²', desc: 'Named after Enrico Fermi. Heaviest element formed by neutron capture.', col: 14, row: 10 },
  { n: 101, s: 'Md', name: 'Mendelevium', m: 258, cat: 'Actinide', config: '[Rn] 5f¹³ 7s²', desc: 'Named after Dmitri Mendeleev, creator of the periodic table.', col: 15, row: 10 },
  { n: 102, s: 'No', name: 'Nobelium', m: 259, cat: 'Actinide', config: '[Rn] 5f¹⁴ 7s²', desc: 'Named after Alfred Nobel. Difficult to study due to short half-life.', col: 16, row: 10 },
  { n: 103, s: 'Lr', name: 'Lawrencium', m: 262, cat: 'Actinide', config: '[Rn] 5f¹⁴ 7s² 7p¹', desc: 'Named after Ernest Lawrence, inventor of the cyclotron.', col: 17, row: 10 },
  // Row 7, col 4-18 (Rf-Og)
  { n: 104, s: 'Rf', name: 'Rutherfordium', m: 267, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d² 7s²', desc: 'Named after Ernest Rutherford. Highly radioactive.', col: 4, row: 7 },
  { n: 105, s: 'Db', name: 'Dubnium', m: 268, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d³ 7s²', desc: 'Named after Dubna, Russia where it was discovered.', col: 5, row: 7 },
  { n: 106, s: 'Sg', name: 'Seaborgium', m: 269, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d⁴ 7s²', desc: 'Named after Glenn T. Seaborg. Synthetic superheavy element.', col: 6, row: 7 },
  { n: 107, s: 'Bh', name: 'Bohrium', m: 270, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d⁵ 7s²', desc: 'Named after Niels Bohr. Extremely radioactive.', col: 7, row: 7 },
  { n: 108, s: 'Hs', name: 'Hassium', m: 269, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d⁶ 7s²', desc: 'Named after Hesse, Germany. No practical uses.', col: 8, row: 7 },
  { n: 109, s: 'Mt', name: 'Meitnerium', m: 278, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d⁷ 7s²', desc: 'Named after Lise Meitner. No stable isotopes.', col: 9, row: 7 },
  { n: 110, s: 'Ds', name: 'Darmstadtium', m: 281, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d⁹ 7s¹', desc: 'Named after Darmstadt, Germany. Extremely short-lived.', col: 10, row: 7 },
  { n: 111, s: 'Rg', name: 'Roentgenium', m: 282, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s¹', desc: 'Named after Wilhelm Rontgen, discoverer of X-rays.', col: 11, row: 7 },
  { n: 112, s: 'Cn', name: 'Copernicium', m: 285, cat: 'Transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s²', desc: 'Named after Nicolaus Copernicus. Highly radioactive.', col: 12, row: 7 },
  { n: 113, s: 'Nh', name: 'Nihonium', m: 286, cat: 'Post-transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p¹', desc: 'Named after Japan (Nihon). First discovered in Asia.', col: 13, row: 7 },
  { n: 114, s: 'Fl', name: 'Flerovium', m: 289, cat: 'Post-transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p²', desc: 'Named after the Flerov Laboratory in Russia.', col: 14, row: 7 },
  { n: 115, s: 'Mc', name: 'Moscovium', m: 290, cat: 'Post-transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p³', desc: 'Named after Moscow. Highly unstable.', col: 15, row: 7 },
  { n: 116, s: 'Lv', name: 'Livermorium', m: 293, cat: 'Post-transition', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁴', desc: 'Named after Lawrence Livermore National Laboratory.', col: 16, row: 7 },
  { n: 117, s: 'Ts', name: 'Tennessine', m: 294, cat: 'Halogen', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁵', desc: 'Named after Tennessee. The second-heaviest known element.', col: 17, row: 7 },
  { n: 118, s: 'Og', name: 'Oganesson', m: 294, cat: 'Noble Gas', config: '[Rn] 5f¹⁴ 6d¹⁰ 7s² 7p⁶', desc: 'Named after Yuri Oganessian. The heaviest known element.', col: 18, row: 7 },
];

const CAT_COLORS: Record<string, string> = {
  'Alkali Metal': '#B84A4A',
  'Alkaline Earth': '#D4953A',
  'Transition': '#C9A84C',
  'Post-transition': '#5A9E6F',
  'Metalloid': '#4A9E9E',
  'Nonmetal': '#5A8AB8',
  'Halogen': '#7B6FB8',
  'Noble Gas': '#8A8578',
  'Lanthanide': '#6B6B5A',
  'Actinide': '#3D3D5C',
};

const CATEGORIES = Object.keys(CAT_COLORS);

export default function PeriodicTable() {
  const [selectedElement, setSelectedElement] = useState<Element | null>(null);
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState<string | null>(null);

  const filteredElements = useMemo(() => {
    if (!search && !filterCat) return null;
    return ELEMENTS.filter((e) => {
      const matchesSearch = !search || e.s.toLowerCase().includes(search.toLowerCase()) || e.name.toLowerCase().includes(search.toLowerCase()) || e.n.toString().includes(search);
      const matchesCat = !filterCat || e.cat === filterCat;
      return matchesSearch && matchesCat;
    });
  }, [search, filterCat]);

  const getOpacity = (el: Element) => {
    if (filteredElements === null) return 1;
    return filteredElements.some((f) => f.n === el.n) ? 1 : 0.15;
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Atom size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Periodic Table</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
            <Search size={12} style={{ color: 'var(--text-muted)' }} />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search element..."
              className="bg-transparent outline-none w-32 text-xs"
              style={{ color: 'var(--text-primary)' }}
            />
            {search && <button onClick={() => setSearch('')}><X size={12} /></button>}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 px-3 py-1.5 shrink-0" style={{ background: 'var(--surface)' }}>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCat(filterCat === cat ? null : cat)}
            className="flex items-center gap-1 text-[10px] transition-opacity"
            style={{ opacity: filterCat && filterCat !== cat ? 0.4 : 1 }}
          >
            <span className="w-2.5 h-2.5 rounded-sm" style={{ background: CAT_COLORS[cat] }} />
            <span style={{ color: filterCat === cat ? 'var(--accent-gold)' : 'var(--text-secondary)' }}>{cat}</span>
          </button>
        ))}
      </div>

      {/* Table grid */}
      <div className="flex-1 overflow-auto p-2">
        <div className="relative" style={{ minWidth: '800px' }}>
          {/* Main grid rows 1-7 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(18, 1fr)', gap: '2px' }}>
            {Array.from({ length: 126 }, (_, i) => {
              const col = (i % 18) + 1;
              const row = Math.floor(i / 18) + 1;
              const el = ELEMENTS.find((e) => e.row === row && e.col === col);
              if (!el) return <div key={`${row}-${col}`} />;
              const opacity = getOpacity(el);
              return (
                <button
                  key={el.n}
                  onClick={() => setSelectedElement(el)}
                  className="flex flex-col items-center justify-center p-1 rounded-sm transition-all hover:scale-110 hover:z-10"
                  style={{
                    background: CAT_COLORS[el.cat] + '20',
                    border: `1px solid ${CAT_COLORS[el.cat]}40`,
                    opacity,
                    minHeight: '42px',
                  }}
                >
                  <span className="text-[8px] self-start leading-none" style={{ color: 'var(--text-muted)' }}>{el.n}</span>
                  <span className="text-[11px] font-bold leading-tight" style={{ color: CAT_COLORS[el.cat] }}>{el.s}</span>
                  <span className="text-[6px] truncate max-w-full" style={{ color: 'var(--text-muted)' }}>{el.name}</span>
                </button>
              );
            })}
          </div>

          {/* Lanthanide and Actinide labels in row 6 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(18, 1fr)', gap: '2px', marginTop: '2px' }}>
            <div className="col-span-2 text-[9px] flex items-center justify-end pr-1" style={{ color: 'var(--text-muted)' }}>57-71</div>
            <div className="col-span-15 text-[9px] flex items-center" style={{ color: 'var(--accent-gold)' }}>Lanthanides</div>
          </div>
          {/* Lanthanides row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(18, 1fr)', gap: '2px', marginTop: '2px' }}>
            {Array.from({ length: 18 }, (_, i) => {
              const col = i + 1;
              const el = ELEMENTS.find((e) => e.row === 9 && e.col === col);
              if (!el) return <div key={`lan-${col}`} />;
              const opacity = getOpacity(el);
              return (
                <button
                  key={el.n}
                  onClick={() => setSelectedElement(el)}
                  className="flex flex-col items-center justify-center p-1 rounded-sm transition-all hover:scale-110 hover:z-10"
                  style={{
                    background: CAT_COLORS[el.cat] + '20',
                    border: `1px solid ${CAT_COLORS[el.cat]}40`,
                    opacity,
                    minHeight: '42px',
                  }}
                >
                  <span className="text-[8px] self-start leading-none" style={{ color: 'var(--text-muted)' }}>{el.n}</span>
                  <span className="text-[11px] font-bold leading-tight" style={{ color: CAT_COLORS[el.cat] }}>{el.s}</span>
                  <span className="text-[6px] truncate max-w-full" style={{ color: 'var(--text-muted)' }}>{el.name}</span>
                </button>
              );
            })}
          </div>

          {/* Actinides */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(18, 1fr)', gap: '2px', marginTop: '2px' }}>
            <div className="col-span-2 text-[9px] flex items-center justify-end pr-1" style={{ color: 'var(--text-muted)' }}>89-103</div>
            <div className="col-span-15 text-[9px] flex items-center" style={{ color: 'var(--accent-gold)' }}>Actinides</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(18, 1fr)', gap: '2px', marginTop: '2px' }}>
            {Array.from({ length: 18 }, (_, i) => {
              const col = i + 1;
              const el = ELEMENTS.find((e) => e.row === 10 && e.col === col);
              if (!el) return <div key={`act-${col}`} />;
              const opacity = getOpacity(el);
              return (
                <button
                  key={el.n}
                  onClick={() => setSelectedElement(el)}
                  className="flex flex-col items-center justify-center p-1 rounded-sm transition-all hover:scale-110 hover:z-10"
                  style={{
                    background: CAT_COLORS[el.cat] + '20',
                    border: `1px solid ${CAT_COLORS[el.cat]}40`,
                    opacity,
                    minHeight: '42px',
                  }}
                >
                  <span className="text-[8px] self-start leading-none" style={{ color: 'var(--text-muted)' }}>{el.n}</span>
                  <span className="text-[11px] font-bold leading-tight" style={{ color: CAT_COLORS[el.cat] }}>{el.s}</span>
                  <span className="text-[6px] truncate max-w-full" style={{ color: 'var(--text-muted)' }}>{el.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Detail panel */}
      {selectedElement && (
        <div className="shrink-0 p-3 flex gap-3" style={{ background: 'var(--surface)', borderTop: '1px solid var(--border-subtle)' }}>
          <div
            className="w-16 h-16 rounded-lg flex flex-col items-center justify-center shrink-0"
            style={{ background: CAT_COLORS[selectedElement.cat] + '20', border: `2px solid ${CAT_COLORS[selectedElement.cat]}` }}
          >
            <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{selectedElement.n}</span>
            <span className="text-xl font-bold" style={{ color: CAT_COLORS[selectedElement.cat] }}>{selectedElement.s}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-sm font-semibold">{selectedElement.name}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full" style={{ background: CAT_COLORS[selectedElement.cat] + '20', color: CAT_COLORS[selectedElement.cat] }}>
                {selectedElement.cat}
              </span>
            </div>
            <div className="flex gap-4 text-[10px]" style={{ color: 'var(--text-muted)' }}>
              <span>Atomic Mass: <span className="font-mono" style={{ color: 'var(--text-primary)' }}>{selectedElement.m}</span></span>
              <span>Config: <span className="font-mono" style={{ color: 'var(--text-primary)' }}>{selectedElement.config}</span></span>
            </div>
            <p className="text-[10px] mt-1 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{selectedElement.desc}</p>
          </div>
        </div>
      )}
    </div>
  );
}
