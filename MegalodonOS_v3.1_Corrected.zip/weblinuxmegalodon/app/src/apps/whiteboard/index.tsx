import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Pencil,
  Eraser,
  Minus,
  Square,
  Circle,
  ArrowRight,
  Type,
  Trash2,
  Download,
  Undo2,
  Redo2,
  StickyNote,
  ZoomIn,
  ZoomOut,
  X,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
type Tool = 'pencil' | 'eraser' | 'line' | 'rect' | 'circle' | 'arrow' | 'text' | 'sticky';

interface Point {
  x: number;
  y: number;
}

interface DrawElement {
  id: string;
  type: Tool;
  points: Point[];
  color: string;
  width: number;
  text?: string;
}

interface StickyNoteData {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const COLORS = [
  '#1A1A26', '#B84A4A', '#5A9E6F', '#5A8AB8', '#C9A84C',
  '#D4953A', '#7B6FB8', '#4A9E9E', '#8A8578', '#E8E4DC',
];

const STICKY_COLORS = ['#FEF3C7', '#DBEAFE', '#D1FAE5', '#FCE7F3', '#F3E8FF'];

const CANVAS_WIDTH = 2000;
const CANVAS_HEIGHT = 1500;

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
function generateId() {
  return `wb-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function getDistance(p1: Point, p2: Point): number {
  return Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2);
}

/* ------------------------------------------------------------------ */
/*  Main Whiteboard App                                                */
/* ------------------------------------------------------------------ */
export default function WhiteboardApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [tool, setTool] = useState<Tool>('pencil');
  const [color, setColor] = useState('#1A1A26');
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [elements, setElements] = useState<DrawElement[]>([]);
  const [stickyNotes, setStickyNotes] = useState<StickyNoteData[]>([]);
  const [history, setHistory] = useState<DrawElement[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentElement, setCurrentElement] = useState<DrawElement | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<Point>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<Point>({ x: 0, y: 0 });
  const [textInput, setTextInput] = useState<{ x: number; y: number } | null>(null);
  const [textValue, setTextValue] = useState('');
  const [editingSticky, setEditingSticky] = useState<string | null>(null);

  const pushHistory = useCallback((newElements: DrawElement[]) => {
    setHistory((prev) => {
      const next = prev.slice(0, historyIndex + 1);
      next.push([...newElements]);
      return next.slice(-30); // Keep last 30 states
    });
    setHistoryIndex((prev) => Math.min(prev + 1, 29));
  }, [historyIndex]);

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements([...history[historyIndex - 1]]);
    } else if (historyIndex === 0) {
      setHistoryIndex(-1);
      setElements([]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements([...history[historyIndex + 1]]);
    }
  };

  const getCanvasPoint = useCallback(
    (e: React.MouseEvent): Point => {
      const canvas = canvasRef.current;
      if (!canvas) return { x: 0, y: 0 };
      const rect = canvas.getBoundingClientRect();
      return {
        x: (e.clientX - rect.left) / zoom,
        y: (e.clientY - rect.top) / zoom,
      };
    },
    [zoom]
  );

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || (e.button === 0 && e.altKey) || (e.button === 0 && tool === 'sticky')) {
      // Pan
      if (e.button === 0 && tool === 'sticky') {
        const pt = getCanvasPoint(e);
        // Place sticky note
        setStickyNotes((prev) => [
          ...prev,
          { id: generateId(), x: pt.x, y: pt.y, text: 'Click to edit', color: STICKY_COLORS[Math.floor(Math.random() * STICKY_COLORS.length)] },
        ]);
        return;
      }
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
      return;
    }
    if (e.button !== 0) return;

    const pt = getCanvasPoint(e);

    if (tool === 'text') {
      setTextInput(pt);
      setTextValue('');
      return;
    }

    setIsDrawing(true);
    const newEl: DrawElement = {
      id: generateId(),
      type: tool,
      points: [pt],
      color,
      width: strokeWidth,
    };
    setCurrentElement(newEl);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
      return;
    }
    if (!isDrawing || !currentElement) return;

    const pt = getCanvasPoint(e);
    if (tool === 'pencil' || tool === 'eraser') {
      setCurrentElement({
        ...currentElement,
        points: [...currentElement.points, pt],
      });
    } else {
      setCurrentElement({
        ...currentElement,
        points: [currentElement.points[0], pt],
      });
    }
  };

  const handleMouseUp = () => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }
    if (!isDrawing || !currentElement) return;

    setIsDrawing(false);
    const newElements = [...elements, currentElement];
    setElements(newElements);
    pushHistory(newElements);
    setCurrentElement(null);
  };

  // Drawing on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Dot grid
    ctx.fillStyle = '#E5E5E5';
    for (let x = 0; x < CANVAS_WIDTH; x += 20) {
      for (let y = 0; y < CANVAS_HEIGHT; y += 20) {
        ctx.beginPath();
        ctx.arc(x, y, 0.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const drawElement = (el: DrawElement) => {
      ctx.strokeStyle = el.type === 'eraser' ? '#FFFFFF' : el.color;
      ctx.fillStyle = el.type === 'eraser' ? '#FFFFFF' : el.color;
      ctx.lineWidth = el.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (el.type === 'pencil' || el.type === 'eraser') {
        if (el.points.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(el.points[0].x, el.points[0].y);
        for (let i = 1; i < el.points.length; i++) {
          ctx.lineTo(el.points[i].x, el.points[i].y);
        }
        ctx.stroke();
      } else if (el.type === 'line') {
        if (el.points.length < 2) return;
        ctx.beginPath();
        ctx.moveTo(el.points[0].x, el.points[0].y);
        ctx.lineTo(el.points[1].x, el.points[1].y);
        ctx.stroke();
      } else if (el.type === 'rect') {
        if (el.points.length < 2) return;
        const x = Math.min(el.points[0].x, el.points[1].x);
        const y = Math.min(el.points[0].y, el.points[1].y);
        const w = Math.abs(el.points[1].x - el.points[0].x);
        const h = Math.abs(el.points[1].y - el.points[0].y);
        ctx.strokeRect(x, y, w, h);
      } else if (el.type === 'circle') {
        if (el.points.length < 2) return;
        const radius = getDistance(el.points[0], el.points[1]);
        ctx.beginPath();
        ctx.arc(el.points[0].x, el.points[0].y, radius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (el.type === 'arrow') {
        if (el.points.length < 2) return;
        const from = el.points[0];
        const to = el.points[1];
        const angle = Math.atan2(to.y - from.y, to.x - from.x);
        const headLen = 12;

        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x, to.y);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(to.x, to.y);
        ctx.lineTo(to.x - headLen * Math.cos(angle - Math.PI / 6), to.y - headLen * Math.sin(angle - Math.PI / 6));
        ctx.moveTo(to.x, to.y);
        ctx.lineTo(to.x - headLen * Math.cos(angle + Math.PI / 6), to.y - headLen * Math.sin(angle + Math.PI / 6));
        ctx.stroke();
      } else if (el.type === 'text' && el.text) {
        ctx.font = `${el.width * 8 + 10}px Inter, sans-serif`;
        ctx.fillStyle = el.color;
        ctx.fillText(el.text, el.points[0].x, el.points[0].y);
      }
    };

    elements.forEach(drawElement);
    if (currentElement) drawElement(currentElement);
  }, [elements, currentElement]);

  const handleClear = () => {
    setElements([]);
    setStickyNotes([]);
    pushHistory([]);
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `whiteboard-${Date.now()}.png`;
    a.click();
  };

  const handleTextSubmit = () => {
    if (!textInput || !textValue.trim()) {
      setTextInput(null);
      return;
    }
    const newEl: DrawElement = {
      id: generateId(),
      type: 'text',
      points: [textInput],
      color,
      width: strokeWidth,
      text: textValue.trim(),
    };
    const newElements = [...elements, newEl];
    setElements(newElements);
    pushHistory(newElements);
    setTextInput(null);
    setTextValue('');
  };

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.1, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.1, 0.3));

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
      e.preventDefault();
      if (e.shiftKey) handleRedo();
      else handleUndo();
    }
  }, [historyIndex, history]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const tools: { id: Tool; icon: typeof Pencil; label: string }[] = [
    { id: 'pencil', icon: Pencil, label: 'Pencil' },
    { id: 'eraser', icon: Eraser, label: 'Eraser' },
    { id: 'line', icon: Minus, label: 'Line' },
    { id: 'rect', icon: Square, label: 'Rectangle' },
    { id: 'circle', icon: Circle, label: 'Circle' },
    { id: 'arrow', icon: ArrowRight, label: 'Arrow' },
    { id: 'text', icon: Type, label: 'Text' },
    { id: 'sticky', icon: StickyNote, label: 'Sticky' },
  ];

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col relative overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E] bg-[#1A1A26] z-10">
        <div className="flex items-center gap-1">
          {tools.map((t) => (
            <button
              key={t.id}
              onClick={() => setTool(t.id)}
              className={`p-1.5 rounded-lg transition-colors ${
                tool === t.id ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'text-[#8A8578] hover:bg-[#222235]'
              }`}
              title={t.label}
            >
              <t.icon className="w-4 h-4" />
            </button>
          ))}

          <div className="w-px h-5 bg-[#2A2A3E] mx-1.5" />

          {/* Colors */}
          <div className="flex gap-0.5">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-5 h-5 rounded border-2 transition-all ${
                  color === c ? 'border-[#E8E4DC] scale-110' : 'border-transparent'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          <div className="w-px h-5 bg-[#2A2A3E] mx-1.5" />

          {/* Stroke width */}
          <label className="text-[10px] text-[#8A8578] mr-1">Width</label>
          <input
            type="range"
            min={1}
            max={10}
            value={strokeWidth}
            onChange={(e) => setStrokeWidth(parseInt(e.target.value))}
            className="w-20 accent-[#C9A84C]"
          />
          <span className="text-[10px] text-[#8A8578] w-4">{strokeWidth}</span>
        </div>

        <div className="flex items-center gap-1">
          <button onClick={handleUndo} className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors text-[#8A8578]" title="Undo (Ctrl+Z)">
            <Undo2 className="w-4 h-4" />
          </button>
          <button onClick={handleRedo} className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors text-[#8A8578]" title="Redo (Ctrl+Shift+Z)">
            <Redo2 className="w-4 h-4" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <button onClick={handleZoomOut} className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors text-[#8A8578]">
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-[10px] text-[#8A8578] w-8 text-center">{Math.round(zoom * 100)}%</span>
          <button onClick={handleZoomIn} className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors text-[#8A8578]">
            <ZoomIn className="w-4 h-4" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <button onClick={handleClear} className="p-1.5 hover:bg-[#B84A4A]/20 rounded-lg transition-colors text-[#B84A4A]" title="Clear">
            <Trash2 className="w-4 h-4" />
          </button>
          <button onClick={handleExport} className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors text-[#8A8578]" title="Export PNG">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Canvas container */}
      <div
        ref={containerRef}
        className="flex-1 overflow-hidden relative bg-[#0A0A0F]"
        style={{ cursor: isPanning ? 'grabbing' : tool === 'text' ? 'text' : tool === 'sticky' ? 'crosshair' : 'default' }}
      >
        <div
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: '0 0',
            width: CANVAS_WIDTH,
            height: CANVAS_HEIGHT,
          }}
        >
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="absolute top-0 left-0"
            style={{ width: CANVAS_WIDTH, height: CANVAS_HEIGHT }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          />

          {/* Sticky notes overlay */}
          {stickyNotes.map((note) => (
            <div
              key={note.id}
              className="absolute rounded shadow-md"
              style={{
                left: note.x,
                top: note.y,
                width: 160,
                minHeight: 120,
                backgroundColor: note.color,
                zIndex: editingSticky === note.id ? 100 : 10,
              }}
            >
              <div className="flex items-center justify-between px-2 py-1 border-b border-black/10">
                <StickyNote className="w-3 h-3 text-black/40" />
                <button
                  onClick={() => setStickyNotes((prev) => prev.filter((n) => n.id !== note.id))}
                  className="p-0.5 hover:bg-black/10 rounded transition-colors"
                >
                  <X className="w-3 h-3 text-black/50" />
                </button>
              </div>
              {editingSticky === note.id ? (
                <textarea
                  autoFocus
                  value={note.text}
                  onChange={(e) => setStickyNotes((prev) => prev.map((n) => n.id === note.id ? { ...n, text: e.target.value } : n))}
                  onBlur={() => setEditingSticky(null)}
                  className="w-full h-[90px] bg-transparent text-[#1A1A26] text-xs p-2 outline-none resize-none"
                />
              ) : (
                <div
                  onClick={() => setEditingSticky(note.id)}
                  className="text-[#1A1A26] text-xs p-2 min-h-[90px] cursor-text whitespace-pre-wrap"
                >
                  {note.text}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Text input overlay */}
        {textInput && (
          <div
            className="absolute z-50"
            style={{
              left: textInput.x * zoom + pan.x,
              top: textInput.y * zoom + pan.y,
            }}
          >
            <input
              autoFocus
              value={textValue}
              onChange={(e) => setTextValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleTextSubmit(); if (e.key === 'Escape') setTextInput(null); }}
              onBlur={handleTextSubmit}
              placeholder="Type text..."
              className="bg-transparent border-b-2 border-[#C9A84C] text-[#1A1A26] outline-none text-sm font-medium placeholder-[#8A8578]"
              style={{ color, fontSize: strokeWidth * 8 + 10 }}
            />
          </div>
        )}

        {/* Pan hint */}
        <div className="absolute bottom-3 right-3 text-[10px] text-[#4D4A42] bg-[#1A1A26]/80 px-2 py-1 rounded">
          Alt+Drag to pan · Ctrl+Z to undo
        </div>
      </div>
    </div>
  );
}
