import { useState, useCallback, useMemo } from 'react';
import {
  Braces, Copy, Check, Search, AlertCircle,
  ChevronDown, ChevronRight, FileJson, Minimize2, Maximize2
} from 'lucide-react';

const SAMPLE_JSON = {
  "users": [
    { "id": 1, "name": "Alice Johnson", "email": "alice@cornstone.dev", "active": true, "role": "admin", "loginCount": 142 },
    { "id": 2, "name": "Bob Smith", "email": "bob@cornstone.dev", "active": false, "role": "user", "loginCount": 89 },
    { "id": 3, "name": "Carol Williams", "email": "carol@cornstone.dev", "active": true, "role": "editor", "loginCount": 267 },
    { "id": 4, "name": "David Brown", "email": "david@cornstone.dev", "active": true, "role": "user", "loginCount": 34 }
  ],
  "metadata": {
    "total": 4,
    "page": 1,
    "perPage": 10,
    "version": "2.1.0",
    "generatedAt": "2025-01-15T09:30:00Z"
  },
  "settings": {
    "theme": "dark",
    "notifications": true,
    "language": "en",
    "features": { "starMap": true, "costOS": true, "whiteboard": false }
  }
};

function getValueType(value: unknown): string {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  return typeof value;
}

function getPreview(value: unknown): string {
  const t = getValueType(value);
  if (t === 'array') return `[${(value as unknown[]).length} items]`;
  if (t === 'object') return `{${Object.keys(value as object).length} keys}`;
  if (t === 'string') return `"${String(value)}"`;
  return String(value);
}

const COLORS: Record<string, string> = {
  string: '#5A9E6F',
  number: '#4A9E9E',
  boolean: '#7B6FB8',
  null: '#7B6FB8',
  key: '#C9A84C',
};

/* ── Tree Node Component ── */
function TreeNode({
  nodeKey,
  value,
  depth,
  collapsedPaths,
  togglePath,
  searchQuery,
}: {
  nodeKey: string;
  value: unknown;
  depth: number;
  collapsedPaths: Set<string>;
  togglePath: (p: string) => void;
  searchQuery: string;
}) {
  const type = getValueType(value);
  const isComposite = type === 'object' || type === 'array';
  const path = depth === 0 ? nodeKey : '';
  const isCollapsed = collapsedPaths.has(path);

  const highlightText = (text: string) => {
    if (!searchQuery) return text;
    const parts = text.split(new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === searchQuery.toLowerCase()
        ? <mark key={i} className="bg-[#C9A84C]/30 text-[#E8E4DC]">{part}</mark>
        : <span key={i}>{part}</span>
    );
  };

  if (!isComposite) {
    return (
      <div className="flex items-start gap-1 py-0.5" style={{ paddingLeft: `${depth * 16 + 8}px` }}>
        <span className="text-[#C9A84C] shrink-0">{highlightText(nodeKey)}:</span>
        <span style={{ color: COLORS[type] || '#E8E4DC' }} className="break-all">
          {type === 'string' ? highlightText(`"${value as string}"`) : highlightText(String(value))}
        </span>
      </div>
    );
  }

  const entries = type === 'array'
    ? (value as unknown[]).map((v, i) => [String(i), v] as [string, unknown])
    : Object.entries(value as object);

  return (
    <div>
      <div
        className="flex items-center gap-1 py-0.5 cursor-pointer hover:bg-[#1A1A26]/50 rounded"
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => togglePath(path)}
      >
        {isCollapsed ? (
          <ChevronRight className="w-3.5 h-3.5 text-[#8A8578] shrink-0" />
        ) : (
          <ChevronDown className="w-3.5 h-3.5 text-[#8A8578] shrink-0" />
        )}
        <span className="text-[#C9A84C]">{highlightText(nodeKey)}:</span>
        {isCollapsed && (
          <span className="text-[#8A8578] text-xs ml-1">{getPreview(value)}</span>
        )}
      </div>
      {!isCollapsed && entries.map(([k, v]) => (
        <TreeNode
          key={`${path}.${k}`}
          nodeKey={k}
          value={v}
          depth={depth + 1}
          collapsedPaths={collapsedPaths}
          togglePath={togglePath}
          searchQuery={searchQuery}
        />
      ))}
    </div>
  );
}

export default function JSONViewer() {
  const [input, setInput] = useState(JSON.stringify(SAMPLE_JSON, null, 2));
  const [viewMode, setViewMode] = useState<'tree' | 'raw'>('tree');
  const [collapsedPaths, setCollapsedPaths] = useState<Set<string>>(new Set());
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const parsed = useMemo(() => {
    try {
      const data = JSON.parse(input);
      setError('');
      return data;
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid JSON');
      return null;
    }
  }, [input]);

  const togglePath = useCallback((path: string) => {
    setCollapsedPaths(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  }, []);

  const formatJSON = useCallback(() => {
    if (!parsed) return;
    setInput(JSON.stringify(parsed, null, 2));
  }, [parsed]);

  const minifyJSON = useCallback(() => {
    if (!parsed) return;
    setInput(JSON.stringify(parsed));
  }, [parsed]);

  const validateJSON = useCallback(() => {
    try {
      JSON.parse(input);
      setError('');
      return true;
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid JSON');
      return false;
    }
  }, [input]);

  const copyJSON = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* noop */ }
  }, [input]);

  const collapseAll = useCallback(() => {
    if (!parsed) return;
    const paths = new Set<string>();
    function collect(obj: unknown, path: string) {
      const t = getValueType(obj);
      if (t === 'object' || t === 'array') {
        paths.add(path);
        const entries = t === 'array'
          ? (obj as unknown[]).map((v, i) => [String(i), v] as [string, unknown])
          : Object.entries(obj as object);
        entries.forEach(([k, v]) => collect(v, `${path}.${k}`));
      }
    }
    collect(parsed, '');
    setCollapsedPaths(paths);
  }, [parsed]);

  const expandAll = useCallback(() => {
    setCollapsedPaths(new Set());
  }, []);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
          onClick={formatJSON}
        >
          <Maximize2 className="w-3 h-3" /> Format
        </button>
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
          onClick={minifyJSON}
        >
          <Minimize2 className="w-3 h-3" /> Minify
        </button>
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
          onClick={validateJSON}
        >
          <FileJson className="w-3 h-3" /> Validate
        </button>
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
          onClick={copyJSON}
        >
          {copied ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
        <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
        <button
          className={`px-2.5 py-1.5 text-xs rounded border transition-colors ${
            viewMode === 'tree' ? 'bg-[#C9A84C]/20 border-[#C9A84C] text-[#C9A84C]' : 'bg-[#1A1A26] border-[#2A2A3E] hover:bg-[#222235]'
          }`}
          onClick={() => setViewMode('tree')}
        >
          Tree
        </button>
        <button
          className={`px-2.5 py-1.5 text-xs rounded border transition-colors ${
            viewMode === 'raw' ? 'bg-[#C9A84C]/20 border-[#C9A84C] text-[#C9A84C]' : 'bg-[#1A1A26] border-[#2A2A3E] hover:bg-[#222235]'
          }`}
          onClick={() => setViewMode('raw')}
        >
          Raw
        </button>
        <div className="flex-1" />
        {viewMode === 'tree' && (
          <div className="flex items-center gap-1">
            <button
              className="px-2 py-1 text-[10px] rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E]"
              onClick={collapseAll}
            >
              Collapse
            </button>
            <button
              className="px-2 py-1 text-[10px] rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E]"
              onClick={expandAll}
            >
              Expand
            </button>
          </div>
        )}
      </div>

      {/* Search bar */}
      <div className="flex items-center gap-2 px-3 py-1.5 bg-[#0A0A0F] border-b border-[#2A2A3E] shrink-0">
        <Search className="w-3.5 h-3.5 text-[#4D4A42]" />
        <input
          type="text"
          className="flex-1 bg-transparent text-xs outline-none placeholder-[#4D4A42]"
          placeholder="Search in JSON..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 px-3 py-2 bg-[#B84A4A]/10 border-b border-[#B84A4A]/20 text-xs text-[#B84A4A] shrink-0">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          {error}
        </div>
      )}

      {/* Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Input panel */}
        <div className="w-1/2 flex flex-col border-r border-[#2A2A3E]">
          <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
            Input
          </div>
          <textarea
            className="flex-1 bg-[#030305] text-xs font-mono p-3 resize-none outline-none text-[#E8E4DC] whitespace-pre overflow-auto"
            value={input}
            onChange={e => setInput(e.target.value)}
            spellCheck={false}
          />
        </div>

        {/* View panel */}
        <div className="w-1/2 flex flex-col overflow-hidden">
          <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
            {viewMode === 'tree' ? 'Tree View' : 'Formatted'}
          </div>
          <div className="flex-1 overflow-auto p-2 font-mono text-xs">
            {parsed ? (
              viewMode === 'tree' ? (
                <div>
                  {Object.entries(parsed).map(([key, value]) => (
                    <TreeNode
                      key={key}
                      nodeKey={key}
                      value={value}
                      depth={0}
                      collapsedPaths={collapsedPaths}
                      togglePath={togglePath}
                      searchQuery={searchQuery}
                    />
                  ))}
                </div>
              ) : (
                <pre className="whitespace-pre-wrap break-all">
                  {JSON.stringify(parsed, null, 2)}
                </pre>
              )
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-[#4D4A42]">
                <Braces className="w-10 h-10 mb-2 opacity-30" />
                <p className="text-xs">Enter valid JSON to view</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Status */}
      {parsed && (
        <div className="flex items-center justify-between px-3 py-1 bg-[#12121A] border-t border-[#2A2A3E] text-[10px] text-[#8A8578] shrink-0">
          <span className="text-[#5A9E6F]">Valid JSON</span>
          <span>{typeof parsed === 'object' && parsed !== null ? `${Object.keys(parsed).length} top-level keys` : ''}</span>
        </div>
      )}
    </div>
  );
}
