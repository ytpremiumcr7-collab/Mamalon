import { X, ExternalLink, Users, Calendar, BookOpen } from 'lucide-react';
import { COMMUNITIES } from '../data/papers';
import type { PaperNode, CitationEdge } from '../data/papers';

interface DetailCardProps {
  paper: PaperNode;
  edges: CitationEdge[];
  allPapers: PaperNode[];
  onClose: () => void;
  onSelectNeighbor: (paper: PaperNode) => void;
}

export default function DetailCard({ paper, edges, allPapers, onClose, onSelectNeighbor }: DetailCardProps) {
  const communityColor = COMMUNITIES[paper.community]?.color || '#C9A84C';
  const communityLabel = COMMUNITIES[paper.community]?.label || paper.community;

  // Find connected papers
  const neighborIds = edges
    .filter((e) => e.source === paper.id || e.target === paper.id)
    .map((e) => (e.source === paper.id ? e.target : e.source));

  const neighbors = allPapers.filter((p) => neighborIds.includes(p.id));

  return (
    <div className="absolute top-0 right-0 bottom-0 w-[380px] bg-[rgba(10,10,15,0.92)] backdrop-blur-md border-l border-[#C9A84C]/30 flex flex-col z-10">
      {/* Header */}
      <div className="flex items-start justify-between p-5 border-b border-[#2A2A3E]">
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold text-[#E8E4DC] leading-snug pr-2">{paper.title}</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-[#222235] rounded transition-colors shrink-0"
        >
          <X className="w-4 h-4 text-[#8A8578] hover:text-[#E8E4DC]" />
        </button>
      </div>

      {/* Meta */}
      <div className="px-5 py-3 border-b border-[#2A2A3E] flex items-center gap-3 flex-wrap">
        <span
          className="px-2 py-0.5 rounded-full text-[10px] font-medium"
          style={{ backgroundColor: `${communityColor}20`, color: communityColor, border: `1px solid ${communityColor}40` }}
        >
          {communityLabel}
        </span>
        <span className="flex items-center gap-1 text-[11px] text-[#8A8578]">
          <Calendar className="w-3 h-3" />
          {paper.year}
        </span>
        <span className="flex items-center gap-1 text-[11px] text-[#8A8578]">
          <BookOpen className="w-3 h-3" />
          Citado {paper.citationCount.toLocaleString()} veces
        </span>
      </div>

      {/* Authors */}
      <div className="px-5 py-3 border-b border-[#2A2A3E]">
        <div className="flex items-center gap-1.5 mb-1.5">
          <Users className="w-3 h-3 text-[#8A8578]" />
          <span className="text-[10px] uppercase text-[#8A8578]">Autores</span>
        </div>
        <div className="text-xs text-[#E8E4DC] leading-relaxed">
          {paper.authors.join(', ')}
        </div>
      </div>

      {/* Abstract */}
      <div className="px-5 py-3 border-b border-[#2A2A3E] flex-1 overflow-auto">
        <span className="text-[10px] uppercase text-[#8A8578] mb-1.5 block">Resumen</span>
        <p className="text-xs text-[#E8E4DC]/90 leading-relaxed">{paper.abstract}</p>
      </div>

      {/* Keywords */}
      <div className="px-5 py-3 border-b border-[#2A2A3E]">
        <span className="text-[10px] uppercase text-[#8A8578] mb-1.5 block">Palabras clave</span>
        <div className="flex flex-wrap gap-1.5">
          {paper.keywords.map((kw) => (
            <span key={kw} className="px-2 py-0.5 bg-[#222235] text-[#8A8578] text-[10px] rounded-full">
              {kw}
            </span>
          ))}
        </div>
      </div>

      {/* Neighbors */}
      {neighbors.length > 0 && (
        <div className="px-5 py-3 border-b border-[#2A2A3E] max-h-36 overflow-auto">
          <span className="text-[10px] uppercase text-[#8A8578] mb-1.5 block">Papers conectados ({neighbors.length})</span>
          <div className="space-y-1.5">
            {neighbors.map((n) => (
              <button
                key={n.id}
                onClick={() => onSelectNeighbor(n)}
                className="w-full text-left px-2 py-1.5 rounded hover:bg-[#222235] transition-colors group"
              >
                <div className="text-[11px] text-[#E8E4DC] group-hover:text-[#C9A84C] truncate leading-snug">
                  {n.title}
                </div>
                <div className="text-[10px] text-[#4D4A42]">{n.authors[0]} et al., {n.year}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="p-4 flex gap-2">
        <a
          href={paper.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-[#C9A84C] text-[#030305] text-xs font-semibold rounded hover:bg-[#D4B85A] transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Abrir Paper
        </a>
      </div>
    </div>
  );
}
