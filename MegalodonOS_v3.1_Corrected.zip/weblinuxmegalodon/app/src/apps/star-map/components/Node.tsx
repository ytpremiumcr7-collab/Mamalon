import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useStarMapStore } from '../../../stores/useStarMapStore';
import { COMMUNITIES } from '../data/papers';
import type { PaperNode } from '../data/papers';

interface NodeProps {
  paper: PaperNode;
  neighborIds: Set<string>;
  onClick: (paper: PaperNode) => void;
}

export default function Node({ paper, neighborIds, onClick }: NodeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const selectedNode = useStarMapStore((s) => s.selectedNode);
  const activeCommunity = useStarMapStore((s) => s.activeCommunity);

  const isSelected = selectedNode === paper.id;
  const isNeighbor = neighborIds.has(paper.id);
  const isDimmed = activeCommunity !== null && activeCommunity !== paper.community;

  // Compute opacity based on state
  const opacity = useMemo(() => {
    if (isDimmed) return 0.1;
    if (isSelected) return 1;
    if (isNeighbor) return 0.9;
    if (selectedNode) return 0.2;
    return 0.75;
  }, [isDimmed, isSelected, isNeighbor, selectedNode]);

  // Compute scale
  const scale = useMemo(() => {
    const base = 0.6 + Math.min(paper.citationCount / 5000, 1.2);
    if (isSelected) return base * 1.8;
    if (hovered) return base * 1.5;
    if (isDimmed) return base * 0.6;
    return base;
  }, [isSelected, hovered, isDimmed, paper.citationCount]);

  const communityColor = COMMUNITIES[paper.community]?.color || '#C9A84C';

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.scale.lerp(new THREE.Vector3(scale, scale, scale), delta * 5);
      const mat = meshRef.current.material as THREE.MeshBasicMaterial;
      mat.opacity = THREE.MathUtils.lerp(mat.opacity, opacity, delta * 5);
    }
    if (ringRef.current) {
      ringRef.current.visible = isSelected;
      if (isSelected) {
        ringRef.current.rotation.z += delta * 1.5;
        ringRef.current.scale.lerp(new THREE.Vector3(1.5, 1.5, 1.5), delta * 5);
      }
    }
  });

  return (
    <group position={paper.position}>
      {/* Glow sphere */}
      <mesh
        ref={meshRef}
        onClick={(e) => {
          e.stopPropagation();
          onClick(paper);
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          setHovered(true);
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          setHovered(false);
          document.body.style.cursor = 'default';
        }}
      >
        <sphereGeometry args={[1, 16, 16]} />
        <meshBasicMaterial
          color={communityColor}
          transparent
          opacity={0.75}
          depthWrite={false}
        />
      </mesh>

      {/* Emissive inner core */}
      <mesh scale={scale * 0.4}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshBasicMaterial
          color="#FFFFFF"
          transparent
          opacity={Math.min(opacity * 1.2, 1)}
          depthWrite={false}
        />
      </mesh>

      {/* Selection ring */}
      <mesh ref={ringRef} visible={false} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2, 0.06, 8, 32]} />
        <meshBasicMaterial
          color="#C9A84C"
          transparent
          opacity={0.8}
          depthWrite={false}
        />
      </mesh>

      {/* Label on hover/selected */}
      {(hovered || isSelected) && (
        <NodeLabel text={paper.title} color={communityColor} isSelected={isSelected} />
      )}
    </group>
  );
}

/** Floating label above node */
function NodeLabel({ text, color, isSelected }: { text: string; color: string; isSelected: boolean }) {
  const labelRef = useRef<THREE.Mesh>(null);

  // Create text texture
  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const fontSize = isSelected ? 28 : 22;
    canvas.width = 1024;
    canvas.height = fontSize + 20;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = `500 ${fontSize}px Inter, sans-serif`;
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const displayText = text.length > 55 ? text.slice(0, 55) + '...' : text;
    ctx.fillText(displayText, canvas.width / 2, canvas.height / 2);
    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }, [text, color, isSelected]);

  return (
    <mesh ref={labelRef} position={[0, isSelected ? 3.5 : 2.5, 0]}>
      <planeGeometry args={[isSelected ? 14 : 12, 1.2]} />
      <meshBasicMaterial map={texture} transparent opacity={0.9} depthWrite={false} side={THREE.DoubleSide} />
    </mesh>
  );
}
