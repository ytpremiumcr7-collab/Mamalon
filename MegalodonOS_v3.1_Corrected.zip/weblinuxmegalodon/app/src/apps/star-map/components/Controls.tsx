import { useState, useRef, useEffect } from 'react';
import { Search, Download, RotateCcw } from 'lucide-react';
import type { PaperNode } from '../data/papers';

interface ControlsProps {
  papers: PaperNode[];
  onSelectPaper: (paper: PaperNode) => void;
  onResetView: () => void;
}

export default function Controls({ papers, onSelectPaper, onResetView }: ControlsProps) {
  const [query, setQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const results = query.length >= 2
    ? papers.filter(
        (p) =>
          p.title.toLowerCase().includes(query.toLowerCase()) ||
          p.authors.some((a) => a.toLowerCase().includes(query.toLowerCase())) ||
          p.keywords.some((k) => k.toLowerCase().includes(query.toLowerCase()))
      ).slice(0, 5)
    : [];

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const downloadCorpus = () => {
    const data = {
      papers: papers.map((p) => ({
        id: p.id,
        title: p.title,
        authors: p.authors,
        year: p.year,
        abstract: p.abstract,
        keywords: p.keywords,
        community: p.community,
        url: p.url,
        citationCount: p.citationCount,
      })),
      exportedAt: new Date().toISOString(),
      total: papers.length,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `star-map-corpus-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="absolute top-3 left-3 z-10 flex items-start gap-2" ref={containerRef}>
      {/* Search */}
      <div className="relative">
        <div className="flex items-center gap-2 bg-[rgba(18,18,26,0.85)] backdrop-blur-sm border border-[#2A2A3E] rounded-lg px-3 py-2 shadow-lg focus-within:border-[#C9A84C] transition-colors">
          <Search className="w-3.5 h-3.5 text-[#8A8578] shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setShowResults(true);
            }}
            onFocus={() => setShowResults(true)}
            placeholder="Buscar papers..."
            className="bg-transparent text-xs text-[#E8E4DC] placeholder:text-[#4D4A42] outline-none w-44"
          />
        </div>

        {/* Search results dropdown */}
        {showResults && results.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-[rgba(18,18,26,0.95)] backdrop-blur-sm border border-[#2A2A3E] rounded-lg shadow-xl overflow-hidden">
            {results.map((paper) => (
              <button
                key={paper.id}
                onClick={() => {
                  onSelectPaper(paper);
                  setQuery('');
                  setShowResults(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-[#222235] transition-colors border-b border-[#2A2A3E]/50 last:border-b-0"
              >
                <div className="text-[11px] text-[#E8E4DC] truncate leading-snug">{paper.title}</div>
                <div className="text-[10px] text-[#8A8578]">{paper.authors[0]} et al., {paper.year}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Download button */}
      <button
        onClick={downloadCorpus}
        className="flex items-center gap-1.5 px-3 py-2 bg-[rgba(18,18,26,0.85)] backdrop-blur-sm border border-[#2A2A3E] rounded-lg text-[#8A8578] hover:text-[#C9A84C] hover:border-[#C9A84C] transition-colors shadow-lg"
        title="Descargar corpus completo"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="text-[11px]">Corpus</span>
      </button>

      {/* Reset view */}
      <button
        onClick={onResetView}
        className="flex items-center gap-1.5 px-3 py-2 bg-[rgba(18,18,26,0.85)] backdrop-blur-sm border border-[#2A2A3E] rounded-lg text-[#8A8578] hover:text-[#C9A84C] hover:border-[#C9A84C] transition-colors shadow-lg"
        title="Resetear vista"
      >
        <RotateCcw className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
