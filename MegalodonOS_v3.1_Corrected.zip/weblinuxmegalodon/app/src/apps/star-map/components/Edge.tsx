import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useStarMapStore } from '../../../stores/useStarMapStore';
import { COMMUNITIES } from '../data/papers';
import type { CitationEdge, PaperNode } from '../data/papers';

interface EdgeProps {
  edge: CitationEdge;
  papers: PaperNode[];
}

export default function Edge({ edge, papers }: EdgeProps) {
  const lineRef = useRef<THREE.LineSegments>(null);
  const selectedNode = useStarMapStore((s) => s.selectedNode);
  const activeCommunity = useStarMapStore((s) => s.activeCommunity);

  const sourcePaper = papers.find((p) => p.id === edge.source);
  const targetPaper = papers.find((p) => p.id === edge.target);

  if (!sourcePaper || !targetPaper) return null;

  const isConnected = selectedNode === edge.source || selectedNode === edge.target;
  const isDimmed = activeCommunity !== null &&
    activeCommunity !== sourcePaper.community &&
    activeCommunity !== targetPaper.community;

  const positions = useMemo(() => {
    const arr = new Float32Array([
      ...sourcePaper.position,
      ...targetPaper.position,
    ]);
    return arr;
  }, [sourcePaper, targetPaper]);

  const opacity = isDimmed ? 0.02 : isConnected ? 0.6 : 0.08;
  const color = isConnected
    ? new THREE.Color(COMMUNITIES[sourcePaper.community]?.color || '#8B7340')
    : new THREE.Color('#8B7340');

  useFrame((_, delta) => {
    if (lineRef.current) {
      const mat = lineRef.current.material as THREE.LineBasicMaterial;
      mat.opacity = THREE.MathUtils.lerp(mat.opacity, opacity, delta * 4);
      if (isConnected) {
        mat.color.lerp(color, delta * 4);
      }
    }
  });

  return (
    <lineSegments ref={lineRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <lineBasicMaterial
        color={isConnected ? '#C9A84C' : '#8B7340'}
        transparent
        opacity={opacity}
        depthWrite={false}
      />
    </lineSegments>
  );
}
