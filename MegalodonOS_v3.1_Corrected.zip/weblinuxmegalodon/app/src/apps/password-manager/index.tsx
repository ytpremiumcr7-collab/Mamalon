import { useState, useEffect, useMemo } from 'react';
import {
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Copy,
  Plus,
  Trash2,
  Search,
  Shield,
  Globe,
  User,
  KeyRound,
  X,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface PasswordEntry {
  id: string;
  website: string;
  username: string;
  password: string;
  url: string;
  category: string;
  createdAt: number;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY = 'cornstone-password-vault';
const MASTER_PASSWORD = 'cornstone';

const CATEGORIES = [
  { name: 'Social', color: '#5A8AB8', icon: Globe },
  { name: 'Work', color: '#C9A84C', icon: KeyRound },
  { name: 'Finance', color: '#5A9E6F', icon: Shield },
  { name: 'Shopping', color: '#D4953A', icon: Globe },
  { name: 'Other', color: '#8A8578', icon: Lock },
];

const SAMPLE_ENTRIES: PasswordEntry[] = [
  { id: 'e1', website: 'GitHub', username: 'dev@cornstone.os', password: 'Gh$7kL9#mP2@vB1', url: 'https://github.com', category: 'Work', createdAt: Date.now() - 86400000 * 10 },
  { id: 'e2', website: 'Google', username: 'admin@cornstone.os', password: 'Go@9xQ3!wR5#zL7', url: 'https://google.com', category: 'Social', createdAt: Date.now() - 86400000 * 5 },
  { id: 'e3', website: 'Stripe', username: 'billing@cornstone.os', password: 'St#4pL8$kM2@vN9', url: 'https://stripe.com', category: 'Finance', createdAt: Date.now() - 86400000 * 2 },
  { id: 'e4', website: 'Amazon', username: 'shop@cornstone.os', password: 'Am@7bX1#qW3$eR5', url: 'https://amazon.com', category: 'Shopping', createdAt: Date.now() - 86400000 },
];

/* ------------------------------------------------------------------ */
/*  Simulated Encryption                                               */
/* ------------------------------------------------------------------ */
function encrypt(data: string, key: string): string {
  const salt = btoa(key).slice(0, 8);
  return btoa(salt + data + salt);
}

function decrypt(data: string, key: string): string {
  try {
    const salt = btoa(key).slice(0, 8);
    const decoded = atob(data);
    if (decoded.startsWith(salt) && decoded.endsWith(salt)) {
      return decoded.slice(salt.length, -salt.length);
    }
    return decoded;
  } catch {
    return data;
  }
}

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadVault(): PasswordEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  // Return encrypted sample data
  return SAMPLE_ENTRIES.map((e) => ({
    ...e,
    password: encrypt(e.password, MASTER_PASSWORD),
  }));
}

function saveVault(entries: PasswordEntry[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
}

function generateId() {
  return `pwd-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function generatePassword(length = 16): string {
  const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lower = 'abcdefghijklmnopqrstuvwxyz';
  const digits = '0123456789';
  const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
  const all = upper + lower + digits + symbols;
  let pwd = '';
  pwd += upper[Math.floor(Math.random() * upper.length)];
  pwd += lower[Math.floor(Math.random() * lower.length)];
  pwd += digits[Math.floor(Math.random() * digits.length)];
  pwd += symbols[Math.floor(Math.random() * symbols.length)];
  for (let i = 4; i < length; i++) {
    pwd += all[Math.floor(Math.random() * all.length)];
  }
  return pwd.split('').sort(() => Math.random() - 0.5).join('');
}

/* ------------------------------------------------------------------ */
/*  Entry Modal                                                        */
/* ------------------------------------------------------------------ */
function EntryModal({
  entry,
  onSave,
  onClose,
}: {
  entry?: PasswordEntry;
  onSave: (e: PasswordEntry) => void;
  onClose: () => void;
}) {
  const [website, setWebsite] = useState(entry?.website ?? '');
  const [username, setUsername] = useState(entry?.username ?? '');
  const [password, setPassword] = useState(entry ? decrypt(entry.password, MASTER_PASSWORD) : '');
  const [url, setUrl] = useState(entry?.url ?? '');
  const [category, setCategory] = useState(entry?.category ?? 'Other');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!website.trim() || !password.trim()) return;
    onSave({
      id: entry?.id ?? generateId(),
      website: website.trim(),
      username: username.trim(),
      password: encrypt(password, MASTER_PASSWORD),
      url: url.trim(),
      category,
      createdAt: entry?.createdAt ?? Date.now(),
    });
    onClose();
  };

  const handleGenerate = () => {
    setPassword(generatePassword(16));
    setShowPassword(true);
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-[#030305]/60 backdrop-blur-sm" />
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="relative z-10 w-[420px] bg-[#1A1A26] border border-[#2A2A3E] rounded-xl shadow-[0_12px_48px_rgba(0,0,0,0.5)] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-[#E8E4DC]">{entry ? 'Edit Entry' : 'New Entry'}</h3>
          <button onClick={onClose} className="p-1 hover:bg-[#222235] rounded-lg transition-colors">
            <X className="w-4 h-4 text-[#8A8578]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Website *</label>
            <input
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder="Website name"
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">URL</label>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://..."
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Username / Email</label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="user@example.com"
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Password *</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full h-9 px-3 pr-20 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors font-mono"
              />
              <div className="absolute right-1 top-1/2 -translate-y-1/2 flex">
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 hover:bg-[#222235] rounded transition-colors"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5 text-[#8A8578]" /> : <Eye className="w-3.5 h-3.5 text-[#8A8578]" />}
                </button>
                <button
                  type="button"
                  onClick={handleGenerate}
                  className="p-1 hover:bg-[#222235] rounded transition-colors"
                  title="Generate"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-[#C9A84C]" />
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-2">Category</label>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.name}
                  type="button"
                  onClick={() => setCategory(cat.name)}
                  className={`px-3 h-7 rounded-md text-xs font-medium transition-colors flex items-center gap-1 ${
                    category === cat.name ? 'text-[#030305]' : 'text-[#8A8578] hover:bg-[#222235] border border-[#2A2A3E]'
                  }`}
                  style={category === cat.name ? { backgroundColor: cat.color } : {}}
                >
                  <cat.icon className="w-3 h-3" />
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <div className="flex-1" />
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-9 bg-[#222235] text-[#E8E4DC] rounded-md text-sm font-medium hover:bg-[#2A2A3E] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 h-9 bg-[#C9A84C] text-[#030305] rounded-md text-sm font-semibold hover:bg-[#D4B85A] transition-colors"
            >
              Save
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Password Manager App                                          */
/* ------------------------------------------------------------------ */
export default function PasswordManagerApp() {
  const [unlocked, setUnlocked] = useState(false);
  const [masterInput, setMasterInput] = useState('');
  const [error, setError] = useState('');
  const [entries, setEntries] = useState<PasswordEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('');
  const [showModal, setShowModal] = useState(false);
  const [editingEntry, setEditingEntry] = useState<PasswordEntry | undefined>();
  const [visiblePasswords, setVisiblePasswords] = useState<Set<string>>(new Set());
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleUnlock = () => {
    if (masterInput === MASTER_PASSWORD) {
      setUnlocked(true);
      setError('');
      setEntries(loadVault());
    } else {
      setError('Incorrect master password');
    }
  };

  useEffect(() => {
    if (unlocked) saveVault(entries);
  }, [entries, unlocked]);

  const filteredEntries = useMemo(() => {
    return entries.filter((e) => {
      if (searchQuery && !e.website.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !e.username.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !e.url.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterCategory && e.category !== filterCategory) return false;
      return true;
    });
  }, [entries, searchQuery, filterCategory]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    entries.forEach((e) => { counts[e.category] = (counts[e.category] || 0) + 1; });
    return counts;
  }, [entries]);

  const handleSave = (entry: PasswordEntry) => {
    setEntries((prev) => {
      const idx = prev.findIndex((e) => e.id === entry.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = entry;
        return next;
      }
      return [...prev, entry];
    });
  };

  const handleDelete = (id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  };

  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    }).catch(() => {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    });
  };

  /* ---- Login Screen ---- */
  if (!unlocked) {
    return (
      <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex items-center justify-center">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="w-[360px] bg-[#1A1A26] border border-[#2A2A3E] rounded-xl shadow-[0_12px_48px_rgba(0,0,0,0.5)] p-6"
        >
          <div className="flex flex-col items-center mb-6">
            <div className="w-14 h-14 bg-[#C9A84C]/10 rounded-full flex items-center justify-center mb-3">
              <Lock className="w-7 h-7 text-[#C9A84C]" />
            </div>
            <h2 className="text-lg font-semibold text-[#E8E4DC]">Password Vault</h2>
            <p className="text-xs text-[#8A8578] mt-1">Enter your master password</p>
          </div>

          <div className="space-y-3">
            <div className="relative">
              <Lock className="w-4 h-4 text-[#4D4A42] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                value={masterInput}
                onChange={(e) => { setMasterInput(e.target.value); setError(''); }}
                placeholder="Master password"
                onKeyDown={(e) => { if (e.key === 'Enter') handleUnlock(); }}
                autoFocus
                className="w-full h-10 pl-10 pr-4 bg-[#12121A] border border-[#2A2A3E] rounded-lg text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
              />
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs text-[#B84A4A] bg-[#B84A4A]/10 rounded-md px-3 py-2 flex items-center gap-1.5"
              >
                <Shield className="w-3 h-3" />
                {error}
              </motion.div>
            )}

            <button
              onClick={handleUnlock}
              className="w-full h-10 bg-[#C9A84C] text-[#030305] rounded-lg text-sm font-semibold hover:bg-[#D4B85A] transition-colors flex items-center justify-center gap-2"
            >
              <Unlock className="w-4 h-4" />
              Unlock Vault
            </button>

            <div className="text-[10px] text-[#4D4A42] text-center pt-2">
              Hint: master password is &ldquo;cornstone&rdquo;
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  /* ---- Vault View ---- */
  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#2A2A3E] bg-[#0A0A0F]">
        <div className="flex items-center gap-3">
          <Shield className="w-5 h-5 text-[#C9A84C]" />
          <div>
            <h2 className="text-sm font-semibold text-[#E8E4DC]">Password Vault</h2>
            <div className="text-[10px] text-[#8A8578]">{entries.length} entries</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3 h-3 text-[#4D4A42] absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search..."
              className="h-8 w-[140px] pl-7 pr-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>
          <button
            onClick={() => { setEditingEntry(undefined); setShowModal(true); }}
            className="h-8 px-3 bg-[#C9A84C] text-[#030305] rounded-md text-xs font-semibold hover:bg-[#D4B85A] transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Add
          </button>
          <button
            onClick={() => { setUnlocked(false); setMasterInput(''); }}
            className="h-8 px-3 bg-[#222235] text-[#8A8578] rounded-md text-xs hover:bg-[#2A2A3E] transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            Lock
          </button>
        </div>
      </div>

      {/* Category filters */}
      <div className="flex items-center gap-1.5 px-4 py-2 border-b border-[#2A2A3E] bg-[#12121A]">
        <button
          onClick={() => setFilterCategory('')}
          className={`px-2.5 h-6 rounded-md text-[10px] font-medium transition-colors ${
            !filterCategory ? 'bg-[#C9A84C] text-[#030305]' : 'text-[#8A8578] hover:bg-[#222235]'
          }`}
        >
          All ({entries.length})
        </button>
        {CATEGORIES.map((cat) => (
          <button
            key={cat.name}
            onClick={() => setFilterCategory(filterCategory === cat.name ? '' : cat.name)}
            className={`px-2.5 h-6 rounded-md text-[10px] font-medium transition-colors flex items-center gap-1 ${
              filterCategory === cat.name ? 'text-[#030305]' : 'text-[#8A8578] hover:bg-[#222235]'
            }`}
            style={filterCategory === cat.name ? { backgroundColor: cat.color } : {}}
          >
            {cat.name} ({categoryCounts[cat.name] || 0})
          </button>
        ))}
      </div>

      {/* Entries list */}
      <div className="flex-1 overflow-auto p-3 space-y-1.5">
        {filteredEntries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-[#4D4A42]">
            <Lock className="w-8 h-8 mb-2 opacity-30" />
            <div className="text-xs">{searchQuery || filterCategory ? 'No matching entries' : 'No entries yet'}</div>
          </div>
        ) : (
          filteredEntries.map((entry) => {
            const cat = CATEGORIES.find((c) => c.name === entry.category) || CATEGORIES[4];
            const showPwd = visiblePasswords.has(entry.id);
            const decryptedPwd = decrypt(entry.password, MASTER_PASSWORD);

            return (
              <motion.div
                key={entry.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3 hover:border-[#3D3D5C] transition-colors group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: cat.color + '20' }}
                    >
                      <Globe className="w-4 h-4" style={{ color: cat.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-[#E8E4DC] truncate">{entry.website}</span>
                        <span
                          className="text-[9px] px-1.5 py-0.5 rounded-full flex-shrink-0"
                          style={{ backgroundColor: cat.color + '20', color: cat.color }}
                        >
                          {entry.category}
                        </span>
                      </div>
                      {entry.url && (
                        <a href={entry.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-[#5A8AB8] hover:underline truncate block">
                          {entry.url}
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2">
                    <button
                      onClick={() => { setEditingEntry(entry); setShowModal(true); }}
                      className="p-1.5 hover:bg-[#222235] rounded transition-colors"
                      title="Edit"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-[#8A8578]" />
                    </button>
                    <button
                      onClick={() => handleDelete(entry.id)}
                      className="p-1.5 hover:bg-[#B84A4A]/20 rounded transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-[#B84A4A]" />
                    </button>
                  </div>
                </div>

                {/* Credentials row */}
                <div className="flex items-center gap-4 mt-2 ml-11">
                  {/* Username */}
                  <div className="flex items-center gap-1.5 flex-1 min-w-0">
                    <User className="w-3 h-3 text-[#4D4A42] flex-shrink-0" />
                    <span className="text-xs text-[#8A8578] truncate font-mono">{entry.username}</span>
                    <button
                      onClick={() => copyToClipboard(entry.username, `user-${entry.id}`)}
                      className="p-0.5 hover:bg-[#222235] rounded transition-colors flex-shrink-0"
                    >
                      {copiedField === `user-${entry.id}` ? (
                        <span className="text-[9px] text-[#5A9E6F]">Copied</span>
                      ) : (
                        <Copy className="w-3 h-3 text-[#4D4A42]" />
                      )}
                    </button>
                  </div>

                  {/* Password */}
                  <div className="flex items-center gap-1.5 flex-1 min-w-0">
                    <KeyRound className="w-3 h-3 text-[#4D4A42] flex-shrink-0" />
                    <span className="text-xs text-[#8A8578] truncate font-mono">
                      {showPwd ? decryptedPwd : '•'.repeat(Math.min(decryptedPwd.length, 16))}
                    </span>
                    <button
                      onClick={() => togglePasswordVisibility(entry.id)}
                      className="p-0.5 hover:bg-[#222235] rounded transition-colors flex-shrink-0"
                    >
                      {showPwd ? <EyeOff className="w-3 h-3 text-[#8A8578]" /> : <Eye className="w-3 h-3 text-[#8A8578]" />}
                    </button>
                    <button
                      onClick={() => copyToClipboard(decryptedPwd, `pwd-${entry.id}`)}
                      className="p-0.5 hover:bg-[#222235] rounded transition-colors flex-shrink-0"
                    >
                      {copiedField === `pwd-${entry.id}` ? (
                        <span className="text-[9px] text-[#5A9E6F]">Copied</span>
                      ) : (
                        <Copy className="w-3 h-3 text-[#4D4A42]" />
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <EntryModal
            entry={editingEntry}
            onSave={handleSave}
            onClose={() => { setShowModal(false); setEditingEntry(undefined); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
