import { useState, useEffect, useCallback } from 'react';
import {
  Plus,
  Copy,
  Trash2,
  Monitor,
  Type,
  Square,
  Circle,
  Image,
  List,
  ChevronLeft,
  ChevronRight,
  X,
  Download,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
type SlideElementType = 'text' | 'shape-rect' | 'shape-circle' | 'image' | 'bullets';

interface SlideElement {
  id: string;
  type: SlideElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  content: string;
  fontSize?: number;
  color?: string;
  bgColor?: string;
}

interface Slide {
  id: string;
  elements: SlideElement[];
  transition: 'fade' | 'slide' | 'zoom';
  bgColor: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY = 'cornstone-presentation';
const SLIDE_WIDTH = 960;
const SLIDE_HEIGHT = 540;

const DEFAULT_SLIDES: Slide[] = [
  {
    id: 'slide-1',
    bgColor: '#FFFFFF',
    transition: 'fade',
    elements: [
      { id: 'el-1', type: 'text', x: 80, y: 160, width: 800, height: 60, content: 'Project Proposal', fontSize: 48, color: '#1A1A26' },
      { id: 'el-2', type: 'text', x: 80, y: 240, width: 800, height: 40, content: 'Cornstone OS Productivity Suite', fontSize: 24, color: '#8A8578' },
    ],
  },
  {
    id: 'slide-2',
    bgColor: '#FFFFFF',
    transition: 'slide',
    elements: [
      { id: 'el-3', type: 'text', x: 60, y: 40, width: 400, height: 50, content: 'Key Features', fontSize: 36, color: '#1A1A26' },
      { id: 'el-4', type: 'bullets', x: 60, y: 110, width: 840, height: 360, content: 'Full-featured Calendar with Mexican holidays\nSpreadsheet with formula engine (SUM, AVG, IF, etc.)\nPresentation tool with slide transitions\nKanban task manager with drag-and-drop\nSecure password vault with encryption\nInteractive whiteboard with drawing tools\nWorld clock with multiple time zones', fontSize: 20, color: '#333333' },
    ],
  },
  {
    id: 'slide-3',
    bgColor: '#FFFFFF',
    transition: 'zoom',
    elements: [
      { id: 'el-5', type: 'text', x: 60, y: 40, width: 400, height: 50, content: 'Thank You', fontSize: 36, color: '#1A1A26' },
      { id: 'el-6', type: 'text', x: 60, y: 200, width: 840, height: 60, content: 'Questions & Discussion', fontSize: 32, color: '#C9A84C' },
      { id: 'el-7', type: 'shape-rect', x: 380, y: 320, width: 200, height: 60, content: '', bgColor: '#C9A84C' },
      { id: 'el-8', type: 'text', x: 380, y: 320, width: 200, height: 60, content: 'Get Started', fontSize: 20, color: '#FFFFFF' },
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadSlides(): Slide[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch { /* ignore */ }
  return JSON.parse(JSON.stringify(DEFAULT_SLIDES));
}

function saveSlides(slides: Slide[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(slides));
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
let idCounter = 0;
function newId(prefix: string) {
  return `${prefix}-${Date.now()}-${++idCounter}`;
}

/* ------------------------------------------------------------------ */
/*  Slide Canvas (renders a slide)                                     */
/* ------------------------------------------------------------------ */
function SlideCanvas({
  slide,
  isEdit,
  selectedElementId,
  onSelectElement,
  onUpdateElement,
  scale = 1,
}: {
  slide: Slide;
  isEdit: boolean;
  selectedElementId: string | null;
  onSelectElement: (id: string | null) => void;
  onUpdateElement: (id: string, updates: Partial<SlideElement>) => void;
  scale?: number;
}) {
  const [editingText, setEditingText] = useState<string | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent, el: SlideElement) => {
    if (!isEdit) return;
    e.stopPropagation();
    onSelectElement(el.id);
    setDragging(el.id);
    const rect = (e.currentTarget as HTMLElement).closest('.slide-container')?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: (e.clientX - rect.left) / scale - el.x,
        y: (e.clientY - rect.top) / scale - el.y,
      });
    }
  };

  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!dragging) return;
      const container = document.querySelector('.slide-container');
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const x = (e.clientX - rect.left) / scale - dragOffset.x;
      const y = (e.clientY - rect.top) / scale - dragOffset.y;
      onUpdateElement(dragging, {
        x: Math.max(0, Math.min(x, SLIDE_WIDTH - 20)),
        y: Math.max(0, Math.min(y, SLIDE_HEIGHT - 20)),
      });
    },
    [dragging, dragOffset, scale, onUpdateElement]
  );

  const handleMouseUp = useCallback(() => {
    setDragging(null);
  }, []);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [dragging, handleMouseMove, handleMouseUp]);

  return (
    <div
      className="slide-container relative"
      style={{
        width: SLIDE_WIDTH * scale,
        height: SLIDE_HEIGHT * scale,
        backgroundColor: slide.bgColor,
      }}
      onClick={() => isEdit && onSelectElement(null)}
    >
      {slide.elements.map((el) => (
        <div
          key={el.id}
          className={`absolute ${isEdit && selectedElementId === el.id ? 'ring-2 ring-[#C9A84C]' : ''} ${
            isEdit ? 'cursor-move' : ''
          }`}
          style={{
            left: el.x * scale,
            top: el.y * scale,
            width: el.width * scale,
            height: el.height * scale,
            backgroundColor: el.bgColor || 'transparent',
            borderRadius: el.type === 'shape-circle' ? '50%' : el.type.startsWith('shape') ? 4 : 0,
          }}
          onMouseDown={(e) => handleMouseDown(e, el)}
          onClick={(e) => { e.stopPropagation(); if (isEdit) onSelectElement(el.id); }}
          onDoubleClick={(e) => {
            e.stopPropagation();
            if (isEdit && (el.type === 'text' || el.type === 'bullets')) {
              setEditingText(el.id);
            }
          }}
        >
          {el.type === 'text' || el.type === 'bullets' ? (
            editingText === el.id && isEdit ? (
              <textarea
                autoFocus
                value={el.content}
                onChange={(e) => onUpdateElement(el.id, { content: e.target.value })}
                onBlur={() => setEditingText(null)}
                onKeyDown={(e) => { if (e.key === 'Escape') setEditingText(null); }}
                className="w-full h-full bg-white/90 text-[#1A1A26] outline-none p-1 resize-none border border-[#C9A84C]"
                style={{ fontSize: (el.fontSize || 16) * scale }}
              />
            ) : (
              <div
                className={`w-full h-full select-none ${
                  el.type === 'bullets'
                    ? 'list-disc pl-4 whitespace-pre-wrap overflow-hidden'
                    : 'flex items-center whitespace-pre-wrap overflow-hidden'
                }`}
                style={{
                  fontSize: (el.fontSize || 16) * scale,
                  color: el.color || '#1A1A26',
                }}
              >
                {el.type === 'bullets'
                  ? el.content.split('\n').map((line, i) => (
                      <div key={i} className="flex items-start gap-2 leading-relaxed">
                        <span className="flex-shrink-0 mt-1 w-1.5 h-1.5 rounded-full bg-current" />
                        <span>{line.replace(/^•\s*/, '')}</span>
                      </div>
                    ))
                  : el.content}
              </div>
            )
          ) : el.type === 'image' ? (
            <div className="w-full h-full bg-[#2A2A3E] flex items-center justify-center text-[#8A8578]" style={{ fontSize: 12 * scale }}>
              <Image className="inline mr-1" style={{ width: 16 * scale, height: 16 * scale } as React.CSSProperties} />
              Image
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Present Mode                                                       */
/* ------------------------------------------------------------------ */
function PresentMode({
  slides,
  currentIndex,
  onClose,
  onNavigate,
}: {
  slides: Slide[];
  currentIndex: number;
  onClose: () => void;
  onNavigate: (i: number) => void;
}) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        if (currentIndex < slides.length - 1) onNavigate(currentIndex + 1);
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (currentIndex > 0) onNavigate(currentIndex - 1);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [currentIndex, slides.length, onClose, onNavigate]);

  const slide = slides[currentIndex];

  const transitionProps =
    slide.transition === 'fade'
      ? { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }
      : slide.transition === 'slide'
      ? { initial: { x: 100, opacity: 0 }, animate: { x: 0, opacity: 1 }, exit: { x: -100, opacity: 0 } }
      : { initial: { scale: 0.5, opacity: 0 }, animate: { scale: 1, opacity: 1 }, exit: { scale: 0.5, opacity: 0 } };

  return (
    <div className="fixed inset-0 z-[99999] bg-[#030305] flex items-center justify-center" onClick={() => currentIndex < slides.length - 1 && onNavigate(currentIndex + 1)}>
      {/* Controls */}
      <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
        <span className="text-xs text-[#8A8578]">{currentIndex + 1} / {slides.length}</span>
        <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="p-2 hover:bg-[#222235] rounded-lg transition-colors">
          <X className="w-5 h-5 text-[#8A8578]" />
        </button>
      </div>

      {/* Navigation buttons */}
      <button
        onClick={(e) => { e.stopPropagation(); if (currentIndex > 0) onNavigate(currentIndex - 1); }}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-3 hover:bg-[#222235]/50 rounded-full transition-colors z-10"
      >
        <ChevronLeft className="w-6 h-6 text-[#8A8578]" />
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); if (currentIndex < slides.length - 1) onNavigate(currentIndex + 1); }}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-3 hover:bg-[#222235]/50 rounded-full transition-colors z-10"
      >
        <ChevronRight className="w-6 h-6 text-[#8A8578]" />
      </button>

      {/* Slide */}
      <AnimatePresence mode="wait">
        <motion.div
          key={slide.id}
          {...transitionProps}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="flex items-center justify-center"
          style={{ maxWidth: '90vw', maxHeight: '85vh' }}
        >
          <div
            style={{
              width: Math.min(window.innerWidth * 0.85, SLIDE_WIDTH),
              height: Math.min(window.innerHeight * 0.8, SLIDE_HEIGHT),
              transform: `scale(${Math.min(window.innerWidth * 0.85 / SLIDE_WIDTH, window.innerHeight * 0.8 / SLIDE_HEIGHT)})`,
              transformOrigin: 'center center',
            }}
          >
            <SlideCanvas
              slide={slide}
              isEdit={false}
              selectedElementId={null}
              onSelectElement={() => {}}
              onUpdateElement={() => {}}
              scale={Math.min(window.innerWidth * 0.85 / SLIDE_WIDTH, window.innerHeight * 0.8 / SLIDE_HEIGHT)}
            />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Progress */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={(e) => { e.stopPropagation(); onNavigate(i); }}
            className={`h-1 rounded-full transition-all ${
              i === currentIndex ? 'w-6 bg-[#C9A84C]' : 'w-2 bg-[#2A2A3E] hover:bg-[#3D3D5C]'
            }`}
          />
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Presentation App                                              */
/* ------------------------------------------------------------------ */
export default function PresentationApp() {
  const [slides, setSlides] = useState<Slide[]>(loadSlides);
  const [currentSlideIdx, setCurrentSlideIdx] = useState(0);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [presentMode, setPresentMode] = useState(false);
  const [dragSlideIdx, setDragSlideIdx] = useState<number | null>(null);

  useEffect(() => { saveSlides(slides); }, [slides]);

  const currentSlide = slides[currentSlideIdx];

  const addSlide = () => {
    if (slides.length >= 20) return;
    const newSlide: Slide = {
      id: newId('slide'),
      bgColor: '#FFFFFF',
      transition: 'fade',
      elements: [
        { id: newId('el'), type: 'text', x: 80, y: 200, width: 800, height: 60, content: 'New Slide', fontSize: 36, color: '#1A1A26' },
      ],
    };
    setSlides((s) => [...s, newSlide]);
    setCurrentSlideIdx(slides.length);
  };

  const duplicateSlide = () => {
    if (slides.length >= 20) return;
    const dup: Slide = {
      ...currentSlide,
      id: newId('slide'),
      elements: currentSlide.elements.map((e) => ({ ...e, id: newId('el') })),
    };
    const next = [...slides];
    next.splice(currentSlideIdx + 1, 0, dup);
    setSlides(next);
    setCurrentSlideIdx(currentSlideIdx + 1);
  };

  const deleteSlide = () => {
    if (slides.length <= 1) return;
    const next = slides.filter((_, i) => i !== currentSlideIdx);
    setSlides(next);
    setCurrentSlideIdx(Math.min(currentSlideIdx, next.length - 1));
  };

  const updateSlide = (idx: number, updates: Partial<Slide>) => {
    setSlides((s) => s.map((slide, i) => (i === idx ? { ...slide, ...updates } : slide)));
  };

  const updateElement = (slideIdx: number, elId: string, updates: Partial<SlideElement>) => {
    setSlides((s) =>
      s.map((slide, i) =>
        i === slideIdx
          ? { ...slide, elements: slide.elements.map((el) => (el.id === elId ? { ...el, ...updates } : el)) }
          : slide
      )
    );
  };

  const addElement = (type: SlideElementType) => {
    const el: SlideElement = {
      id: newId('el'),
      type,
      x: 100,
      y: 150,
      width: type === 'text' ? 400 : type === 'bullets' ? 600 : type === 'image' ? 300 : 200,
      height: type === 'text' ? 60 : type === 'bullets' ? 300 : type === 'image' ? 200 : 100,
      content: type === 'text' ? 'New Text' : type === 'bullets' ? 'Item 1\nItem 2\nItem 3' : '',
      fontSize: type === 'text' ? 28 : type === 'bullets' ? 18 : 16,
      color: '#1A1A26',
      bgColor: type.startsWith('shape') ? '#C9A84C' : undefined,
    };
    updateSlide(currentSlideIdx, { elements: [...currentSlide.elements, el] });
    setSelectedElementId(el.id);
  };

  const deleteElement = (elId: string) => {
    updateSlide(currentSlideIdx, {
      elements: currentSlide.elements.filter((e) => e.id !== elId),
    });
    setSelectedElementId(null);
  };

  const handleSlideDragStart = (idx: number) => setDragSlideIdx(idx);
  const handleSlideDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    if (dragSlideIdx === null || dragSlideIdx === idx) return;
    const next = [...slides];
    const [moved] = next.splice(dragSlideIdx, 1);
    next.splice(idx, 0, moved);
    setSlides(next);
    setCurrentSlideIdx(idx);
    setDragSlideIdx(idx);
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(slides, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'presentation.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const selectedElement = currentSlide.elements.find((e) => e.id === selectedElementId);

  // Scale for the editor canvas
  const canvasScale = 0.55;

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex">
      {/* Thumbnails panel */}
      <div className="w-[180px] border-r border-[#2A2A3E] flex flex-col bg-[#0A0A0F]">
        <div className="flex items-center justify-between px-2 py-2 border-b border-[#2A2A3E]">
          <span className="text-xs text-[#8A8578]">Slides ({slides.length})</span>
          <div className="flex gap-0.5">
            <button onClick={addSlide} className="p-1 hover:bg-[#222235] rounded transition-colors" title="New Slide">
              <Plus className="w-3.5 h-3.5 text-[#8A8578]" />
            </button>
            <button onClick={duplicateSlide} className="p-1 hover:bg-[#222235] rounded transition-colors" title="Duplicate">
              <Copy className="w-3.5 h-3.5 text-[#8A8578]" />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-auto p-2 space-y-2">
          {slides.map((slide, idx) => (
            <div
              key={slide.id}
              draggable
              onDragStart={() => handleSlideDragStart(idx)}
              onDragOver={(e) => handleSlideDragOver(e, idx)}
              onDragEnd={() => setDragSlideIdx(null)}
              onClick={() => setCurrentSlideIdx(idx)}
              className={`relative cursor-pointer rounded border-2 transition-all group ${
                idx === currentSlideIdx ? 'border-[#C9A84C]' : 'border-transparent hover:border-[#3D3D5C]'
              }`}
            >
              <div className="w-full aspect-video rounded overflow-hidden" style={{ backgroundColor: slide.bgColor }}>
                {/* Mini preview */}
                <div className="w-full h-full relative" style={{ transform: 'scale(0.156)', transformOrigin: 'top left', width: SLIDE_WIDTH, height: SLIDE_HEIGHT }}>
                  {slide.elements.map((el) => (
                    <div
                      key={el.id}
                      className="absolute"
                      style={{
                        left: el.x,
                        top: el.y,
                        width: el.width,
                        height: el.height,
                        backgroundColor: el.bgColor || 'transparent',
                        borderRadius: el.type === 'shape-circle' ? '50%' : 0,
                      }}
                    >
                      {el.type === 'text' || el.type === 'bullets' ? (
                        <div style={{ fontSize: el.fontSize || 16, color: el.color || '#1A1A26' }} className="truncate">
                          {el.content.slice(0, 30)}
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-[#0A0A0F]/80 text-[10px] text-[#8A8578] px-1.5 py-0.5 flex items-center justify-between">
                <span>{idx + 1}</span>
                {slides.length > 1 && (
                  <button
                    onClick={(e) => { e.stopPropagation(); if (idx === currentSlideIdx) deleteSlide(); else { const next = slides.filter((_, i) => i !== idx); setSlides(next); setCurrentSlideIdx(Math.min(currentSlideIdx, next.length - 1)); }}}
                    className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-[#B84A4A]/20 rounded transition-all"
                  >
                    <Trash2 className="w-2.5 h-2.5 text-[#B84A4A]" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main editing area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E] bg-[#1A1A26]">
          <div className="flex items-center gap-1">
            <button onClick={() => addElement('text')} className="flex items-center gap-1 px-2 h-7 hover:bg-[#222235] rounded text-xs text-[#8A8578] transition-colors">
              <Type className="w-3.5 h-3.5" /> Text
            </button>
            <button onClick={() => addElement('shape-rect')} className="flex items-center gap-1 px-2 h-7 hover:bg-[#222235] rounded text-xs text-[#8A8578] transition-colors">
              <Square className="w-3.5 h-3.5" /> Rect
            </button>
            <button onClick={() => addElement('shape-circle')} className="flex items-center gap-1 px-2 h-7 hover:bg-[#222235] rounded text-xs text-[#8A8578] transition-colors">
              <Circle className="w-3.5 h-3.5" /> Circle
            </button>
            <button onClick={() => addElement('image')} className="flex items-center gap-1 px-2 h-7 hover:bg-[#222235] rounded text-xs text-[#8A8578] transition-colors">
              <Image className="w-3.5 h-3.5" /> Image
            </button>
            <button onClick={() => addElement('bullets')} className="flex items-center gap-1 px-2 h-7 hover:bg-[#222235] rounded text-xs text-[#8A8578] transition-colors">
              <List className="w-3.5 h-3.5" /> Bullets
            </button>
            {selectedElementId && (
              <>
                <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
                <button onClick={() => deleteElement(selectedElementId)} className="p-1 hover:bg-[#B84A4A]/20 rounded transition-colors text-[#B84A4A]">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
          <div className="flex items-center gap-2">
            <select
              value={currentSlide.transition}
              onChange={(e) => updateSlide(currentSlideIdx, { transition: e.target.value as Slide['transition'] })}
              className="h-7 px-2 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
            >
              <option value="fade">Fade</option>
              <option value="slide">Slide</option>
              <option value="zoom">Zoom</option>
            </select>
            <button onClick={exportJSON} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Export JSON">
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPresentMode(true)}
              className="flex items-center gap-1.5 px-3 h-7 bg-[#C9A84C] text-[#030305] rounded text-xs font-semibold hover:bg-[#D4B85A] transition-colors"
            >
              <Monitor className="w-3.5 h-3.5" />
              Present
            </button>
          </div>
        </div>

        {/* Canvas area */}
        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 bg-[#0A0A0F] flex items-center justify-center overflow-auto p-4">
            <div className="shadow-[0_8px_32px_rgba(0,0,0,0.4)]">
              <SlideCanvas
                slide={currentSlide}
                isEdit
                selectedElementId={selectedElementId}
                onSelectElement={setSelectedElementId}
                onUpdateElement={(id, updates) => updateElement(currentSlideIdx, id, updates)}
                scale={canvasScale}
              />
            </div>
          </div>

          {/* Properties panel */}
          {selectedElement && (
            <div className="w-[200px] border-l border-[#2A2A3E] bg-[#1A1A26] p-3 overflow-auto">
              <div className="text-xs font-medium text-[#8A8578] mb-3">Properties</div>
              <div className="space-y-3">
                <div>
                  <label className="text-[10px] text-[#4D4A42] block mb-1">Content</label>
                  <textarea
                    value={selectedElement.content}
                    onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { content: e.target.value })}
                    rows={3}
                    className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C] resize-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#4D4A42] block mb-1">X</label>
                    <input
                      type="number"
                      value={selectedElement.x}
                      onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { x: parseInt(e.target.value) || 0 })}
                      className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#4D4A42] block mb-1">Y</label>
                    <input
                      type="number"
                      value={selectedElement.y}
                      onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { y: parseInt(e.target.value) || 0 })}
                      className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#4D4A42] block mb-1">W</label>
                    <input
                      type="number"
                      value={selectedElement.width}
                      onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { width: parseInt(e.target.value) || 100 })}
                      className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#4D4A42] block mb-1">H</label>
                    <input
                      type="number"
                      value={selectedElement.height}
                      onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { height: parseInt(e.target.value) || 100 })}
                      className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-[#4D4A42] block mb-1">Font Size</label>
                  <input
                    type="number"
                    value={selectedElement.fontSize || 16}
                    onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { fontSize: parseInt(e.target.value) || 16 })}
                    className="w-full px-2 py-1 bg-[#12121A] border border-[#2A2A3E] rounded text-xs text-[#E8E4DC] outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#4D4A42] block mb-1">Text Color</label>
                  <input
                    type="color"
                    value={selectedElement.color || '#1A1A26'}
                    onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { color: e.target.value })}
                    className="w-full h-7 bg-[#12121A] border border-[#2A2A3E] rounded cursor-pointer"
                  />
                </div>
                {selectedElement.bgColor !== undefined && (
                  <div>
                    <label className="text-[10px] text-[#4D4A42] block mb-1">Background</label>
                    <input
                      type="color"
                      value={selectedElement.bgColor}
                      onChange={(e) => updateElement(currentSlideIdx, selectedElementId!, { bgColor: e.target.value })}
                      className="w-full h-7 bg-[#12121A] border border-[#2A2A3E] rounded cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Present Mode */}
      <AnimatePresence>
        {presentMode && (
          <PresentMode
            slides={slides}
            currentIndex={currentSlideIdx}
            onClose={() => setPresentMode(false)}
            onNavigate={setCurrentSlideIdx}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
