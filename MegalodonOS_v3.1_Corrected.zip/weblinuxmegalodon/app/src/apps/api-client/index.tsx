import { useState, useCallback } from 'react';
import {
  Send, Clock, Plus, X, Globe, ChevronDown,
  Copy, Check, History, Star
} from 'lucide-react';

/* ── types ── */
type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' | 'HEAD' | 'OPTIONS';

interface HeaderPair {
  id: string;
  key: string;
  value: string;
  enabled: boolean;
}

interface RequestHistory {
  id: string;
  method: HttpMethod;
  url: string;
  timestamp: number;
  status?: number;
  starred?: boolean;
}

interface ApiResponse {
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  time: number;
  size: number;
}

const METHOD_COLORS: Record<HttpMethod, string> = {
  GET: '#5A9E6F',
  POST: '#C9A84C',
  PUT: '#5A8AB8',
  DELETE: '#B84A4A',
  PATCH: '#D4953A',
  HEAD: '#8A8578',
  OPTIONS: '#7B6FB8',
};

const SAMPLE_REQUESTS: RequestHistory[] = [
  { id: '1', method: 'GET', url: 'https://jsonplaceholder.typicode.com/users', timestamp: Date.now() - 3600000, starred: true },
  { id: '2', method: 'GET', url: 'https://jsonplaceholder.typicode.com/posts/1', timestamp: Date.now() - 7200000, starred: true },
  { id: '3', method: 'POST', url: 'https://jsonplaceholder.typicode.com/posts', timestamp: Date.now() - 86400000 },
  { id: '4', method: 'GET', url: 'https://jsonplaceholder.typicode.com/posts/1/comments', timestamp: Date.now() - 90000000 },
  { id: '5', method: 'GET', url: 'https://api.github.com/users/github', timestamp: Date.now() - 172800000 },
];

export default function ApiClient() {
  const [method, setMethod] = useState<HttpMethod>('GET');
  const [url, setUrl] = useState('https://jsonplaceholder.typicode.com/users');
  const [headers, setHeaders] = useState<HeaderPair[]>([
    { id: '1', key: 'Content-Type', value: 'application/json', enabled: true },
    { id: '2', key: 'Accept', value: 'application/json', enabled: true },
  ]);
  const [body, setBody] = useState('{\n  "title": "Cornstone Post",\n  "body": "A test post from the API client",\n  "userId": 1\n}');
  const [copied, setCopied] = useState(false);
  const copyText = useCallback(async (text: string) => {
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* noop */ }
  }, []);

  const [response, setResponse] = useState<ApiResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [history, setHistory] = useState<RequestHistory[]>(SAMPLE_REQUESTS);
  const [showHistory, setShowHistory] = useState(false);
  const [resTab, setResTab] = useState<'body' | 'headers'>('body');
  const [bodyFormat, setBodyFormat] = useState<'formatted' | 'raw'>('formatted');

  const [activeReqTab, setActiveReqTab] = useState<'headers' | 'body'>('headers');

  const addHeader = useCallback(() => {
    setHeaders(prev => [...prev, { id: Date.now().toString(), key: '', value: '', enabled: true }]);
  }, []);

  const updateHeader = useCallback((id: string, field: 'key' | 'value', value: string) => {
    setHeaders(prev => prev.map(h => h.id === id ? { ...h, [field]: value } : h));
  }, []);

  const removeHeader = useCallback((id: string) => {
    setHeaders(prev => prev.filter(h => h.id !== id));
  }, []);

  const toggleHeader = useCallback((id: string) => {
    setHeaders(prev => prev.map(h => h.id === id ? { ...h, enabled: !h.enabled } : h));
  }, []);

  const sendRequest = useCallback(async () => {
    if (!url.trim()) return;
    setLoading(true);
    setError('');
    setResponse(null);

    const startTime = performance.now();

    try {
      const reqHeaders: Record<string, string> = {};
      headers.filter(h => h.enabled && h.key).forEach(h => { reqHeaders[h.key] = h.value; });

      const options: RequestInit = {
        method,
        headers: reqHeaders,
      };

      if (['POST', 'PUT', 'PATCH'].includes(method) && body.trim()) {
        options.body = body;
      }

      const res = await fetch(url, options);
      const resBody = await res.text();
      const endTime = performance.now();

      const resHeaders: Record<string, string> = {};
      res.headers.forEach((v, k) => { resHeaders[k] = v; });

      const responseData: ApiResponse = {
        status: res.status,
        statusText: res.statusText,
        headers: resHeaders,
        body: resBody,
        time: Math.round(endTime - startTime),
        size: new Blob([resBody]).size,
      };

      setResponse(responseData);

      const newEntry: RequestHistory = {
        id: Date.now().toString(),
        method,
        url,
        timestamp: Date.now(),
        status: res.status,
      };
      setHistory(prev => [newEntry, ...prev].slice(0, 50));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Request failed');
    } finally {
      setLoading(false);
    }
  }, [method, url, headers, body]);

  const loadRequest = useCallback((req: RequestHistory) => {
    setMethod(req.method);
    setUrl(req.url);
    setResponse(null);
    setError('');
  }, []);

  const toggleStar = useCallback((id: string) => {
    setHistory(prev => prev.map(h => h.id === id ? { ...h, starred: !h.starred } : h));
  }, []);

  const formatBody = (bodyText: string): string => {
    try {
      const parsed = JSON.parse(bodyText);
      return JSON.stringify(parsed, null, 2);
    } catch {
      return bodyText;
    }
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return '#5A9E6F';
    if (status >= 300 && status < 400) return '#D4953A';
    if (status >= 400) return '#B84A4A';
    return '#8A8578';
  };

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex overflow-hidden text-xs">
      {/* History sidebar */}
      {showHistory && (
        <div className="w-56 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col shrink-0 overflow-hidden">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-[#2A2A3E] shrink-0">
            <History className="w-3.5 h-3.5 text-[#8A8578]" />
            <span className="font-medium">History</span>
          </div>
          <div className="flex-1 overflow-y-auto">
            {history.map(req => (
              <div
                key={req.id}
                className="flex items-center gap-2 px-3 py-2 hover:bg-[#1A1A26] cursor-pointer transition-colors border-b border-[#2A2A3E]/50 group"
              >
                <button
                  className="shrink-0"
                  onClick={e => { e.stopPropagation(); toggleStar(req.id); }}
                >
                  <Star className={`w-3 h-3 ${req.starred ? 'text-[#C9A84C] fill-[#C9A84C]' : 'text-[#4D4A42]'}`} />
                </button>
                <div className="flex-1 min-w-0" onClick={() => loadRequest(req)}>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-[10px] px-1 rounded" style={{ color: METHOD_COLORS[req.method], background: `${METHOD_COLORS[req.method]}15` }}>
                      {req.method}
                    </span>
                    {req.status && (
                      <span className="text-[10px]" style={{ color: getStatusColor(req.status) }}>{req.status}</span>
                    )}
                  </div>
                  <div className="truncate text-[#8A8578] mt-0.5">{req.url}</div>
                </div>
                <button
                  className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-[#B84A4A]/20 transition-all shrink-0"
                  onClick={e => { e.stopPropagation(); setHistory(prev => prev.filter(h => h.id !== req.id)); }}
                >
                  <X className="w-3 h-3 text-[#B84A4A]" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Request bar */}
        <div className="flex items-center gap-2 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0">
          <button
            className="p-1.5 rounded hover:bg-[#222235] transition-colors shrink-0"
            onClick={() => setShowHistory(!showHistory)}
          >
            <History className={`w-4 h-4 ${showHistory ? 'text-[#C9A84C]' : 'text-[#8A8578]'}`} />
          </button>

          {/* Method selector */}
          <div className="relative shrink-0">
            <select
              className="appearance-none bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 pr-7 font-mono text-xs outline-none focus:border-[#C9A84C] cursor-pointer"
              style={{ color: METHOD_COLORS[method] }}
              value={method}
              onChange={e => setMethod(e.target.value as HttpMethod)}
            >
              {(['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'] as HttpMethod[]).map(m => (
                <option key={m} value={m} style={{ color: METHOD_COLORS[m] }}>{m}</option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-[#8A8578]" />
          </div>

          {/* URL */}
          <input
            type="text"
            className="flex-1 bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 font-mono text-xs outline-none focus:border-[#C9A84C] min-w-0"
            value={url}
            onChange={e => setUrl(e.target.value)}
            placeholder="https://api.example.com/endpoint"
            onKeyDown={e => e.key === 'Enter' && sendRequest()}
          />

          {/* Send button */}
          <button
            className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#C9A84C] text-[#030305] font-medium hover:bg-[#D4B85A] transition-colors shrink-0 disabled:opacity-50"
            onClick={sendRequest}
            disabled={loading}
          >
            {loading ? (
              <div className="w-3.5 h-3.5 border-2 border-[#030305] border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            Send
          </button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Request config */}
          <div className="w-1/2 flex flex-col border-r border-[#2A2A3E] min-w-0">
            {/* Request tabs */}
            <div className="flex items-center gap-0 border-b border-[#2A2A3E] shrink-0">
              <button
                className={`px-3 py-2 text-xs transition-colors border-b-2 ${activeReqTab === 'headers' ? 'border-[#C9A84C] text-[#C9A84C]' : 'border-transparent text-[#8A8578] hover:text-[#E8E4DC]'}`}
                onClick={() => setActiveReqTab('headers')}
              >
                Headers ({headers.filter(h => h.enabled).length})
              </button>
              <button
                className={`px-3 py-2 text-xs transition-colors border-b-2 ${activeReqTab === 'body' ? 'border-[#C9A84C] text-[#C9A84C]' : 'border-transparent text-[#8A8578] hover:text-[#E8E4DC]'}`}
                onClick={() => setActiveReqTab('body')}
              >
                Body
              </button>
            </div>

            {activeReqTab === 'headers' ? (
              <div className="flex-1 overflow-auto p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-[#4D4A42] uppercase tracking-wider">Request Headers</span>
                  <button
                    className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] text-[10px]"
                    onClick={addHeader}
                  >
                    <Plus className="w-3 h-3" /> Add
                  </button>
                </div>
                <div className="flex flex-col gap-1.5">
                  {headers.map(h => (
                    <div key={h.id} className="flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={h.enabled}
                        onChange={() => toggleHeader(h.id)}
                        className="accent-[#C9A84C] shrink-0"
                      />
                      <input
                        type="text"
                        className="flex-1 min-w-0 bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 font-mono text-[11px] outline-none focus:border-[#C9A84C]"
                        placeholder="Header"
                        value={h.key}
                        onChange={e => updateHeader(h.id, 'key', e.target.value)}
                      />
                      <input
                        type="text"
                        className="flex-1 min-w-0 bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 font-mono text-[11px] outline-none focus:border-[#C9A84C]"
                        placeholder="Value"
                        value={h.value}
                        onChange={e => updateHeader(h.id, 'value', e.target.value)}
                      />
                      <button
                        className="p-1 rounded hover:bg-[#B84A4A]/20 shrink-0"
                        onClick={() => removeHeader(h.id)}
                      >
                        <X className="w-3 h-3 text-[#B84A4A]" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-hidden">
                <textarea
                  className="w-full h-full bg-[#030305] p-3 font-mono text-xs resize-none outline-none text-[#E8E4DC] whitespace-pre"
                  value={body}
                  onChange={e => setBody(e.target.value)}
                  placeholder="Request body (JSON)..."
                  spellCheck={false}
                />
              </div>
            )}
          </div>

          {/* Response */}
          <div className="w-1/2 flex flex-col min-w-0">
            {response ? (
              <>
                {/* Response status bar */}
                <div className="flex items-center gap-3 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
                  <span className="font-mono text-sm font-bold" style={{ color: getStatusColor(response.status) }}>
                    {response.status} {response.statusText}
                  </span>
                  <span className="flex items-center gap-1 text-[#8A8578]">
                    <Clock className="w-3 h-3" /> {response.time}ms
                  </span>
                  <span className="text-[#8A8578]">{(response.size / 1024).toFixed(2)} KB</span>
                  <div className="flex-1" />
                  <button
                    className="p-1 rounded hover:bg-[#222235]"
                    onClick={() => { copyText(response.body); }}
                  >
                    {copied ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3 text-[#8A8578]" />}
                  </button>
                </div>

                {/* Response tabs */}
                <div className="flex items-center gap-0 border-b border-[#2A2A3E] shrink-0">
                  <button
                    className={`px-3 py-1.5 text-xs transition-colors border-b-2 ${resTab === 'body' ? 'border-[#C9A84C] text-[#C9A84C]' : 'border-transparent text-[#8A8578]'}`}
                    onClick={() => setResTab('body')}
                  >
                    Body
                  </button>
                  <button
                    className={`px-3 py-1.5 text-xs transition-colors border-b-2 ${resTab === 'headers' ? 'border-[#C9A84C] text-[#C9A84C]' : 'border-transparent text-[#8A8578]'}`}
                    onClick={() => setResTab('headers')}
                  >
                    Headers ({Object.keys(response.headers).length})
                  </button>
                  <div className="flex-1" />
                  {resTab === 'body' && (
                    <div className="flex items-center gap-1 pr-2">
                      <button
                        className={`px-2 py-0.5 text-[10px] rounded ${bodyFormat === 'formatted' ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'text-[#8A8578]'}`}
                        onClick={() => setBodyFormat('formatted')}
                      >
                        Formatted
                      </button>
                      <button
                        className={`px-2 py-0.5 text-[10px] rounded ${bodyFormat === 'raw' ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'text-[#8A8578]'}`}
                        onClick={() => setBodyFormat('raw')}
                      >
                        Raw
                      </button>
                    </div>
                  )}
                </div>

                {/* Response content */}
                <div className="flex-1 overflow-auto p-3 font-mono text-xs">
                  {resTab === 'body' ? (
                    <pre className="whitespace-pre-wrap break-all text-[#5A9E6F]">
                      {bodyFormat === 'formatted' ? formatBody(response.body) : response.body}
                    </pre>
                  ) : (
                    <div className="flex flex-col gap-1">
                      {Object.entries(response.headers).map(([k, v]) => (
                        <div key={k} className="flex gap-2">
                          <span className="text-[#C9A84C] shrink-0">{k}:</span>
                          <span className="text-[#8A8578] break-all">{v}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            ) : error ? (
              <div className="flex-1 flex flex-col items-center justify-center text-[#B84A4A]">
                <X className="w-10 h-10 mb-2 opacity-40" />
                <p className="text-sm font-medium">Request Failed</p>
                <p className="text-xs text-[#8A8578] mt-1 max-w-xs text-center">{error}</p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-[#4D4A42]">
                <Globe className="w-12 h-12 mb-3 opacity-30" />
                <p className="text-sm">Send a request to see the response</p>
                <p className="text-xs mt-1 opacity-60">Enter a URL and click Send</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}


