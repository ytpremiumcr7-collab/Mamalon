import { useState, useCallback, useMemo } from 'react';
import {
  GitCompare, ArrowRightLeft, Trash2, Copy, Check,
  Columns, Rows
} from 'lucide-react';

const SAMPLE_OLD = `function calculateTotal(items) {
  let total = 0;
  for (const item of items) {
    total += item.price * item.qty;
  }
  return total;
}

function greet() {
  return "Hello";
}

function formatUser(user) {
  return user.firstName + " " + user.lastName;
}

const API_BASE = "https://api.example.com/v1";
const MAX_RETRIES = 3;

function fetchData(endpoint) {
  return fetch(API_BASE + endpoint)
    .then(res => res.json());
}

export { calculateTotal, greet, fetchData };`;

const SAMPLE_NEW = `function calculateTotal(items) {
  let total = 0;
  for (const item of items) {
    total += item.price * item.qty;
  }
  return total.toFixed(2);
}

function greet(name) {
  return \`Hello, \${name}\`;
}

function formatUser(user) {
  return \`\${user.firstName} \${user.lastName}\`;
}

const API_BASE = "https://api.cornstone.dev/v2";
const MAX_RETRIES = 5;
const TIMEOUT = 30000;

function fetchData(endpoint, options = {}) {
  return fetch(API_BASE + endpoint, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    }
  }).then(res => res.json());
}

export { calculateTotal, greet, fetchData, formatUser };`;

/* ── diff algorithm (LCS-based) ── */
type DiffOp = { type: 'same' | 'add' | 'remove'; oldLine?: string; newLine?: string; oldIndex?: number; newIndex?: number };

function computeDiff(oldText: string, newText: string): DiffOp[] {
  const oldLines = oldText.split('\n');
  const newLines = newText.split('\n');

  /* Simple LCS-based diff */
  const m = oldLines.length;
  const n = newLines.length;

  // Compute LCS
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (oldLines[i - 1] === newLines[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  // Backtrack
  const result: DiffOp[] = [];
  let i = m, j = n;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && oldLines[i - 1] === newLines[j - 1]) {
      result.unshift({ type: 'same', oldLine: oldLines[i - 1], newLine: newLines[j - 1], oldIndex: i - 1, newIndex: j - 1 });
      i--; j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.unshift({ type: 'add', newLine: newLines[j - 1], newIndex: j - 1 });
      j--;
    } else {
      result.unshift({ type: 'remove', oldLine: oldLines[i - 1], oldIndex: i - 1 });
      i--;
    }
  }

  return result;
}

/* ── character-level diff for changed lines ── */
function charDiff(oldLine: string, newLine: string): { oldHtml: string; newHtml: string } {
  /* Simple word-level diff */
  const oldWords = oldLine.split(/(\s+)/);
  const newWords = newLine.split(/(\s+)/);

  // Very simple approach: find common prefix and suffix
  let prefixLen = 0;
  while (prefixLen < oldWords.length && prefixLen < newWords.length &&
         oldWords[prefixLen] === newWords[prefixLen]) prefixLen++;

  let suffixLen = 0;
  while (suffixLen < oldWords.length - prefixLen && suffixLen < newWords.length - prefixLen &&
         oldWords[oldWords.length - 1 - suffixLen] === newWords[newWords.length - 1 - suffixLen]) suffixLen++;

  const oldPrefix = oldWords.slice(0, prefixLen).join('');
  const oldChanged = oldWords.slice(prefixLen, oldWords.length - suffixLen).join('');
  const oldSuffix = oldWords.slice(oldWords.length - suffixLen).join('');

  const newPrefix = newWords.slice(0, prefixLen).join('');
  const newChanged = newWords.slice(prefixLen, newWords.length - suffixLen).join('');
  const newSuffix = newWords.slice(newWords.length - suffixLen).join('');

  return {
    oldHtml: escapeHtml(oldPrefix) + (oldChanged ? `<del class="bg-[#B84A4A]/30 text-[#B84A4A] decoration-none">${escapeHtml(oldChanged)}</del>` : '') + escapeHtml(oldSuffix),
    newHtml: escapeHtml(newPrefix) + (newChanged ? `<ins class="bg-[#5A9E6F]/30 text-[#5A9E6F] decoration-none">${escapeHtml(newChanged)}</ins>` : '') + escapeHtml(newSuffix),
  };
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export default function DiffTool() {
  const [oldText, setOldText] = useState(SAMPLE_OLD);
  const [newText, setNewText] = useState(SAMPLE_NEW);
  const [viewMode, setViewMode] = useState<'split' | 'inline'>('split');
  const [diff, setDiff] = useState<DiffOp[] | null>(null);
  const [copied, setCopied] = useState(false);

  const compare = useCallback(() => {
    setDiff(computeDiff(oldText, newText));
  }, [oldText, newText]);

  const stats = useMemo(() => {
    if (!diff) return { added: 0, removed: 0, modified: 0 };
    let added = 0, removed = 0, modified = 0;
    diff.forEach(op => {
      if (op.type === 'add') added++;
      if (op.type === 'remove') removed++;
    });
    /* Count modified as adjacent add/remove pairs */
    for (let i = 0; i < diff.length - 1; i++) {
      if (diff[i].type === 'remove' && diff[i + 1].type === 'add') {
        modified++;
        added--;
        removed--;
      }
    }
    return { added, removed, modified };
  }, [diff]);

  const swapSides = useCallback(() => {
    setOldText(newText);
    setNewText(oldText);
    setDiff(null);
  }, [oldText, newText]);

  const copyDiff = useCallback(async () => {
    if (!diff) return;
    const text = diff.map(op => {
      if (op.type === 'same') return ` ${op.oldLine}`;
      if (op.type === 'add') return `+${op.newLine}`;
      return `-${op.oldLine}`;
    }).join('\n');
    try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* noop */ }
  }, [diff]);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        <button
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#C9A84C] text-[#030305] font-medium hover:bg-[#D4B85A] transition-colors"
          onClick={compare}
        >
          <GitCompare className="w-3.5 h-3.5" /> Compare
        </button>
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
          onClick={swapSides}
        >
          <ArrowRightLeft className="w-3 h-3" /> Swap
        </button>
        {diff && (
          <button
            className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
            onClick={copyDiff}
          >
            {copied ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        )}
        <div className="w-px h-5 bg-[#2A2A3E]" />
        <button
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded border transition-colors ${viewMode === 'split' ? 'bg-[#C9A84C]/20 border-[#C9A84C] text-[#C9A84C]' : 'bg-[#1A1A26] border-[#2A2A3E] hover:bg-[#222235]'}`}
          onClick={() => setViewMode('split')}
        >
          <Columns className="w-3 h-3" /> Split
        </button>
        <button
          className={`flex items-center gap-1 px-2.5 py-1.5 rounded border transition-colors ${viewMode === 'inline' ? 'bg-[#C9A84C]/20 border-[#C9A84C] text-[#C9A84C]' : 'bg-[#1A1A26] border-[#2A2A3E] hover:bg-[#222235]'}`}
          onClick={() => setViewMode('inline')}
        >
          <Rows className="w-3 h-3" /> Inline
        </button>
        <div className="flex-1" />
        {diff && (
          <div className="flex items-center gap-3 text-[10px]">
            <span className="text-[#5A9E6F]">+{stats.added} added</span>
            <span className="text-[#B84A4A]">-{stats.removed} removed</span>
            {stats.modified > 0 && <span className="text-[#D4953A]">~{stats.modified} modified</span>}
          </div>
        )}
        <button
          className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#B84A4A]/20 text-[#B84A4A]"
          onClick={() => { setOldText(''); setNewText(''); setDiff(null); }}
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>

      {/* Input areas or Diff view */}
      {!diff ? (
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 flex flex-col border-r border-[#2A2A3E] min-w-0">
            <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
              Original
            </div>
            <textarea
              className="flex-1 bg-[#030305] p-3 font-mono text-xs resize-none outline-none text-[#E8E4DC] whitespace-pre overflow-auto"
              value={oldText}
              onChange={e => setOldText(e.target.value)}
              spellCheck={false}
              placeholder="Paste original text..."
            />
          </div>
          <div className="flex-1 flex flex-col min-w-0">
            <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
              Modified
            </div>
            <textarea
              className="flex-1 bg-[#030305] p-3 font-mono text-xs resize-none outline-none text-[#E8E4DC] whitespace-pre overflow-auto"
              value={newText}
              onChange={e => setNewText(e.target.value)}
              spellCheck={false}
              placeholder="Paste modified text..."
            />
          </div>
        </div>
      ) : (
        /* Diff display */
        <div className="flex-1 overflow-auto">
          {viewMode === 'split' ? (
            /* Side-by-side */
            <table className="w-full border-collapse">
              <thead className="sticky top-0 z-10">
                <tr>
                  <th className="w-12 bg-[#0A0A0F] border-b border-r border-[#2A2A3E] text-[10px] text-[#4D4A42] font-normal py-1">#</th>
                  <th className="w-1/2 bg-[#0A0A0F] border-b border-r border-[#2A2A3E] text-[10px] text-[#4D4A42] font-normal py-1 px-2 text-left">Original</th>
                  <th className="w-12 bg-[#0A0A0F] border-b border-r border-[#2A2A3E] text-[10px] text-[#4D4A42] font-normal py-1">#</th>
                  <th className="w-1/2 bg-[#0A0A0F] border-b border-[#2A2A3E] text-[10px] text-[#4D4A42] font-normal py-1 px-2 text-left">Modified</th>
                </tr>
              </thead>
              <tbody>
                {diff.map((op, i) => {
                  if (op.type === 'same') {
                    return (
                      <tr key={i} className="hover:bg-[#1A1A26]/30">
                        <td className="w-12 text-right pr-2 text-[10px] text-[#4D4A42] border-r border-[#2A2A3E]/50 select-none">{(op.oldIndex ?? 0) + 1}</td>
                        <td className="font-mono text-xs px-2 py-0.5 border-r border-[#2A2A3E]/50 whitespace-pre">{op.oldLine}</td>
                        <td className="w-12 text-right pr-2 text-[10px] text-[#4D4A42] border-r border-[#2A2A3E]/50 select-none">{(op.newIndex ?? 0) + 1}</td>
                        <td className="font-mono text-xs px-2 py-0.5 whitespace-pre">{op.newLine}</td>
                      </tr>
                    );
                  }

                  if (op.type === 'remove') {
                    /* Check if next is add (modified pair) */
                    const nextOp = diff[i + 1];
                    if (nextOp && nextOp.type === 'add') {
                      const cd = charDiff(op.oldLine || '', nextOp.newLine || '');
                      return (
                        <tr key={i} className="bg-[#D4953A]/5">
                          <td className="w-12 text-right pr-2 text-[10px] text-[#B84A4A] border-r border-[#2A2A3E]/50 select-none font-medium">{(op.oldIndex ?? 0) + 1}</td>
                          <td className="font-mono text-xs px-2 py-0.5 border-r border-[#2A2A3E]/50 whitespace-pre"
                            dangerouslySetInnerHTML={{ __html: cd.oldHtml }} />
                          <td className="w-12 text-right pr-2 text-[10px] text-[#5A9E6F] border-r border-[#2A2A3E]/50 select-none font-medium">{(nextOp.newIndex ?? 0) + 1}</td>
                          <td className="font-mono text-xs px-2 py-0.5 whitespace-pre"
                            dangerouslySetInnerHTML={{ __html: cd.newHtml }} />
                        </tr>
                      );
                    }

                    return (
                      <tr key={i} className="bg-[#B84A4A]/8">
                        <td className="w-12 text-right pr-2 text-[10px] text-[#B84A4A] border-r border-[#2A2A3E]/50 select-none font-medium">{(op.oldIndex ?? 0) + 1}</td>
                        <td className="font-mono text-xs px-2 py-0.5 border-r border-[#2A2A3E]/50 text-[#B84A4A] whitespace-pre">{op.oldLine}</td>
                        <td className="w-12 border-r border-[#2A2A3E]/50" />
                        <td />
                      </tr>
                    );
                  }

                  if (op.type === 'add') {
                    /* Check if previous was remove (already handled as pair) */
                    const prevOp = diff[i - 1];
                    if (prevOp && prevOp.type === 'remove') return null;

                    return (
                      <tr key={i} className="bg-[#5A9E6F]/8">
                        <td className="w-12 border-r border-[#2A2A3E]/50" />
                        <td className="border-r border-[#2A2A3E]/50" />
                        <td className="w-12 text-right pr-2 text-[10px] text-[#5A9E6F] border-r border-[#2A2A3E]/50 select-none font-medium">{(op.newIndex ?? 0) + 1}</td>
                        <td className="font-mono text-xs px-2 py-0.5 text-[#5A9E6F] whitespace-pre">{op.newLine}</td>
                      </tr>
                    );
                  }

                  return null;
                })}
              </tbody>
            </table>
          ) : (
            /* Inline view */
            <div className="font-mono text-xs">
              {diff.map((op, i) => {
                if (op.type === 'same') {
                  return (
                    <div key={i} className="flex hover:bg-[#1A1A26]/30">
                      <span className="w-12 text-right pr-2 text-[10px] text-[#4D4A42] select-none shrink-0 border-r border-[#2A2A3E]/50"> </span>
                      <span className="px-2 py-0.5 whitespace-pre">{op.oldLine}</span>
                    </div>
                  );
                }
                if (op.type === 'remove') {
                  const nextOp = diff[i + 1];
                  if (nextOp && nextOp.type === 'add') {
                    const cd = charDiff(op.oldLine || '', nextOp.newLine || '');
                    return (
                      <div key={i}>
                        <div className="flex bg-[#B84A4A]/8">
                          <span className="w-12 text-right pr-2 text-[10px] text-[#B84A4A] select-none shrink-0 border-r border-[#2A2A3E]/50 font-medium">-</span>
                          <span className="px-2 py-0.5 whitespace-pre text-[#B84A4A]" dangerouslySetInnerHTML={{ __html: cd.oldHtml }} />
                        </div>
                        <div className="flex bg-[#5A9E6F]/8">
                          <span className="w-12 text-right pr-2 text-[10px] text-[#5A9E6F] select-none shrink-0 border-r border-[#2A2A3E]/50 font-medium">+</span>
                          <span className="px-2 py-0.5 whitespace-pre text-[#5A9E6F]" dangerouslySetInnerHTML={{ __html: cd.newHtml }} />
                        </div>
                      </div>
                    );
                  }
                  return (
                    <div key={i} className="flex bg-[#B84A4A]/8">
                      <span className="w-12 text-right pr-2 text-[10px] text-[#B84A4A] select-none shrink-0 border-r border-[#2A2A3E]/50 font-medium">-</span>
                      <span className="px-2 py-0.5 whitespace-pre text-[#B84A4A]">{op.oldLine}</span>
                    </div>
                  );
                }
                if (op.type === 'add') {
                  const prevOp = diff[i - 1];
                  if (prevOp && prevOp.type === 'remove') return null;
                  return (
                    <div key={i} className="flex bg-[#5A9E6F]/8">
                      <span className="w-12 text-right pr-2 text-[10px] text-[#5A9E6F] select-none shrink-0 border-r border-[#2A2A3E]/50 font-medium">+</span>
                      <span className="px-2 py-0.5 whitespace-pre text-[#5A9E6F]">{op.newLine}</span>
                    </div>
                  );
                }
                return null;
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
