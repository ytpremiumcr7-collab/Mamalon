import { useState, useEffect, useRef } from 'react';
import {
  Globe,
  Bell,
  Timer,
  Watch,
  Plus,
  X,
  Trash2,
  Play,
  Pause,
  RotateCcw,
  Flag,
  Sun,
  Moon,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@radix-ui/react-tabs';
import { motion, AnimatePresence } from 'framer-motion';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface City {
  id: string;
  name: string;
  timezone: string;
}

interface Alarm {
  id: string;
  time: string;
  label: string;
  repeat: string[];
  enabled: boolean;
}

interface StopwatchLap {
  id: number;
  split: number;
  total: number;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY_ALARM = 'cornstone-alarms';

const DEFAULT_CITIES: City[] = [
  { id: 'c1', name: 'Mexico City', timezone: 'America/Mexico_City' },
  { id: 'c2', name: 'New York', timezone: 'America/New_York' },
  { id: 'c3', name: 'London', timezone: 'Europe/London' },
  { id: 'c4', name: 'Tokyo', timezone: 'Asia/Tokyo' },
  { id: 'c5', name: 'Paris', timezone: 'Europe/Paris' },
  { id: 'c6', name: 'Sydney', timezone: 'Australia/Sydney' },
];

const ALL_CITIES: City[] = [
  ...DEFAULT_CITIES,
  { id: 'c7', name: 'Los Angeles', timezone: 'America/Los_Angeles' },
  { id: 'c8', name: 'Chicago', timezone: 'America/Chicago' },
  { id: 'c9', name: 'Dubai', timezone: 'Asia/Dubai' },
  { id: 'c10', name: 'Singapore', timezone: 'Asia/Singapore' },
  { id: 'c11', name: 'Berlin', timezone: 'Europe/Berlin' },
  { id: 'c12', name: 'Moscow', timezone: 'Europe/Moscow' },
  { id: 'c13', name: 'Mumbai', timezone: 'Asia/Kolkata' },
  { id: 'c14', name: 'Shanghai', timezone: 'Asia/Shanghai' },
  { id: 'c15', name: 'Sao Paulo', timezone: 'America/Sao_Paulo' },
  { id: 'c16', name: 'Cairo', timezone: 'Africa/Cairo' },
];

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadAlarms(): Alarm[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ALARM);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  return [
    { id: 'a1', time: '07:00', label: 'Morning Routine', repeat: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], enabled: true },
    { id: 'a2', time: '09:00', label: 'Stand-up Meeting', repeat: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], enabled: false },
  ];
}

function saveAlarms(alarms: Alarm[]) {
  localStorage.setItem(STORAGE_KEY_ALARM, JSON.stringify(alarms));
}

function generateId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

/* ------------------------------------------------------------------ */
/*  Analog Clock Face                                                  */
/* ------------------------------------------------------------------ */
function AnalogClock({ date, size = 120 }: { date: Date; size?: number }) {
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 6;

  const hours = date.getHours() % 12;
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  const hourAngle = (hours + minutes / 60) * 30;
  const minAngle = (minutes + seconds / 60) * 6;
  const secAngle = seconds * 6;

  const hourLen = r * 0.5;
  const minLen = r * 0.7;
  const secLen = r * 0.8;

  const hand = (angle: number, len: number, width: number, color: string) => {
    const rad = (angle - 90) * Math.PI / 180;
    const x2 = cx + len * Math.cos(rad);
    const y2 = cy + len * Math.sin(rad);
    return <line x1={cx} y1={cy} x2={x2} y2={y2} stroke={color} strokeWidth={width} strokeLinecap="round" />;
  };

  return (
    <svg width={size} height={size} className="flex-shrink-0">
      {/* Face */}
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#2A2A3E" strokeWidth={1.5} />
      <circle cx={cx} cy={cy} r={2} fill="#C9A84C" />
      {/* Hour markers */}
      {Array.from({ length: 12 }, (_, i) => {
        const a = (i * 30 - 90) * Math.PI / 180;
        const x1 = cx + (r - 8) * Math.cos(a);
        const y1 = cy + (r - 8) * Math.sin(a);
        const x2 = cx + (r - 4) * Math.cos(a);
        const y2 = cy + (r - 4) * Math.sin(a);
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#8A8578" strokeWidth={i % 3 === 0 ? 2 : 1} />;
      })}
      {/* Hands */}
      {hand(hourAngle, hourLen, 2.5, '#E8E4DC')}
      {hand(minAngle, minLen, 1.5, '#E8E4DC')}
      {hand(secAngle, secLen, 0.8, '#C9A84C')}
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  World Clock Tab                                                    */
/* ------------------------------------------------------------------ */
function WorldClockTab() {
  const [time, setTime] = useState(new Date());
  const [cities, setCities] = useState<City[]>(DEFAULT_CITIES);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const getCityTime = (tz: string) => {
    return new Date(time.toLocaleString('en-US', { timeZone: tz }));
  };

  const isDaytime = (tz: string) => {
    const h = getCityTime(tz).getHours();
    return h >= 6 && h < 18;
  };

  const removeCity = (id: string) => {
    setCities((prev) => prev.filter((c) => c.id !== id));
  };

  const addCity = (city: City) => {
    if (!cities.find((c) => c.id === city.id)) {
      setCities((prev) => [...prev, city]);
    }
    setShowAdd(false);
  };

  return (
    <div className="p-4 h-full overflow-auto">
      {/* Local time hero */}
      <div className="flex items-center justify-center gap-6 mb-6 p-4 bg-[#1A1A26] rounded-xl border border-[#2A2A3E]">
        <AnalogClock date={time} size={140} />
        <div>
          <div className="text-3xl font-mono text-[#E8E4DC] font-semibold tracking-wider">
            {time.toLocaleTimeString('en-US', { hour12: false })}
          </div>
          <div className="text-sm text-[#8A8578] mt-1">
            {time.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
          </div>
          <div className="text-xs text-[#4D4A42] mt-0.5 flex items-center gap-1">
            {isDaytime(Intl.DateTimeFormat().resolvedOptions().timeZone) ? (
              <><Sun className="w-3 h-3 text-[#C9A84C]" /> Daytime</>
            ) : (
              <><Moon className="w-3 h-3 text-[#5A8AB8]" /> Nighttime</>
            )}
            <span className="mx-1">·</span>
            <span>Local Time</span>
          </div>
        </div>
      </div>

      {/* City grid */}
      <div className="grid grid-cols-2 gap-3">
        {cities.map((city) => {
          const cityTime = getCityTime(city.timezone);
          const day = isDaytime(city.timezone);
          const diff = Math.round((cityTime.getTime() - new Date(time.toLocaleString('en-US', { timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone })).getTime()) / 3600000);

          return (
            <motion.div
              key={city.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-[#1A1A26] border border-[#2A2A3E] rounded-xl p-3 flex items-center gap-3 relative group"
            >
              <AnalogClock date={cityTime} size={70} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-medium text-[#E8E4DC] truncate">{city.name}</span>
                  {day ? <Sun className="w-3 h-3 text-[#C9A84C] flex-shrink-0" /> : <Moon className="w-3 h-3 text-[#5A8AB8] flex-shrink-0" />}
                </div>
                <div className="text-lg font-mono text-[#E8E4DC] mt-0.5">
                  {cityTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
                </div>
                <div className="text-[10px] text-[#8A8578]">
                  {cityTime.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                  <span className="ml-1.5 text-[#4D4A42]">{diff >= 0 ? `+${diff}` : diff}h</span>
                </div>
              </div>
              <button
                onClick={() => removeCity(city.id)}
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-0.5 hover:bg-[#B84A4A]/20 rounded transition-all"
              >
                <X className="w-3 h-3 text-[#B84A4A]" />
              </button>
            </motion.div>
          );
        })}

        {/* Add city button */}
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="bg-[#1A1A26] border border-[#2A2A3E] border-dashed rounded-xl p-3 flex items-center justify-center gap-2 text-[#8A8578] hover:border-[#C9A84C] hover:text-[#C9A84C] transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span className="text-xs">Add City</span>
        </button>
      </div>

      {/* Add city dropdown */}
      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 bg-[#1A1A26] border border-[#2A2A3E] rounded-xl p-3 overflow-hidden"
          >
            <div className="text-xs text-[#8A8578] mb-2">Select a city:</div>
            <div className="grid grid-cols-3 gap-1.5">
              {ALL_CITIES.filter((c) => !cities.find((x) => x.id === c.id)).map((city) => (
                <button
                  key={city.id}
                  onClick={() => addCity(city)}
                  className="px-2 py-1.5 bg-[#12121A] border border-[#2A2A3E] rounded text-[11px] text-[#E8E4DC] hover:border-[#C9A84C] transition-colors text-left"
                >
                  {city.name}
                </button>
              ))}
            </div>
            {ALL_CITIES.filter((c) => !cities.find((x) => x.id === c.id)).length === 0 && (
              <div className="text-xs text-[#4D4A42] text-center py-2">All cities added</div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Alarm Tab                                                          */
/* ------------------------------------------------------------------ */
function AlarmTab() {
  const [alarms, setAlarms] = useState<Alarm[]>(loadAlarms);
  const [showAdd, setShowAdd] = useState(false);
  const [newTime, setNewTime] = useState('08:00');
  const [newLabel, setNewLabel] = useState('');
  const [newRepeat, setNewRepeat] = useState<string[]>([]);

  useEffect(() => { saveAlarms(alarms); }, [alarms]);

  const toggleAlarm = (id: string) => {
    setAlarms((prev) => prev.map((a) => a.id === id ? { ...a, enabled: !a.enabled } : a));
  };

  const deleteAlarm = (id: string) => {
    setAlarms((prev) => prev.filter((a) => a.id !== id));
  };

  const addAlarm = () => {
    if (!newTime) return;
    setAlarms((prev) => [...prev, {
      id: generateId('alarm'),
      time: newTime,
      label: newLabel || 'Alarm',
      repeat: newRepeat,
      enabled: true,
    }]);
    setNewLabel('');
    setNewRepeat([]);
    setShowAdd(false);
  };

  const toggleRepeatDay = (day: string) => {
    setNewRepeat((prev) => prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]);
  };

  return (
    <div className="p-4 h-full overflow-auto">
      <button
        onClick={() => setShowAdd(!showAdd)}
        className="w-full mb-3 h-9 bg-[#C9A84C] text-[#030305] rounded-lg text-xs font-semibold hover:bg-[#D4B85A] transition-colors flex items-center justify-center gap-1.5"
      >
        <Plus className="w-4 h-4" />
        Add Alarm
      </button>

      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#1A1A26] border border-[#2A2A3E] rounded-xl p-4 mb-3 space-y-3 overflow-hidden"
          >
            <div className="flex gap-3">
              <div className="flex-1">
                <label className="text-[10px] text-[#8A8578] block mb-1">Time</label>
                <input
                  type="time"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none"
                />
              </div>
              <div className="flex-1">
                <label className="text-[10px] text-[#8A8578] block mb-1">Label</label>
                <input
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  placeholder="Alarm label"
                  className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none"
                />
              </div>
            </div>
            <div>
              <label className="text-[10px] text-[#8A8578] block mb-1">Repeat</label>
              <div className="flex gap-1">
                {DAYS.map((d) => (
                  <button
                    key={d}
                    onClick={() => toggleRepeatDay(d)}
                    className={`flex-1 h-7 rounded text-[10px] font-medium transition-colors ${
                      newRepeat.includes(d) ? 'bg-[#C9A84C] text-[#030305]' : 'bg-[#222235] text-[#8A8578] hover:bg-[#2A2A3E]'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowAdd(false)} className="flex-1 h-8 bg-[#222235] text-[#E8E4DC] rounded text-xs hover:bg-[#2A2A3E] transition-colors">Cancel</button>
              <button onClick={addAlarm} className="flex-1 h-8 bg-[#C9A84C] text-[#030305] rounded text-xs font-semibold hover:bg-[#D4B85A] transition-colors">Save</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-2">
        {alarms.length === 0 && (
          <div className="text-center text-xs text-[#4D4A42] py-8">
            <Bell className="w-6 h-6 mx-auto mb-2 opacity-30" />
            No alarms set
          </div>
        )}
        {alarms.map((alarm) => (
          <motion.div
            key={alarm.id}
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-[#1A1A26] border border-[#2A2A3E] rounded-xl p-3 flex items-center gap-3"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className={`text-xl font-mono font-semibold ${alarm.enabled ? 'text-[#E8E4DC]' : 'text-[#4D4A42]'}`}>
                  {alarm.time}
                </span>
                <span className="text-[10px] text-[#8A8578]">{alarm.label}</span>
              </div>
              {alarm.repeat.length > 0 && (
                <div className="text-[10px] text-[#8A8578] mt-0.5">
                  {alarm.repeat.join(', ')}
                </div>
              )}
            </div>
            <button
              onClick={() => toggleAlarm(alarm.id)}
              className={`w-10 h-5 rounded-full transition-colors relative ${
                alarm.enabled ? 'bg-[#C9A84C]' : 'bg-[#2A2A3E]'
              }`}
            >
              <div
                className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                  alarm.enabled ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
            <button
              onClick={() => deleteAlarm(alarm.id)}
              className="p-1.5 hover:bg-[#B84A4A]/20 rounded transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5 text-[#B84A4A]" />
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Timer Tab                                                          */
/* ------------------------------------------------------------------ */
function TimerTab() {
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(5);
  const [seconds, setSeconds] = useState(0);
  const [remaining, setRemaining] = useState(5 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const total = hours * 3600 + minutes * 60 + seconds;
  const progress = total > 0 ? ((total - remaining) / total) * 100 : 0;

  useEffect(() => {
    if (isRunning && !isPaused) {
      intervalRef.current = setInterval(() => {
        setRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning, isPaused]);

  const start = () => {
    const t = hours * 3600 + minutes * 60 + seconds;
    if (t <= 0) return;
    if (!isPaused) setRemaining(t);
    setIsRunning(true);
    setIsPaused(false);
  };

  const pause = () => {
    setIsPaused(true);
    setIsRunning(false);
  };

  const reset = () => {
    setIsRunning(false);
    setIsPaused(false);
    setRemaining(total);
  };

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  // SVG circle progress
  const size = 180;
  const strokeWidth = 6;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="p-4 h-full flex flex-col items-center justify-center">
      {/* Input section */}
      <div className={`flex items-center gap-2 mb-6 transition-opacity ${isRunning || isPaused ? 'opacity-40 pointer-events-none' : ''}`}>
        <div className="text-center">
          <input
            type="number"
            min={0}
            max={23}
            value={hours}
            onChange={(e) => setHours(Math.max(0, Math.min(23, parseInt(e.target.value) || 0)))}
            className="w-14 h-12 bg-[#12121A] border border-[#2A2A3E] rounded-lg text-center text-xl font-mono text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none"
          />
          <div className="text-[10px] text-[#8A8578] mt-1">hrs</div>
        </div>
        <span className="text-xl text-[#8A8578] -mt-4">:</span>
        <div className="text-center">
          <input
            type="number"
            min={0}
            max={59}
            value={minutes}
            onChange={(e) => setMinutes(Math.max(0, Math.min(59, parseInt(e.target.value) || 0)))}
            className="w-14 h-12 bg-[#12121A] border border-[#2A2A3E] rounded-lg text-center text-xl font-mono text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none"
          />
          <div className="text-[10px] text-[#8A8578] mt-1">min</div>
        </div>
        <span className="text-xl text-[#8A8578] -mt-4">:</span>
        <div className="text-center">
          <input
            type="number"
            min={0}
            max={59}
            value={seconds}
            onChange={(e) => setSeconds(Math.max(0, Math.min(59, parseInt(e.target.value) || 0)))}
            className="w-14 h-12 bg-[#12121A] border border-[#2A2A3E] rounded-lg text-center text-xl font-mono text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none"
          />
          <div className="text-[10px] text-[#8A8578] mt-1">sec</div>
        </div>
      </div>

      {/* Circular progress */}
      <div className="relative mb-6">
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#2A2A3E" strokeWidth={strokeWidth} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#C9A84C"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-mono font-semibold text-[#E8E4DC]">{formatTime(remaining)}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        {!isRunning ? (
          <button
            onClick={start}
            className="h-10 px-5 bg-[#5A9E6F] text-white rounded-lg text-sm font-semibold hover:bg-[#6AAF7F] transition-colors flex items-center gap-1.5"
          >
            <Play className="w-4 h-4" />
            Start
          </button>
        ) : (
          <button
            onClick={pause}
            className="h-10 px-5 bg-[#C9A84C] text-[#030305] rounded-lg text-sm font-semibold hover:bg-[#D4B85A] transition-colors flex items-center gap-1.5"
          >
            <Pause className="w-4 h-4" />
            Pause
          </button>
        )}
        <button
          onClick={reset}
          className="h-10 px-5 bg-[#222235] text-[#E8E4DC] rounded-lg text-sm font-medium hover:bg-[#2A2A3E] transition-colors flex items-center gap-1.5"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Stopwatch Tab                                                      */
/* ------------------------------------------------------------------ */
function StopwatchTab() {
  const [elapsed, setElapsed] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<StopwatchLap[]>([]);
  const startTimeRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now() - elapsed;
      intervalRef.current = setInterval(() => {
        setElapsed(Date.now() - startTimeRef.current);
      }, 10);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning]);

  const start = () => setIsRunning(true);
  const stop = () => setIsRunning(false);
  const reset = () => {
    setIsRunning(false);
    setElapsed(0);
    setLaps([]);
  };

  const lap = () => {
    const prevTotal = laps.length > 0 ? laps[laps.length - 1].total : 0;
    setLaps((prev) => [...prev, { id: prev.length + 1, split: elapsed - prevTotal, total: elapsed }]);
  };

  const formatMs = (ms: number) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    const centi = Math.floor((ms % 1000) / 10);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${centi.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-4 h-full flex flex-col">
      {/* Time display */}
      <div className="text-center mb-4">
        <div className="text-4xl font-mono font-semibold text-[#E8E4DC] tracking-wider">
          {formatMs(elapsed)}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-3 mb-4">
        {!isRunning ? (
          <button
            onClick={start}
            className="h-10 px-5 bg-[#5A9E6F] text-white rounded-lg text-sm font-semibold hover:bg-[#6AAF7F] transition-colors flex items-center gap-1.5"
          >
            <Play className="w-4 h-4" />
            Start
          </button>
        ) : (
          <button
            onClick={stop}
            className="h-10 px-5 bg-[#B84A4A] text-white rounded-lg text-sm font-semibold hover:bg-[#C85A5A] transition-colors flex items-center gap-1.5"
          >
            <Pause className="w-4 h-4" />
            Stop
          </button>
        )}
        <button
          onClick={lap}
          disabled={!isRunning && elapsed === 0}
          className="h-10 px-5 bg-[#222235] text-[#E8E4DC] rounded-lg text-sm font-medium hover:bg-[#2A2A3E] transition-colors disabled:opacity-30 flex items-center gap-1.5"
        >
          <Flag className="w-4 h-4" />
          Lap
        </button>
        <button
          onClick={reset}
          className="h-10 px-5 bg-[#222235] text-[#8A8578] rounded-lg text-sm font-medium hover:bg-[#2A2A3E] transition-colors flex items-center gap-1.5"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </button>
      </div>

      {/* Laps */}
      {laps.length > 0 && (
        <div className="flex-1 overflow-auto border-t border-[#2A2A3E] pt-2">
          <div className="grid grid-cols-3 gap-2 text-[10px] text-[#8A8578] px-3 mb-1">
            <span>Lap</span>
            <span className="text-right">Split</span>
            <span className="text-right">Total</span>
          </div>
          <div className="space-y-0.5">
            {[...laps].reverse().map((lap) => (
              <div key={lap.id} className="grid grid-cols-3 gap-2 px-3 py-1.5 bg-[#1A1A26] rounded text-xs">
                <span className="text-[#8A8578]">#{lap.id}</span>
                <span className="text-right font-mono text-[#E8E4DC]">{formatMs(lap.split)}</span>
                <span className="text-right font-mono text-[#C9A84C]">{formatMs(lap.total)}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Clock App                                                     */
/* ------------------------------------------------------------------ */
export default function ClockApp() {
  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col">
      <Tabs defaultValue="world" className="flex-1 flex flex-col">
        <TabsList className="flex items-center gap-0 border-b border-[#2A2A3E] bg-[#0A0A0F] px-2">
          {[
            { value: 'world', icon: Globe, label: 'World' },
            { value: 'alarm', icon: Bell, label: 'Alarm' },
            { value: 'timer', icon: Timer, label: 'Timer' },
            { value: 'stopwatch', icon: Watch, label: 'Stopwatch' },
          ].map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="flex items-center gap-1.5 px-4 py-2.5 text-xs text-[#8A8578] border-b-2 border-transparent transition-colors data-[state=active]:text-[#C9A84C] data-[state=active]:border-[#C9A84C] hover:text-[#E8E4DC]"
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <div className="flex-1 overflow-hidden">
          <TabsContent value="world" className="h-full data-[state=inactive]:hidden">
            <WorldClockTab />
          </TabsContent>
          <TabsContent value="alarm" className="h-full data-[state=inactive]:hidden">
            <AlarmTab />
          </TabsContent>
          <TabsContent value="timer" className="h-full data-[state=inactive]:hidden">
            <TimerTab />
          </TabsContent>
          <TabsContent value="stopwatch" className="h-full data-[state=inactive]:hidden">
            <StopwatchTab />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
