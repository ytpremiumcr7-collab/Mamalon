import { useState, useRef, useCallback, useEffect } from 'react';
import {
  Upload, Download, RotateCcw, RotateCw, FlipHorizontal, FlipVertical,
  Crop, Sun, Contrast, Droplet, Eraser,
  Image as ImageIcon
} from 'lucide-react';

interface Adjustments {
  brightness: number;
  contrast: number;
  saturation: number;
  blur: number;
  grayscale: number;
  sepia: number;
  hueRotate: number;
  invert: number;
}

const DEFAULT_ADJUSTMENTS: Adjustments = {
  brightness: 100,
  contrast: 100,
  saturation: 100,
  blur: 0,
  grayscale: 0,
  sepia: 0,
  hueRotate: 0,
  invert: 0,
};

interface HistoryState {
  imageData: ImageData;
  adjustments: Adjustments;
  rotation: number;
  flipH: boolean;
  flipV: boolean;
}

export default function ImageEditor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [adjustments, setAdjustments] = useState<Adjustments>({ ...DEFAULT_ADJUSTMENTS });
  const [rotation, setRotation] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [, setHistoryData] = useState<HistoryState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [cropMode, setCropMode] = useState(false);
  const [cropStart, setCropStart] = useState<{ x: number; y: number } | null>(null);
  const [cropRect, setCropRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const buildFilterString = useCallback(() => {
    const a = adjustments;
    return [
      `brightness(${a.brightness}%)`,
      `contrast(${a.contrast}%)`,
      `saturate(${a.saturation}%)`,
      `blur(${a.blur}px)`,
      `grayscale(${a.grayscale}%)`,
      `sepia(${a.sepia}%)`,
      `hue-rotate(${a.hueRotate}deg)`,
      `invert(${a.invert}%)`,
    ].join(' ');
  }, [adjustments]);

  /* Draw image to canvas */
  const drawImage = useCallback(() => {
    if (!image || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = image.width;
    canvas.height = image.height;

    ctx.save();
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    /* Apply transforms */
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    ctx.translate(cx, cy);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.translate(-cx, -cy);

    /* Apply filters */
    ctx.filter = buildFilterString();
    ctx.drawImage(image, 0, 0);
    ctx.filter = 'none';
    ctx.restore();
  }, [image, adjustments, rotation, flipH, flipV, buildFilterString]);

  useEffect(() => { drawImage(); }, [drawImage]);

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => {
      setImage(img);
      setAdjustments({ ...DEFAULT_ADJUSTMENTS });
      setRotation(0);
      setFlipH(false);
      setFlipV(false);
      setHistoryData([]);
      setHistoryIndex(-1);
    };
    img.src = URL.createObjectURL(file);
  }, []);

  const saveToHistory = useCallback(() => {
    if (!canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    const imageData = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
    const newState: HistoryState = { imageData, adjustments: { ...adjustments }, rotation, flipH, flipV };
    setHistoryData(prev => [...prev.slice(0, historyIndex + 1), newState].slice(-20));
    setHistoryIndex(prev => Math.min(prev + 1, 19));
  }, [adjustments, rotation, flipH, flipV, historyIndex]);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void saveToHistory;

  const applyFilter = useCallback((name: string, updates: Partial<Adjustments>) => {
    setActiveFilter(name);
    setAdjustments(prev => ({ ...prev, ...updates }));
  }, []);

  const resetFilters = useCallback(() => {
    setAdjustments({ ...DEFAULT_ADJUSTMENTS });
    setActiveFilter(null);
  }, []);

  const rotate = useCallback((deg: number) => {
    setRotation(prev => prev + deg);
  }, []);

  const downloadImage = useCallback(() => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'edited-image.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  }, []);

  const handleCropStart = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!cropMode || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    setCropStart({ x, y });
    setCropRect({ x, y, w: 0, h: 0 });
    setIsDragging(true);
  }, [cropMode]);

  const handleCropMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging || !cropStart || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const scaleY = canvasRef.current.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    setCropRect({
      x: Math.min(cropStart.x, x),
      y: Math.min(cropStart.y, y),
      w: Math.abs(x - cropStart.x),
      h: Math.abs(y - cropStart.y),
    });
  }, [isDragging, cropStart]);

  const handleCropEnd = useCallback(() => {
    if (!cropRect || !canvasRef.current || !cropMode) {
      setIsDragging(false);
      setCropStart(null);
      return;
    }
    setIsDragging(false);
    /* Apply crop */
    if (cropRect.w > 10 && cropRect.h > 10) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const imageData = ctx.getImageData(cropRect.x, cropRect.y, cropRect.w, cropRect.h);
        canvas.width = cropRect.w;
        canvas.height = cropRect.h;
        ctx.putImageData(imageData, 0, 0);
        /* Convert back to image */
        const img = new Image();
        img.onload = () => setImage(img);
        img.src = canvas.toDataURL();
      }
    }
    setCropMode(false);
    setCropStart(null);
    setCropRect(null);
  }, [cropRect, cropMode]);

  const filters = [
    { name: 'Normal', icon: ImageIcon, updates: {} },
    { name: 'Grayscale', icon: Droplet, updates: { grayscale: 100 } },
    { name: 'Sepia', icon: Sun, updates: { sepia: 100 } },
    { name: 'Blur', icon: Droplet, updates: { blur: 5 } },
    { name: 'Invert', icon: Contrast, updates: { invert: 100 } },
    { name: 'Vintage', icon: Sun, updates: { sepia: 50, contrast: 120, saturation: 80 } },
    { name: 'Noir', icon: Contrast, updates: { grayscale: 100, contrast: 150 } },
    { name: 'Warm', icon: Sun, updates: { sepia: 30, hueRotate: -15, saturation: 120 } },
  ];

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        <label className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#C9A84C] text-[#030305] hover:bg-[#D4B85A] cursor-pointer transition-colors">
          <Upload className="w-3.5 h-3.5" /> Open
          <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileUpload} />
        </label>
        <div className="w-px h-5 bg-[#2A2A3E]" />
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={() => rotate(-90)}>
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={() => rotate(90)}>
          <RotateCw className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={() => setFlipH(!flipH)}>
          <FlipHorizontal className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={() => setFlipV(!flipV)}>
          <FlipVertical className="w-3.5 h-3.5" />
        </button>
        <button
          className={`flex items-center gap-1 px-2 py-1.5 rounded transition-colors ${cropMode ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235]'}`}
          onClick={() => { setCropMode(!cropMode); setCropRect(null); }}
        >
          <Crop className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={resetFilters}>
          <Eraser className="w-3.5 h-3.5" /> Reset
        </button>
        <div className="flex-1" />
        <button className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#5A9E6F] text-white hover:bg-[#6AAF7F] transition-colors" onClick={downloadImage}>
          <Download className="w-3.5 h-3.5" /> Save
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col shrink-0 overflow-y-auto">
          {/* Filter presets */}
          <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider">Filters</div>
          <div className="grid grid-cols-2 gap-1 px-2 pb-2">
            {filters.map(f => (
              <button
                key={f.name}
                className={`flex flex-col items-center gap-1 px-2 py-2 rounded border transition-colors ${
                  activeFilter === f.name ? 'border-[#C9A84C] bg-[#C9A84C]/10' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
                }`}
                onClick={() => { resetFilters(); setTimeout(() => applyFilter(f.name, f.updates), 0); }}
              >
                <f.icon className="w-4 h-4 text-[#8A8578]" />
                <span className="text-[10px]">{f.name}</span>
              </button>
            ))}
          </div>

          {/* Adjustments */}
          <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider border-t border-[#2A2A3E]">Adjustments</div>
          <div className="px-3 pb-3 flex flex-col gap-2.5">
            {([
              { key: 'brightness' as keyof Adjustments, label: 'Brightness', min: 0, max: 200, icon: Sun },
              { key: 'contrast' as keyof Adjustments, label: 'Contrast', min: 0, max: 200, icon: Contrast },
              { key: 'saturation' as keyof Adjustments, label: 'Saturation', min: 0, max: 200, icon: Droplet },
              { key: 'blur' as keyof Adjustments, label: 'Blur', min: 0, max: 20, icon: Droplet, step: 0.5 },
              { key: 'hueRotate' as keyof Adjustments, label: 'Hue', min: -180, max: 180, icon: RotateCw },
            ]).map(({ key, label, min, max, icon: Icon, step = 1 }) => (
              <div key={key}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1 text-[10px] text-[#8A8578]">
                    <Icon className="w-3 h-3" /> {label}
                  </div>
                  <span className="text-[10px] font-mono">{adjustments[key]}</span>
                </div>
                <input
                  type="range"
                  min={min}
                  max={max}
                  step={step}
                  value={adjustments[key]}
                  onChange={e => setAdjustments(prev => ({ ...prev, [key]: parseFloat(e.target.value) }))}
                  className="w-full h-1 bg-[#2A2A3E] rounded-full appearance-none cursor-pointer accent-[#C9A84C]"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Canvas area */}
        <div className="flex-1 flex items-center justify-center bg-[#0A0A0F] overflow-auto p-4">
          {image ? (
            <div className="relative">
              <canvas
                ref={canvasRef}
                className={`max-w-full max-h-full shadow-lg ${cropMode ? 'cursor-crosshair' : 'cursor-default'}`}
                style={{ maxHeight: 'calc(100vh - 200px)' }}
                onMouseDown={handleCropStart}
                onMouseMove={handleCropMove}
                onMouseUp={handleCropEnd}
                onMouseLeave={handleCropEnd}
              />
              {cropMode && cropRect && (
                <div
                  className="absolute border-2 border-dashed border-[#C9A84C] bg-[#C9A84C]/10 pointer-events-none"
                  style={{
                    left: `${(cropRect.x / (canvasRef.current?.width || 1)) * 100}%`,
                    top: `${(cropRect.y / (canvasRef.current?.height || 1)) * 100}%`,
                    width: `${(cropRect.w / (canvasRef.current?.width || 1)) * 100}%`,
                    height: `${(cropRect.h / (canvasRef.current?.height || 1)) * 100}%`,
                  }}
                />
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-[#4D4A42]">
              <ImageIcon className="w-16 h-16 mb-3 opacity-30" />
              <p className="text-sm">Upload an image to start editing</p>
              <p className="text-xs mt-1 opacity-60">PNG, JPEG, WebP supported</p>
              <label className="mt-3 px-4 py-2 rounded bg-[#C9A84C] text-[#030305] cursor-pointer hover:bg-[#D4B85A] transition-colors">
                Select Image
                <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
              </label>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
