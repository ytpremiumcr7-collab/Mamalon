import { useState, useRef, useEffect, useCallback } from 'react';
import { LineChart, Plus, X, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

const COLORS = ['#C9A84C', '#4A9E9E', '#7B6FB8', '#5A9E6F', '#B84A4A', '#D4953A', '#5A8AB8', '#E8E4DC'];

interface GraphFunction {
  id: string;
  expression: string;
  color: string;
  visible: boolean;
}

function parseExpression(expr: string): (x: number) => number {
  const clean = expr
    .replace(/\^/g, '**')
    .replace(/sin\(/g, 'Math.sin(')
    .replace(/cos\(/g, 'Math.cos(')
    .replace(/tan\(/g, 'Math.tan(')
    .replace(/log\(/g, 'Math.log10(')
    .replace(/ln\(/g, 'Math.log(')
    .replace(/sqrt\(/g, 'Math.sqrt(')
    .replace(/abs\(/g, 'Math.abs(')
    .replace(/exp\(/g, 'Math.exp(')
    .replace(/pi/g, 'Math.PI')
    .replace(/e(?![a-z])/g, 'Math.E');
  return (x: number) => {
    try {
      const result = Function('x', `"use strict"; return (${clean})`)(x);
      return typeof result === 'number' && isFinite(result) ? result : NaN;
    } catch {
      return NaN;
    }
  };
}

export default function GraphingCalculator() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [functions, setFunctions] = useState<GraphFunction[]>([
    { id: '1', expression: 'x^2', color: COLORS[0], visible: true },
    { id: '2', expression: 'sin(x)', color: COLORS[1], visible: true },
  ]);
  const [zoom, setZoom] = useState(40);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [tracePos, setTracePos] = useState<{ x: number; y: number } | null>(null);
  const [canvasSize, setCanvasSize] = useState({ w: 0, h: 0 });

  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const update = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setCanvasSize({ w: rect.width, h: rect.height });
      }
    };
    update();
    const ro = new ResizeObserver(update);
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  const toCanvasX = useCallback((x: number) => canvasSize.w / 2 + pan.x + x * zoom, [canvasSize, pan, zoom]);
  const toCanvasY = useCallback((y: number) => canvasSize.h / 2 + pan.y - y * zoom, [canvasSize, pan, zoom]);
  const fromCanvasX = useCallback((cx: number) => (cx - canvasSize.w / 2 - pan.x) / zoom, [canvasSize, pan, zoom]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || canvasSize.w === 0 || canvasSize.h === 0) return;
    canvas.width = canvasSize.w * window.devicePixelRatio;
    canvas.height = canvasSize.h * window.devicePixelRatio;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    // Background
    ctx.fillStyle = '#0A0A0F';
    ctx.fillRect(0, 0, canvasSize.w, canvasSize.h);

    // Grid
    const step = zoom >= 80 ? 0.5 : zoom >= 30 ? 1 : zoom >= 10 ? 2 : 5;
    const xStart = Math.floor(fromCanvasX(0) / step) * step;
    const xEnd = Math.ceil(fromCanvasX(canvasSize.w) / step) * step;

    ctx.strokeStyle = 'rgba(42,42,62,0.4)';
    ctx.lineWidth = 1;
    for (let x = xStart; x <= xEnd; x += step) {
      const cx = toCanvasX(x);
      ctx.beginPath();
      ctx.moveTo(cx, 0);
      ctx.lineTo(cx, canvasSize.h);
      ctx.stroke();
    }

    const fromCanvasY = (cy: number) => -(cy - canvasSize.h / 2 - pan.y) / zoom;
    const yStart = Math.floor(fromCanvasY(canvasSize.h) / step) * step;
    const yEnd = Math.ceil(fromCanvasY(0) / step) * step;
    for (let y = yStart; y <= yEnd; y += step) {
      const cy = toCanvasY(y);
      ctx.beginPath();
      ctx.moveTo(0, cy);
      ctx.lineTo(canvasSize.w, cy);
      ctx.stroke();
    }

    // Axes
    ctx.strokeStyle = 'rgba(138,133,120,0.6)';
    ctx.lineWidth = 1.5;
    const originX = toCanvasX(0);
    const originY = toCanvasY(0);
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(canvasSize.w, originY);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(originX, 0);
    ctx.lineTo(originX, canvasSize.h);
    ctx.stroke();

    // Axis labels
    ctx.fillStyle = 'rgba(138,133,120,0.6)';
    ctx.font = '10px monospace';
    ctx.textAlign = 'center';
    for (let x = xStart; x <= xEnd; x += step) {
      if (Math.abs(x) < 0.001) continue;
      const cx = toCanvasX(x);
      if (cx > 10 && cx < canvasSize.w - 10) {
        ctx.fillText(x.toString(), cx, originY + 14);
      }
    }
    ctx.textAlign = 'right';
    for (let y = yStart; y <= yEnd; y += step) {
      if (Math.abs(y) < 0.001) continue;
      const cy = toCanvasY(y);
      if (cy > 14 && cy < canvasSize.h - 4) {
        ctx.fillText(y.toString(), originX - 6, cy + 4);
      }
    }

    // Functions
    for (const fn of functions) {
      if (!fn.visible) continue;
      const f = parseExpression(fn.expression);
      ctx.strokeStyle = fn.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      let first = true;
      for (let px = 0; px < canvasSize.w; px += 1) {
        const x = fromCanvasX(px);
        const y = f(x);
        if (isNaN(y) || !isFinite(y)) {
          first = true;
          continue;
        }
        const py = toCanvasY(y);
        if (py < -1000 || py > canvasSize.h + 1000) {
          first = true;
          continue;
        }
        if (first) {
          ctx.moveTo(px, py);
          first = false;
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.stroke();
    }

    // Trace
    if (tracePos) {
      const cx = toCanvasX(tracePos.x);
      const cy = toCanvasY(tracePos.y);
      ctx.strokeStyle = 'var(--accent-gold)';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx, 0);
      ctx.lineTo(cx, canvasSize.h);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, cy);
      ctx.lineTo(canvasSize.w, cy);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = 'var(--accent-gold)';
      ctx.beginPath();
      ctx.arc(cx, cy, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }, [functions, zoom, pan, canvasSize, toCanvasX, toCanvasY, fromCanvasX, tracePos]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({ x: pan.x + e.clientX - dragStart.x, y: pan.y + e.clientY - dragStart.y });
      setDragStart({ x: e.clientX, y: e.clientY });
    }
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const x = fromCanvasX(mx);
      // Find closest function y
      let bestY = NaN;
      let bestDist = Infinity;
      for (const fn of functions) {
        if (!fn.visible) continue;
        const f = parseExpression(fn.expression);
        const y = f(x);
        if (!isNaN(y) && isFinite(y)) {
          const cy = toCanvasY(y);
          const dist = Math.abs(cy - my);
          if (dist < bestDist && dist < 30) {
            bestDist = dist;
            bestY = y;
          }
        }
      }
      if (!isNaN(bestY)) {
        setTracePos({ x, y: bestY });
      } else {
        setTracePos(null);
      }
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((z) => Math.max(5, Math.min(200, z * factor)));
  };

  const addFunction = () => {
    const id = Date.now().toString();
    setFunctions((prev) => [...prev, { id, expression: 'x', color: COLORS[prev.length % COLORS.length], visible: true }]);
  };

  const removeFunction = (id: string) => {
    setFunctions((prev) => prev.filter((f) => f.id !== id));
  };

  return (
    <div className="w-full h-full flex flex-col" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <LineChart size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Graphing Calculator</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setZoom((z) => z * 1.2)} className="p-1.5 rounded hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}><ZoomIn size={14} /></button>
          <button onClick={() => setZoom((z) => z / 1.2)} className="p-1.5 rounded hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}><ZoomOut size={14} /></button>
          <button onClick={() => { setZoom(40); setPan({ x: 0, y: 0 }); }} className="p-1.5 rounded hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}><RotateCcw size={14} /></button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Function list */}
        <div className="w-56 flex flex-col gap-1.5 p-2 overflow-y-auto shrink-0" style={{ background: 'var(--surface)', borderRight: '1px solid var(--border-subtle)' }}>
          {functions.map((fn, i) => (
            <div key={fn.id} className="flex items-center gap-1.5 px-2 py-1.5 rounded-md" style={{ background: 'var(--abyss)' }}>
              <div className="w-3 h-3 rounded-full shrink-0" style={{ background: fn.color }} />
              <span className="text-xs font-mono shrink-0" style={{ color: 'var(--text-muted)' }}>f{i + 1}(x)=</span>
              <input
                value={fn.expression}
                onChange={(e) => setFunctions((prev) => prev.map((f) => (f.id === fn.id ? { ...f, expression: e.target.value } : f)))}
                className="flex-1 bg-transparent outline-none text-xs font-mono"
                style={{ color: 'var(--text-primary)' }}
              />
              <button onClick={() => setFunctions((prev) => prev.map((f) => (f.id === fn.id ? { ...f, visible: !f.visible } : f)))} className="text-[10px] shrink-0" style={{ color: fn.visible ? 'var(--accent-gold)' : 'var(--text-muted)' }}>
                {fn.visible ? '●' : '○'}
              </button>
              <button onClick={() => removeFunction(fn.id)} className="shrink-0" style={{ color: 'var(--text-muted)' }}>
                <X size={12} />
              </button>
            </div>
          ))}
          <button onClick={addFunction} className="w-full py-1.5 rounded-md text-[11px] font-medium transition-colors hover:bg-[#222235]" style={{ border: '1px dashed var(--border-subtle)', color: 'var(--text-muted)' }}>
            <Plus size={12} className="inline mr-1" /> Add Function
          </button>

          {tracePos && (
            <div className="mt-2 p-2 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
              <div className="text-[10px] mb-1" style={{ color: 'var(--text-muted)' }}>Trace</div>
              <div className="text-xs font-mono" style={{ color: 'var(--accent-gold)' }}>
                x: {tracePos.x.toFixed(3)}
              </div>
              <div className="text-xs font-mono" style={{ color: 'var(--info)' }}>
                y: {tracePos.y.toFixed(3)}
              </div>
            </div>
          )}
        </div>

        {/* Canvas */}
        <div
          ref={containerRef}
          className="flex-1 relative overflow-hidden cursor-crosshair"
          onMouseDown={(e) => { setIsDragging(true); setDragStart({ x: e.clientX, y: e.clientY }); }}
          onMouseUp={() => setIsDragging(false)}
          onMouseLeave={() => setIsDragging(false)}
          onMouseMove={handleMouseMove}
          onWheel={handleWheel}
        >
          <canvas ref={canvasRef} className="w-full h-full" style={{ imageRendering: 'auto' }} />
        </div>
      </div>
    </div>
  );
}
