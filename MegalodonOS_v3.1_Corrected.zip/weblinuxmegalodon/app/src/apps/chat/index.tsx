import { useState, useRef, useEffect } from 'react';
import {
  MessageCircle,
  Send,
  Search,
  Smile,
  MoreVertical,
  Bot,
  Bell,
  Calendar,
  ArrowLeft,
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'me' | 'them';
  timestamp: string;
}

interface Conversation {
  id: string;
  name: string;
  avatar: React.ReactNode;
  messages: Message[];
  lastActive: string;
  unread: number;
}

const EMOJIS = ['😀', '😂', '❤️', '👍', '🎉', '🔥', '👋', '😊', '🤔', '👏', '✅', '⭐', '🙏', '💯', '😎', '🤖', '💻', '📁', '⚡', '🚀'];

const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: '1', name: 'Cornstone Bot', avatar: <Bot size={18} />, lastActive: '2m ago', unread: 1,
    messages: [
      { id: '1', content: 'Hello! Welcome to Cornstone OS. I\'m your assistant bot. How can I help you today?', sender: 'them', timestamp: '10:00' },
      { id: '2', content: 'What can this OS do?', sender: 'me', timestamp: '10:02' },
      { id: '3', content: 'Cornstone OS features 50+ fully functional applications including a file manager, terminal, code editor, media suite, games, scientific tools, and communication apps. You can also customize your desktop theme, manage windows, and organize your workspace.', sender: 'them', timestamp: '10:02' },
    ],
  },
  {
    id: '2', name: 'System Alerts', avatar: <Bell size={18} />, lastActive: '1h ago', unread: 0,
    messages: [
      { id: '4', content: 'System backup completed successfully.', sender: 'them', timestamp: '09:00' },
      { id: '5', content: 'Storage usage is at 45%. You have plenty of space remaining.', sender: 'them', timestamp: '09:01' },
      { id: '6', content: 'Thanks for the update!', sender: 'me', timestamp: '09:05' },
      { id: '7', content: 'You\'re welcome! I\'ll keep monitoring your system and let you know if anything needs attention.', sender: 'them', timestamp: '09:06' },
    ],
  },
  {
    id: '3', name: 'Calendar Bot', avatar: <Calendar size={18} />, lastActive: '3h ago', unread: 0,
    messages: [
      { id: '8', content: 'You have a meeting scheduled in 30 minutes: "Project Review" in Conference Room A.', sender: 'them', timestamp: '13:30' },
      { id: '9', content: 'Got it, thanks for the reminder!', sender: 'me', timestamp: '13:31' },
      { id: '10', content: 'Would you like me to send you a 5-minute warning as well?', sender: 'them', timestamp: '13:32' },
      { id: '11', content: 'Yes please!', sender: 'me', timestamp: '13:33' },
    ],
  },
];

const BOT_RESPONSES: Record<string, string[]> = {
  '1': [
    'You can press Super+E to open the File Manager, or Super+T for the Terminal.',
    'Try exploring the Start Menu to discover all available applications!',
    'Settings can be accessed from the taskbar or desktop context menu.',
    'The Megalodon CostOS app helps with construction cost estimation.',
    'You can customize your desktop wallpaper in the Settings app.',
  ],
  '2': [
    'New system update available: Version 2.1.0.',
    'No new alerts at this time. Everything is running smoothly.',
    'Memory usage is at 62%. CPU load is normal.',
    'A new security patch will be installed tonight at 3 AM.',
  ],
  '3': [
    'Your next meeting is tomorrow at 10:00 AM.',
    'No other events scheduled for today.',
    'Would you like me to schedule a new event?',
    'Reminder: Team standup every Monday at 9:00 AM.',
  ],
};

export default function Chat() {
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [activeConvId, setActiveConvId] = useState<string>('1');
  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [typingIndicator, setTypingIndicator] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileView, setMobileView] = useState<'list' | 'chat'>('list');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConv = conversations.find((c) => c.id === activeConvId) || conversations[0];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConv.messages, typingIndicator]);

  const sendMessage = () => {
    if (!inputText.trim()) return;
    const newMsg: Message = {
      id: Date.now().toString(),
      content: inputText.trim(),
      sender: 'me',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConvId
          ? { ...c, messages: [...c.messages, newMsg], lastActive: 'just now' }
          : c
      )
    );
    setInputText('');
    setShowEmojiPicker(false);

    // Simulate typing indicator
    setTypingIndicator(true);
    setTimeout(() => {
      setTypingIndicator(false);
      const responses = BOT_RESPONSES[activeConvId] || ['Interesting! Tell me more.'];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        content: randomResponse,
        sender: 'them',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeConvId
            ? { ...c, messages: [...c.messages, botMsg], lastActive: 'just now' }
            : c
        )
      );
    }, 1500 + Math.random() * 1000);
  };

  const addEmoji = (emoji: string) => {
    setInputText((prev) => prev + emoji);
  };

  const filteredConvs = conversations.filter(
    (c) =>
      !searchQuery ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.messages.some((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="w-full h-full flex" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Conversation list */}
      <div
        className={`${mobileView === 'chat' ? 'hidden' : 'flex'} w-full md:w-64 flex-col shrink-0`}
        style={{ background: 'var(--surface)', borderRight: '1px solid var(--border-subtle)' }}
      >
        <div className="flex items-center gap-2 px-3 py-2.5" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
          <MessageCircle size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Messages</span>
        </div>

        <div className="px-3 py-2" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
            <Search size={12} style={{ color: 'var(--text-muted)' }} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contacts..."
              className="bg-transparent outline-none w-full text-xs"
              style={{ color: 'var(--text-primary)' }}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredConvs.map((conv) => (
            <button
              key={conv.id}
              onClick={() => {
                setActiveConvId(conv.id);
                setConversations((prev) =>
                  prev.map((c) => (c.id === conv.id ? { ...c, unread: 0 } : c))
                );
                setMobileView('chat');
              }}
              className="w-full flex items-start gap-2.5 px-3 py-2.5 text-left transition-colors"
              style={{
                background: activeConvId === conv.id ? 'rgba(201,168,76,0.08)' : 'transparent',
              }}
            >
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                style={{ background: 'var(--surface-elevated)' }}
              >
                {conv.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className={`text-xs ${conv.unread > 0 ? 'font-semibold' : ''}`}>{conv.name}</span>
                  <span className="text-[10px] shrink-0 ml-1" style={{ color: 'var(--text-muted)' }}>{conv.lastActive}</span>
                </div>
                <div className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>
                  {conv.messages[conv.messages.length - 1]?.content}
                </div>
              </div>
              {conv.unread > 0 && (
                <span className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
                  {conv.unread}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div className={`${mobileView === 'list' ? 'hidden' : 'flex'} flex-1 flex-col md:flex`}>
        {/* Chat header */}
        <div className="flex items-center gap-2.5 px-3 py-2.5 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
          <button className="md:hidden p-1" onClick={() => setMobileView('list')}>
            <ArrowLeft size={16} />
          </button>
          <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--surface-elevated)' }}>
            {activeConv.avatar}
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium">{activeConv.name}</div>
            <div className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
              {typingIndicator ? 'typing...' : 'Online'}
            </div>
          </div>
          <button className="p-1.5 rounded hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-muted)' }}>
            <MoreVertical size={14} />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2">
          {activeConv.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className="max-w-[75%] px-3 py-2 rounded-lg text-xs leading-relaxed"
                style={{
                  background: msg.sender === 'me' ? 'rgba(201,168,76,0.18)' : 'var(--surface-elevated)',
                  color: 'var(--text-primary)',
                  borderTopRightRadius: msg.sender === 'me' ? '4px' : undefined,
                  borderTopLeftRadius: msg.sender === 'them' ? '4px' : undefined,
                }}
              >
                {msg.content}
                <div
                  className={`text-[9px] mt-1 ${msg.sender === 'me' ? 'text-right' : ''}`}
                  style={{ color: 'var(--text-muted)' }}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}
          {typingIndicator && (
            <div className="flex justify-start">
              <div
                className="px-3 py-2 rounded-lg"
                style={{ background: 'var(--surface-elevated)', borderTopLeftRadius: '4px' }}
              >
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: 'var(--text-muted)', animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: 'var(--text-muted)', animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: 'var(--text-muted)', animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="shrink-0 px-3 py-2.5" style={{ borderTop: '1px solid var(--border-subtle)' }}>
          {showEmojiPicker && (
            <div className="absolute bottom-14 right-4 p-2 rounded-lg grid grid-cols-5 gap-1 z-10" style={{ background: 'var(--surface-elevated)', border: '1px solid var(--border-subtle)' }}>
              {EMOJIS.map((e) => (
                <button
                  key={e}
                  onClick={() => addEmoji(e)}
                  className="w-7 h-7 flex items-center justify-center text-lg rounded hover:bg-[#222235] transition-colors"
                >
                  {e}
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowEmojiPicker((v) => !v)}
              className="p-2 rounded-lg hover:bg-[#222235] transition-colors shrink-0"
              style={{ color: 'var(--text-muted)' }}
            >
              <Smile size={16} />
            </button>
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') sendMessage();
              }}
              placeholder="Type a message..."
              className="flex-1 px-3 py-2 rounded-lg text-xs outline-none"
              style={{ background: 'var(--surface-elevated)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
            />
            <button
              onClick={sendMessage}
              disabled={!inputText.trim()}
              className="p-2 rounded-lg transition-colors disabled:opacity-30"
              style={{ background: inputText.trim() ? 'var(--accent-gold)' : 'var(--surface-hover)', color: inputText.trim() ? 'var(--void)' : 'var(--text-muted)' }}
            >
              <Send size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
