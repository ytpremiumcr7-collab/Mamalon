import { useState, useEffect, useRef, useCallback } from 'react';
import { Activity, Cpu, HardDrive, Wifi, Trash2, Search, XCircle } from 'lucide-react';

type ProcessStatus = 'Running' | 'Sleeping' | 'Zombie';

interface Process {
  pid: number;
  name: string;
  cpu: number;
  mem: number;
  status: ProcessStatus;
  user: string;
}

interface MetricHistory {
  cpu: number[];
  memory: number[];
  disk: number[];
  networkUp: number[];
  networkDown: number[];
}

const INITIAL_PROCESSES: Process[] = [
  { pid: 1, name: 'systemd', cpu: 0.1, mem: 12, status: 'Running', user: 'root' },
  { pid: 124, name: 'cornstone-wm', cpu: 2.3, mem: 156, status: 'Running', user: 'user' },
  { pid: 256, name: 'megalodon-engine', cpu: 8.7, mem: 423, status: 'Running', user: 'user' },
  { pid: 312, name: 'star-map-render', cpu: 12.1, mem: 312, status: 'Running', user: 'user' },
  { pid: 428, name: 'node', cpu: 5.4, mem: 198, status: 'Running', user: 'user' },
  { pid: 512, name: 'chrome', cpu: 15.2, mem: 567, status: 'Running', user: 'user' },
  { pid: 623, name: 'postgres', cpu: 1.8, mem: 89, status: 'Sleeping', user: 'postgres' },
  { pid: 712, name: 'sshd', cpu: 0.2, mem: 8, status: 'Sleeping', user: 'root' },
  { pid: 834, name: 'nginx', cpu: 0.5, mem: 24, status: 'Running', user: 'www' },
  { pid: 945, name: 'redis-server', cpu: 0.8, mem: 32, status: 'Running', user: 'redis' },
  { pid: 1023, name: 'dockerd', cpu: 2.1, mem: 178, status: 'Running', user: 'root' },
  { pid: 1134, name: 'python3', cpu: 6.3, mem: 245, status: 'Running', user: 'user' },
  { pid: 1245, name: 'mysql', cpu: 3.2, mem: 312, status: 'Sleeping', user: 'mysql' },
  { pid: 1356, name: 'mongodb', cpu: 1.5, mem: 156, status: 'Sleeping', user: 'mongodb' },
  { pid: 1467, name: 'elasticsearch', cpu: 4.8, mem: 456, status: 'Running', user: 'user' },
  { pid: 1578, name: 'kafka', cpu: 2.9, mem: 289, status: 'Running', user: 'kafka' },
  { pid: 1689, name: 'grafana', cpu: 1.2, mem: 67, status: 'Sleeping', user: 'grafana' },
  { pid: 1790, name: 'prometheus', cpu: 3.5, mem: 234, status: 'Running', user: 'prometheus' },
  { pid: 1801, name: 'bash', cpu: 0.3, mem: 12, status: 'Running', user: 'user' },
  { pid: 1912, name: 'vim', cpu: 0.6, mem: 18, status: 'Running', user: 'user' },
];

const MAX_HISTORY = 60;

function generateMetric(history: number[], newValue: number): number[] {
  return [...history.slice(-(MAX_HISTORY - 1)), newValue];
}

function SparkLine({ data, color, height = 40 }: { data: number[]; color: string; height?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || data.length < 2) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = canvas.offsetWidth * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, canvas.offsetWidth, height);

    const max = Math.max(...data, 10);
    const stepX = canvas.offsetWidth / (MAX_HISTORY - 1);

    // Fill area
    ctx.beginPath();
    ctx.moveTo(0, height);
    data.forEach((v, i) => {
      const x = i * stepX;
      const y = height - (v / max) * height;
      if (i === 0) ctx.lineTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.lineTo((data.length - 1) * stepX, height);
    ctx.closePath();
    ctx.fillStyle = color + '14';
    ctx.fill();

    // Line
    ctx.beginPath();
    data.forEach((v, i) => {
      const x = i * stepX;
      const y = height - (v / max) * height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.stroke();
  }, [data, color, height]);

  return <canvas ref={canvasRef} className="w-full" style={{ height }} />;
}

export default function SystemMonitor() {
  const [processes, setProcesses] = useState<Process[]>(INITIAL_PROCESSES);
  const [history, setHistory] = useState<MetricHistory>({
    cpu: Array(MAX_HISTORY).fill(15),
    memory: Array(MAX_HISTORY).fill(50),
    disk: Array(MAX_HISTORY).fill(65),
    networkUp: Array(MAX_HISTORY).fill(0.1),
    networkDown: Array(MAX_HISTORY).fill(0.5),
  });
  const [sortBy, setSortBy] = useState<'cpu' | 'mem' | 'pid' | 'name'>('cpu');
  const [sortDesc, setSortDesc] = useState(true);
  const [search, setSearch] = useState('');
  const [uptime, setUptime] = useState(0);
  const [activeTab, setActiveTab] = useState<'performance' | 'processes'>('performance');

  // Uptime counter
  useEffect(() => {
    const interval = setInterval(() => setUptime(u => u + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  // Update metrics every 2 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setHistory(prev => {
        const newCpu = Math.max(5, Math.min(80, prev.cpu[prev.cpu.length - 1] + (Math.random() - 0.5) * 20));
        const newMem = Math.max(35, Math.min(75, prev.memory[prev.memory.length - 1] + (Math.random() - 0.5) * 8));
        const newDisk = Math.max(60, Math.min(70, prev.disk[prev.disk.length - 1] + (Math.random() - 0.5) * 2));
        const newNetUp = Math.max(0, Math.random() * 3);
        const newNetDown = Math.max(0, Math.random() * 8);
        return {
          cpu: generateMetric(prev.cpu, newCpu),
          memory: generateMetric(prev.memory, newMem),
          disk: generateMetric(prev.disk, newDisk),
          networkUp: generateMetric(prev.networkUp, newNetUp),
          networkDown: generateMetric(prev.networkDown, newNetDown),
        };
      });

      setProcesses(prev => prev.map(p => ({
        ...p,
        cpu: Math.max(0.1, p.cpu + (Math.random() - 0.5) * 3),
        mem: Math.max(5, p.mem + (Math.random() - 0.5) * 10),
      })));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleSort = useCallback((col: 'cpu' | 'mem' | 'pid' | 'name') => {
    setSortBy(prev => {
      if (prev === col) { setSortDesc(d => !d); return prev; }
      setSortDesc(true);
      return col;
    });
  }, []);

  const handleKill = useCallback((pid: number) => {
    setProcesses(prev => prev.filter(p => p.pid !== pid));
  }, []);

  const filteredProcesses = processes
    .filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()) || String(p.pid).includes(search))
    .sort((a, b) => {
      const valA = a[sortBy];
      const valB = b[sortBy];
      const cmp = typeof valA === 'string' ? valA.localeCompare(valB as string) : (valA as number) - (valB as number);
      return sortDesc ? -cmp : cmp;
    });

  const currentCpu = history.cpu[history.cpu.length - 1];
  const currentMem = history.memory[history.memory.length - 1];
  const currentDisk = history.disk[history.disk.length - 1];
  const totalMem = 16384;
  const usedMem = Math.round((currentMem / 100) * totalMem);

  const formatUptime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h}h ${m}m ${sec}s`;
  };

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col overflow-hidden">
      {/* Tabs */}
      <div className="flex items-center gap-1 px-3 py-2 border-b border-[#2A2A3E] shrink-0">
        <button
          onClick={() => setActiveTab('performance')}
          className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${activeTab === 'performance' ? 'bg-[#222235] text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
        >
          <span className="flex items-center gap-1.5"><Activity className="w-3.5 h-3.5" /> Performance</span>
        </button>
        <button
          onClick={() => setActiveTab('processes')}
          className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${activeTab === 'processes' ? 'bg-[#222235] text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
        >
          <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5" /> Processes ({processes.length})</span>
        </button>
        <div className="ml-auto text-[10px] text-[#4D4A42] font-mono">Uptime: {formatUptime(uptime)}</div>
      </div>

      {activeTab === 'performance' ? (
        <div className="flex-1 overflow-auto p-4 space-y-4">
          {/* Metric cards */}
          <div className="grid grid-cols-2 gap-3">
            {/* CPU */}
            <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-[#4A9E9E]" />
                  <span className="text-xs text-[#8A8578]">CPU</span>
                </div>
                <span className="text-xs font-mono text-[#4A9E9E]">{currentCpu.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-[#0A0A0F] rounded-full h-2 mb-2">
                <div className="h-2 rounded-full transition-all duration-1000" style={{ width: `${currentCpu}%`, backgroundColor: '#4A9E9E' }} />
              </div>
              <SparkLine data={history.cpu} color="#4A9E9E" />
              {/* CPU cores */}
              <div className="flex gap-1 mt-2">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(c => (
                  <div key={c} className="flex-1 bg-[#0A0A0F] rounded-full h-1">
                    <div className="h-1 rounded-full transition-all duration-1000" style={{ width: `${Math.random() * 100}%`, backgroundColor: '#4A9E9E' }} />
                  </div>
                ))}
              </div>
            </div>

            {/* Memory */}
            <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-[#C9A84C]" />
                  <span className="text-xs text-[#8A8578]">Memory</span>
                </div>
                <span className="text-xs font-mono text-[#C9A84C]">{(usedMem / 1024).toFixed(1)} GB / {(totalMem / 1024).toFixed(1)} GB</span>
              </div>
              <div className="w-full bg-[#0A0A0F] rounded-full h-2 mb-2">
                <div className="h-2 rounded-full transition-all duration-1000" style={{ width: `${currentMem}%`, backgroundColor: '#C9A84C' }} />
              </div>
              <SparkLine data={history.memory} color="#C9A84C" />
            </div>

            {/* Disk */}
            <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-[#5A9E6F]" />
                  <span className="text-xs text-[#8A8578]">Disk</span>
                </div>
                <span className="text-xs font-mono text-[#5A9E6F]">{currentDisk.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-[#0A0A0F] rounded-full h-2 mb-2">
                <div className="h-2 rounded-full transition-all duration-1000" style={{ width: `${currentDisk}%`, backgroundColor: '#5A9E6F' }} />
              </div>
              <SparkLine data={history.disk} color="#5A9E6F" />
            </div>

            {/* Network */}
            <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Wifi className="w-3.5 h-3.5 text-[#7B6FB8]" />
                  <span className="text-xs text-[#8A8578]">Network</span>
                </div>
                <span className="text-xs font-mono text-[#7B6FB8]">{(history.networkDown[history.networkDown.length - 1]).toFixed(1)} MB/s</span>
              </div>
              <div className="flex gap-2 mb-2">
                <div className="flex items-center gap-1">
                  <span className="text-[8px] text-[#4A9E9E]">▲</span>
                  <span className="text-[10px] font-mono text-[#8A8578]">{history.networkUp[history.networkUp.length - 1].toFixed(1)} MB/s</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-[8px] text-[#C9A84C]">▼</span>
                  <span className="text-[10px] font-mono text-[#8A8578]">{history.networkDown[history.networkDown.length - 1].toFixed(1)} MB/s</span>
                </div>
              </div>
              <canvas className="w-full" style={{ height: 40 }} ref={(c) => {
                if (!c) return;
                const ctx = c.getContext('2d');
                if (!ctx) return;
                const dpr = window.devicePixelRatio || 1;
                c.width = c.offsetWidth * dpr;
                c.height = 40 * dpr;
                ctx.scale(dpr, dpr);
                ctx.clearRect(0, 0, c.offsetWidth, 40);
                const stepX = c.offsetWidth / (MAX_HISTORY - 1);
                const maxVal = Math.max(...history.networkDown, ...history.networkUp, 5);
                // Upload line
                ctx.beginPath();
                history.networkUp.forEach((v, i) => {
                  const x = i * stepX;
                  const y = 40 - (v / maxVal) * 40;
                  if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                });
                ctx.strokeStyle = '#4A9E9E';
                ctx.lineWidth = 1.5;
                ctx.stroke();
                // Download line
                ctx.beginPath();
                history.networkDown.forEach((v, i) => {
                  const x = i * stepX;
                  const y = 40 - (v / maxVal) * 40;
                  if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                });
                ctx.strokeStyle = '#C9A84C';
                ctx.lineWidth = 1.5;
                ctx.stroke();
              }} />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* Search bar */}
          <div className="px-3 py-2 border-b border-[#2A2A3E] flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-[#4D4A42]" />
            <input
              type="text"
              placeholder="Search processes..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="flex-1 bg-transparent text-xs text-[#E8E4DC] outline-none placeholder-[#4D4A42]"
            />
            {search && (
              <button onClick={() => setSearch('')} className="text-[#4D4A42] hover:text-[#8A8578]">
                <XCircle className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Process table */}
          <div className="flex-1 overflow-auto">
            <table className="w-full text-xs">
              <thead className="sticky top-0 z-10">
                <tr className="bg-[#1A1A26] text-[#8A8578] border-b border-[#2A2A3E]">
                  <th className="text-left p-2 font-medium cursor-pointer hover:text-[#E8E4DC]" onClick={() => handleSort('pid')}>
                    PID {sortBy === 'pid' && (sortDesc ? '↓' : '↑')}
                  </th>
                  <th className="text-left p-2 font-medium cursor-pointer hover:text-[#E8E4DC]" onClick={() => handleSort('name')}>
                    Name {sortBy === 'name' && (sortDesc ? '↓' : '↑')}
                  </th>
                  <th className="text-right p-2 font-medium cursor-pointer hover:text-[#E8E4DC]" onClick={() => handleSort('cpu')}>
                    CPU% {sortBy === 'cpu' && (sortDesc ? '↓' : '↑')}
                  </th>
                  <th className="text-right p-2 font-medium cursor-pointer hover:text-[#E8E4DC]" onClick={() => handleSort('mem')}>
                    Mem (MB) {sortBy === 'mem' && (sortDesc ? '↓' : '↑')}
                  </th>
                  <th className="text-left p-2 font-medium">Status</th>
                  <th className="text-left p-2 font-medium">User</th>
                  <th className="text-right p-2 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProcesses.map(p => (
                  <tr key={p.pid} className="border-t border-[#2A2A3E]/50 hover:bg-[#222235]/50 transition-colors">
                    <td className="p-2 font-mono text-[#8A8578]">{p.pid}</td>
                    <td className="p-2 text-[#E8E4DC] font-medium">{p.name}</td>
                    <td className="p-2 text-right font-mono text-[#C9A84C]">{p.cpu.toFixed(1)}</td>
                    <td className="p-2 text-right font-mono text-[#5A8AB8]">{Math.round(p.mem)}</td>
                    <td className="p-2">
                      <span className={`inline-flex items-center gap-1 text-[10px] ${
                        p.status === 'Running' ? 'text-[#5A9E6F]' : p.status === 'Sleeping' ? 'text-[#8A8578]' : 'text-[#D4953A]'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          p.status === 'Running' ? 'bg-[#5A9E6F]' : p.status === 'Sleeping' ? 'bg-[#8A8578]' : 'bg-[#D4953A]'
                        }`} />
                        {p.status}
                      </span>
                    </td>
                    <td className="p-2 text-[#8A8578]">{p.user}</td>
                    <td className="p-2 text-right">
                      <button
                        onClick={() => handleKill(p.pid)}
                        className="text-[#B84A4A]/60 hover:text-[#B84A4A] transition-colors p-1"
                        title="End task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredProcesses.length === 0 && (
                  <tr><td colSpan={7} className="p-4 text-center text-[#4D4A42]">No processes found</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
