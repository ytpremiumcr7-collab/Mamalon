import { useState, useMemo } from 'react';
import {
  Mail,
  Inbox,
  Send,
  FileText,
  Trash2,
  AlertTriangle,
  Star,
  Search,
  PenSquare,
  Reply,
  Forward,
  Archive,
  X,
} from 'lucide-react';

type FolderId = 'inbox' | 'sent' | 'drafts' | 'trash' | 'spam';

interface Email {
  id: string;
  subject: string;
  from: string;
  fromName: string;
  to: string;
  date: string;
  body: string;
  folder: FolderId;
  read: boolean;
  starred: boolean;
}

const DEMO_EMAILS: Email[] = [
  {
    id: '1', subject: 'Welcome to Cornstone OS', from: 'admin@cornstone.local', fromName: 'Admin',
    to: 'user@cornstone.local', date: '2026-01-12T09:00:00', read: false, starred: true, folder: 'inbox',
    body: 'Welcome to your new operating system! Cornstone OS is designed to be a premium, fully functional web-based desktop environment. Explore the 50+ applications, customize your desktop, and enjoy the seamless experience.\n\nIf you need any help, check out the Help app or ask in the Chat.',
  },
  {
    id: '2', subject: 'System Update Available', from: 'system@cornstone.local', fromName: 'System',
    to: 'user@cornstone.local', date: '2026-01-11T14:30:00', read: false, starred: false, folder: 'inbox',
    body: 'A new version of Cornstone OS is available for download. Version 2.1.0 includes performance improvements, new applications, and security patches.\n\nClick here to install the update now, or go to Settings > System to schedule it for later.',
  },
  {
    id: '3', subject: 'Your Daily Digest', from: 'digest@cornstone.local', fromName: 'Daily Digest',
    to: 'user@cornstone.local', date: '2026-01-10T08:00:00', read: true, starred: false, folder: 'inbox',
    body: 'Here is your personalized digest for today:\n\n- 3 new emails received\n- 1 system notification\n- 2 upcoming meetings\n- Storage usage: 45%\n\nHave a productive day!',
  },
  {
    id: '4', subject: 'Meeting: Project Review', from: 'calendar@cornstone.local', fromName: 'Calendar',
    to: 'user@cornstone.local', date: '2026-01-09T10:15:00', read: true, starred: true, folder: 'inbox',
    body: 'You have a meeting scheduled:\n\nTitle: Project Review\nDate: January 15, 2026\nTime: 14:00 - 15:30\nLocation: Conference Room A\n\nAttendees:\n- John Smith\n- Jane Doe\n- Bob Johnson',
  },
  {
    id: '5', subject: 'Security Alert', from: 'security@cornstone.local', fromName: 'Security',
    to: 'user@cornstone.local', date: '2026-01-08T22:00:00', read: false, starred: false, folder: 'inbox',
    body: 'Unusual login activity was detected on your account from IP 192.168.1.45. If this was you, you can ignore this message.\n\nIf not, please change your password immediately in Settings > Security.',
  },
  {
    id: '6', subject: 'New Feature: Star-Map', from: 'features@cornstone.local', fromName: 'Feature Team',
    to: 'user@cornstone.local', date: '2026-01-07T11:00:00', read: true, starred: false, folder: 'inbox',
    body: 'The 3D Citation Star-Map is now available! Explore the interactive visualization of neuroscience citations in a stunning 3D space environment.\n\nAccess it from the desktop or press Super+S.',
  },
  {
    id: '7', subject: 'Storage Usage Report', from: 'system@cornstone.local', fromName: 'System',
    to: 'user@cornstone.local', date: '2026-01-06T06:00:00', read: true, starred: false, folder: 'inbox',
    body: 'You are using 45% of your storage quota (45 GB of 100 GB).\n\nBreakdown:\n- Documents: 15 GB\n- Media: 20 GB\n- Applications: 8 GB\n- System: 2 GB',
  },
  {
    id: '8', subject: 'Welcome to Megalodon CostOS', from: 'megalodon@cornstone.local', fromName: 'Megalodon Team',
    to: 'user@cornstone.local', date: '2026-01-05T13:00:00', read: false, starred: true, folder: 'inbox',
    body: 'Get started with cost estimation using Megalodon CostOS. Create your first project, add building elements, and generate accurate cost estimates.\n\nWatch our tutorial video or read the documentation to learn more.',
  },
  {
    id: '9', subject: 'Weekly Newsletter', from: 'newsletter@cornstone.local', fromName: 'Newsletter',
    to: 'user@cornstone.local', date: '2026-01-04T07:00:00', read: true, starred: false, folder: 'inbox',
    body: 'This week in Cornstone development:\n\n- New calculator suite with graphing\n- Improved file manager performance\n- Dark theme refinements\n- Bug fixes and stability improvements',
  },
  {
    id: '10', subject: 'Password Changed', from: 'security@cornstone.local', fromName: 'Security',
    to: 'user@cornstone.local', date: '2026-01-03T16:20:00', read: true, starred: false, folder: 'inbox',
    body: 'Your password was successfully changed on January 3, 2026 at 16:20 UTC.\n\nIf you did not make this change, contact support immediately.',
  },
  {
    id: '11', subject: 'Account Verification', from: 'noreply@cornstone.local', fromName: 'Cornstone',
    to: 'user@cornstone.local', date: '2026-01-02T10:00:00', read: true, starred: false, folder: 'spam',
    body: 'Please verify your email address by clicking the link below.\n\nThis helps us keep your account secure.',
  },
  {
    id: '12', subject: 'Backup Complete', from: 'system@cornstone.local', fromName: 'System',
    to: 'user@cornstone.local', date: '2026-01-01T03:00:00', read: true, starred: false, folder: 'inbox',
    body: 'Your system backup completed successfully at 03:00 UTC.\n\nBackup size: 12.4 GB\nDuration: 45 minutes\nFiles backed up: 15,234',
  },
];

const FOLDERS: { id: FolderId; label: string; icon: React.ReactNode }[] = [
  { id: 'inbox', label: 'Inbox', icon: <Inbox size={16} /> },
  { id: 'sent', label: 'Sent', icon: <Send size={16} /> },
  { id: 'drafts', label: 'Drafts', icon: <FileText size={16} /> },
  { id: 'spam', label: 'Spam', icon: <AlertTriangle size={16} /> },
  { id: 'trash', label: 'Trash', icon: <Trash2 size={16} /> },
];

export default function EmailClient() {
  const [emails, setEmails] = useState<Email[]>(DEMO_EMAILS);
  const [activeFolder, setActiveFolder] = useState<FolderId>('inbox');
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCompose, setShowCompose] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [replyMode, setReplyMode] = useState(false);
  const [replyBody, setReplyBody] = useState('');

  const folderEmails = useMemo(() => {
    return emails
      .filter((e) => e.folder === activeFolder)
      .filter(
        (e) =>
          !searchQuery ||
          e.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
          e.body.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [emails, activeFolder, searchQuery]);

  const selectedEmail = emails.find((e) => e.id === selectedEmailId);

  const folderCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    FOLDERS.forEach((f) => {
      counts[f.id] = emails.filter((e) => e.folder === f.id && !e.read).length;
    });
    return counts;
  }, [emails]);

  const markRead = (id: string, read: boolean) => {
    setEmails((prev) => prev.map((e) => (e.id === id ? { ...e, read } : e)));
  };

  const toggleStar = (id: string) => {
    setEmails((prev) => prev.map((e) => (e.id === id ? { ...e, starred: !e.starred } : e)));
  };

  const moveToFolder = (id: string, folder: FolderId) => {
    setEmails((prev) => prev.map((e) => (e.id === id ? { ...e, folder } : e)));
    if (selectedEmailId === id) setSelectedEmailId(null);
  };

  const sendEmail = () => {
    if (!composeTo || !composeSubject) return;
    const newEmail: Email = {
      id: Date.now().toString(),
      subject: composeSubject,
      from: 'user@cornstone.local',
      fromName: 'Me',
      to: composeTo,
      date: new Date().toISOString(),
      body: composeBody,
      folder: 'sent',
      read: true,
      starred: false,
    };
    setEmails((prev) => [...prev, newEmail]);
    setShowCompose(false);
    setComposeTo('');
    setComposeSubject('');
    setComposeBody('');
  };

  const sendReply = () => {
    if (!selectedEmail || !replyBody.trim()) return;
    const newEmail: Email = {
      id: Date.now().toString(),
      subject: `Re: ${selectedEmail.subject}`,
      from: 'user@cornstone.local',
      fromName: 'Me',
      to: selectedEmail.from,
      date: new Date().toISOString(),
      body: `On ${new Date(selectedEmail.date).toLocaleDateString()}, ${selectedEmail.fromName} wrote:\n\n${selectedEmail.body}\n\n---\n\n${replyBody}`,
      folder: 'sent',
      read: true,
      starred: false,
    };
    setEmails((prev) => [...prev, newEmail]);
    setReplyMode(false);
    setReplyBody('');
  };

  const formatDate = (d: string) => {
    const date = new Date(d);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="w-full h-full flex flex-col" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-3 py-2" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Mail size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Mail</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
            <Search size={12} style={{ color: 'var(--text-muted)' }} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search emails..."
              className="bg-transparent outline-none w-40"
              style={{ color: 'var(--text-primary)' }}
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')}><X size={12} /></button>
            )}
          </div>
          <button
            onClick={() => setShowCompose(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
            style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
          >
            <PenSquare size={12} />
            Compose
          </button>
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Folder sidebar */}
        <div className="w-44 flex flex-col py-2 overflow-y-auto shrink-0" style={{ background: 'var(--surface)', borderRight: '1px solid var(--border-subtle)' }}>
          {FOLDERS.map((folder) => (
            <button
              key={folder.id}
              onClick={() => { setActiveFolder(folder.id); setSelectedEmailId(null); }}
              className="flex items-center justify-between px-3 py-2 mx-2 rounded-md text-sm transition-colors"
              style={{
                background: activeFolder === folder.id ? 'rgba(201,168,76,0.12)' : 'transparent',
                color: activeFolder === folder.id ? 'var(--accent-gold)' : 'var(--text-secondary)',
              }}
            >
              <span className="flex items-center gap-2">
                {folder.icon}
                {folder.label}
              </span>
              {folderCounts[folder.id] > 0 && (
                <span className="text-xs font-medium px-1.5 py-0.5 rounded-full" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
                  {folderCounts[folder.id]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Email list */}
        <div className="w-72 flex flex-col shrink-0 overflow-hidden" style={{ background: 'var(--abyss)', borderRight: '1px solid var(--border-subtle)' }}>
          <div className="px-3 py-2 text-xs font-medium" style={{ color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)' }}>
            {FOLDERS.find((f) => f.id === activeFolder)?.label} ({folderEmails.length})
          </div>
          <div className="flex-1 overflow-y-auto">
            {folderEmails.map((email) => (
              <button
                key={email.id}
                onClick={() => {
                  setSelectedEmailId(email.id);
                  if (!email.read) markRead(email.id, true);
                  setReplyMode(false);
                }}
                className="w-full flex flex-col gap-1 px-3 py-2.5 text-left transition-colors border-b"
                style={{
                  background: selectedEmailId === email.id ? 'rgba(201,168,76,0.08)' : 'transparent',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs truncate flex-1 ${!email.read ? 'font-semibold' : ''}`} style={{ color: 'var(--text-primary)' }}>
                    {!email.read && <span className="inline-block w-1.5 h-1.5 rounded-full mr-1.5" style={{ background: 'var(--accent-gold)' }} />}
                    {email.fromName}
                  </span>
                  <span className="text-[10px] shrink-0 ml-2" style={{ color: 'var(--text-muted)' }}>{formatDate(email.date)}</span>
                </div>
                <div className={`text-xs truncate ${!email.read ? 'font-medium' : ''}`} style={{ color: !email.read ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                  {email.subject}
                </div>
                <div className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>{email.body.slice(0, 60)}...</div>
              </button>
            ))}
            {folderEmails.length === 0 && (
              <div className="flex flex-col items-center justify-center h-40 gap-2" style={{ color: 'var(--text-muted)' }}>
                <Mail size={24} className="opacity-40" />
                <span className="text-xs">No emails</span>
              </div>
            )}
          </div>
        </div>

        {/* Reading pane */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {selectedEmail ? (
            <>
              <div className="flex items-center justify-between px-4 py-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <div className="flex items-center gap-2">
                  <button onClick={() => toggleStar(selectedEmail.id)} className="transition-transform active:scale-90">
                    <Star size={16} fill={selectedEmail.starred ? 'var(--accent-gold)' : 'none'} style={{ color: selectedEmail.starred ? 'var(--accent-gold)' : 'var(--text-muted)' }} />
                  </button>
                  <button onClick={() => { setReplyMode(true); setReplyBody(''); }} className="flex items-center gap-1 px-2 py-1 rounded text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-secondary)' }}>
                    <Reply size={12} /> Reply
                  </button>
                  <button onClick={() => setShowCompose(true)} className="flex items-center gap-1 px-2 py-1 rounded text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-secondary)' }}>
                    <Forward size={12} /> Forward
                  </button>
                  {activeFolder !== 'trash' && (
                    <button onClick={() => moveToFolder(selectedEmail.id, 'trash')} className="flex items-center gap-1 px-2 py-1 rounded text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--danger)' }}>
                      <Trash2 size={12} /> Delete
                    </button>
                  )}
                  {activeFolder === 'trash' && (
                    <button onClick={() => moveToFolder(selectedEmail.id, 'inbox')} className="flex items-center gap-1 px-2 py-1 rounded text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--success)' }}>
                      <Archive size={12} /> Restore
                    </button>
                  )}
                </div>
              </div>
              <div className="px-4 py-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <h2 className="text-base font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{selectedEmail.subject}</h2>
                <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium shrink-0" style={{ background: 'var(--surface-elevated)' }}>
                    {selectedEmail.fromName[0]}
                  </div>
                  <div>
                    <div><strong style={{ color: 'var(--text-primary)' }}>{selectedEmail.fromName}</strong> &lt;{selectedEmail.from}&gt;</div>
                    <div>To: {selectedEmail.to}</div>
                  </div>
                  <span className="ml-auto">{new Date(selectedEmail.date).toLocaleString()}</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto px-4 py-4 text-sm leading-relaxed whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
                {selectedEmail.body}
              </div>

              {/* Reply area */}
              {replyMode && (
                <div className="shrink-0 p-3" style={{ borderTop: '1px solid var(--border-subtle)', background: 'var(--surface)' }}>
                  <div className="text-xs mb-2" style={{ color: 'var(--text-muted)' }}>Reply to {selectedEmail.fromName}</div>
                  <textarea
                    value={replyBody}
                    onChange={(e) => setReplyBody(e.target.value)}
                    placeholder="Write your reply..."
                    className="w-full h-20 px-3 py-2 rounded-md text-xs outline-none resize-none mb-2 font-mono"
                    style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
                  />
                  <div className="flex items-center gap-2">
                    <button
                      onClick={sendReply}
                      className="px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
                      style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
                    >
                      Send Reply
                    </button>
                    <button onClick={() => setReplyMode(false)} className="px-3 py-1.5 rounded-md text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-secondary)' }}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center gap-3" style={{ color: 'var(--text-muted)' }}>
              <Mail size={40} className="opacity-30" />
              <span className="text-sm">Select an email to read</span>
            </div>
          )}
        </div>
      </div>

      {/* Compose modal */}
      {showCompose && (
        <div className="absolute inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(3,3,5,0.6)', backdropFilter: 'blur(8px)' }}>
          <div className="w-[500px] max-h-[80vh] flex flex-col rounded-xl overflow-hidden" style={{ background: 'var(--surface-elevated)', boxShadow: 'var(--shadow-window-active)' }}>
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              <span className="text-sm font-semibold">New Message</span>
              <button onClick={() => setShowCompose(false)} className="p-1 rounded hover:bg-[#222235]">
                <X size={16} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              <div>
                <label className="text-xs block mb-1" style={{ color: 'var(--text-muted)' }}>To</label>
                <input
                  type="text"
                  value={composeTo}
                  onChange={(e) => setComposeTo(e.target.value)}
                  placeholder="recipient@example.com"
                  className="w-full px-3 py-2 rounded-md text-xs outline-none font-mono"
                  style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
                />
              </div>
              <div>
                <label className="text-xs block mb-1" style={{ color: 'var(--text-muted)' }}>Subject</label>
                <input
                  type="text"
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  placeholder="Subject"
                  className="w-full px-3 py-2 rounded-md text-xs outline-none"
                  style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
                />
              </div>
              <div className="flex-1">
                <label className="text-xs block mb-1" style={{ color: 'var(--text-muted)' }}>Body</label>
                <textarea
                  value={composeBody}
                  onChange={(e) => setComposeBody(e.target.value)}
                  placeholder="Write your message..."
                  className="w-full h-40 px-3 py-2 rounded-md text-xs outline-none resize-none font-mono"
                  style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 px-4 py-3" style={{ borderTop: '1px solid var(--border-subtle)' }}>
              <button onClick={() => setShowCompose(false)} className="px-3 py-1.5 rounded-md text-xs hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-secondary)' }}>
                Cancel
              </button>
              <button
                onClick={sendEmail}
                className="px-4 py-1.5 rounded-md text-xs font-medium transition-colors"
                style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
              >
                Send
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
