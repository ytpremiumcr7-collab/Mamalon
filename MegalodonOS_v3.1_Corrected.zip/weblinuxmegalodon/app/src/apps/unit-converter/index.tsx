import { useState, useMemo, useCallback } from 'react';
import { ArrowLeftRight, Clock, RotateCcw } from 'lucide-react';

interface Category {
  name: string;
  units: { name: string; symbol: string; toBase: (v: number) => number; fromBase: (v: number) => number }[];
}

const CATEGORIES: Category[] = [
  {
    name: 'Length',
    units: [
      { name: 'Meter', symbol: 'm', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Kilometer', symbol: 'km', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      { name: 'Centimeter', symbol: 'cm', toBase: (v) => v / 100, fromBase: (v) => v * 100 },
      { name: 'Millimeter', symbol: 'mm', toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      { name: 'Mile', symbol: 'mi', toBase: (v) => v * 1609.344, fromBase: (v) => v / 1609.344 },
      { name: 'Foot', symbol: 'ft', toBase: (v) => v * 0.3048, fromBase: (v) => v / 0.3048 },
      { name: 'Inch', symbol: 'in', toBase: (v) => v * 0.0254, fromBase: (v) => v / 0.0254 },
      { name: 'Yard', symbol: 'yd', toBase: (v) => v * 0.9144, fromBase: (v) => v / 0.9144 },
    ],
  },
  {
    name: 'Weight',
    units: [
      { name: 'Kilogram', symbol: 'kg', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Gram', symbol: 'g', toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      { name: 'Pound', symbol: 'lb', toBase: (v) => v * 0.453592, fromBase: (v) => v / 0.453592 },
      { name: 'Ounce', symbol: 'oz', toBase: (v) => v * 0.0283495, fromBase: (v) => v / 0.0283495 },
      { name: 'Ton', symbol: 't', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      { name: 'Stone', symbol: 'st', toBase: (v) => v * 6.35029, fromBase: (v) => v / 6.35029 },
    ],
  },
  {
    name: 'Temperature',
    units: [
      { name: 'Celsius', symbol: '°C', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Fahrenheit', symbol: '°F', toBase: (v) => (v - 32) * 5 / 9, fromBase: (v) => v * 9 / 5 + 32 },
      { name: 'Kelvin', symbol: 'K', toBase: (v) => v - 273.15, fromBase: (v) => v + 273.15 },
    ],
  },
  {
    name: 'Volume',
    units: [
      { name: 'Liter', symbol: 'L', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Milliliter', symbol: 'mL', toBase: (v) => v / 1000, fromBase: (v) => v * 1000 },
      { name: 'Gallon (US)', symbol: 'gal', toBase: (v) => v * 3.78541, fromBase: (v) => v / 3.78541 },
      { name: 'Quart', symbol: 'qt', toBase: (v) => v * 0.946353, fromBase: (v) => v / 0.946353 },
      { name: 'Cup', symbol: 'cup', toBase: (v) => v * 0.236588, fromBase: (v) => v / 0.236588 },
      { name: 'Fluid Ounce', symbol: 'fl oz', toBase: (v) => v * 0.0295735, fromBase: (v) => v / 0.0295735 },
    ],
  },
  {
    name: 'Area',
    units: [
      { name: 'Square Meter', symbol: 'm²', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Square Foot', symbol: 'ft²', toBase: (v) => v * 0.092903, fromBase: (v) => v / 0.092903 },
      { name: 'Acre', symbol: 'ac', toBase: (v) => v * 4046.86, fromBase: (v) => v / 4046.86 },
      { name: 'Hectare', symbol: 'ha', toBase: (v) => v * 10000, fromBase: (v) => v / 10000 },
    ],
  },
  {
    name: 'Speed',
    units: [
      { name: 'm/s', symbol: 'm/s', toBase: (v) => v, fromBase: (v) => v },
      { name: 'km/h', symbol: 'km/h', toBase: (v) => v / 3.6, fromBase: (v) => v * 3.6 },
      { name: 'mph', symbol: 'mph', toBase: (v) => v * 0.44704, fromBase: (v) => v / 0.44704 },
      { name: 'Knot', symbol: 'kn', toBase: (v) => v * 0.514444, fromBase: (v) => v / 0.514444 },
    ],
  },
  {
    name: 'Time',
    units: [
      { name: 'Second', symbol: 's', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Minute', symbol: 'min', toBase: (v) => v * 60, fromBase: (v) => v / 60 },
      { name: 'Hour', symbol: 'h', toBase: (v) => v * 3600, fromBase: (v) => v / 3600 },
      { name: 'Day', symbol: 'd', toBase: (v) => v * 86400, fromBase: (v) => v / 86400 },
      { name: 'Week', symbol: 'wk', toBase: (v) => v * 604800, fromBase: (v) => v / 604800 },
    ],
  },
  {
    name: 'Data',
    units: [
      { name: 'Byte', symbol: 'B', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Kilobyte', symbol: 'KB', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      { name: 'Megabyte', symbol: 'MB', toBase: (v) => v * 1000000, fromBase: (v) => v / 1000000 },
      { name: 'Gigabyte', symbol: 'GB', toBase: (v) => v * 1e9, fromBase: (v) => v / 1e9 },
      { name: 'Terabyte', symbol: 'TB', toBase: (v) => v * 1e12, fromBase: (v) => v / 1e12 },
      { name: 'Petabyte', symbol: 'PB', toBase: (v) => v * 1e15, fromBase: (v) => v / 1e15 },
      { name: 'Bit', symbol: 'b', toBase: (v) => v / 8, fromBase: (v) => v * 8 },
    ],
  },
  {
    name: 'Pressure',
    units: [
      { name: 'Pascal', symbol: 'Pa', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Bar', symbol: 'bar', toBase: (v) => v * 100000, fromBase: (v) => v / 100000 },
      { name: 'PSI', symbol: 'psi', toBase: (v) => v * 6894.76, fromBase: (v) => v / 6894.76 },
      { name: 'Atmosphere', symbol: 'atm', toBase: (v) => v * 101325, fromBase: (v) => v / 101325 },
      { name: 'Torr', symbol: 'Torr', toBase: (v) => v * 133.322, fromBase: (v) => v / 133.322 },
    ],
  },
  {
    name: 'Energy',
    units: [
      { name: 'Joule', symbol: 'J', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Calorie', symbol: 'cal', toBase: (v) => v * 4.184, fromBase: (v) => v / 4.184 },
      { name: 'BTU', symbol: 'BTU', toBase: (v) => v * 1055.06, fromBase: (v) => v / 1055.06 },
      { name: 'kWh', symbol: 'kWh', toBase: (v) => v * 3.6e6, fromBase: (v) => v / 3.6e6 },
      { name: 'Electronvolt', symbol: 'eV', toBase: (v) => v * 1.602e-19, fromBase: (v) => v / 1.602e-19 },
    ],
  },
  {
    name: 'Power',
    units: [
      { name: 'Watt', symbol: 'W', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Kilowatt', symbol: 'kW', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      { name: 'Horsepower', symbol: 'hp', toBase: (v) => v * 745.7, fromBase: (v) => v / 745.7 },
      { name: 'BTU/h', symbol: 'BTU/h', toBase: (v) => v * 0.293071, fromBase: (v) => v / 0.293071 },
    ],
  },
  {
    name: 'Frequency',
    units: [
      { name: 'Hertz', symbol: 'Hz', toBase: (v) => v, fromBase: (v) => v },
      { name: 'Kilohertz', symbol: 'kHz', toBase: (v) => v * 1000, fromBase: (v) => v / 1000 },
      { name: 'Megahertz', symbol: 'MHz', toBase: (v) => v * 1e6, fromBase: (v) => v / 1e6 },
      { name: 'Gigahertz', symbol: 'GHz', toBase: (v) => v * 1e9, fromBase: (v) => v / 1e9 },
    ],
  },
];

interface HistoryEntry {
  id: string;
  fromValue: number;
  fromUnit: string;
  toValue: number;
  toUnit: string;
  category: string;
}

export default function UnitConverter() {
  const [activeCategory, setActiveCategory] = useState(0);
  const [fromIndex, setFromIndex] = useState(0);
  const [toIndex, setToIndex] = useState(1);
  const [fromValue, setFromValue] = useState('1');
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const category = CATEGORIES[activeCategory];

  const result = useMemo(() => {
    const val = parseFloat(fromValue);
    if (isNaN(val)) return '';
    const fromUnit = category.units[fromIndex];
    const toUnit = category.units[toIndex];
    const baseVal = fromUnit.toBase(val);
    const converted = toUnit.fromBase(baseVal);
    if (converted === 0) return '0';
    if (Math.abs(converted) < 0.000001 || Math.abs(converted) > 1e9) return converted.toExponential(6);
    return parseFloat(converted.toPrecision(10)).toString();
  }, [fromValue, fromIndex, toIndex, category]);

  const commonConversions = useMemo(() => {
    const val = parseFloat(fromValue);
    if (isNaN(val)) return [];
    const fromUnit = category.units[fromIndex];
    const baseVal = fromUnit.toBase(val);
    return category.units
      .filter((_, i) => i !== fromIndex)
      .map((u) => {
        const cv = u.fromBase(baseVal);
        const formatted = cv === 0 ? '0' : Math.abs(cv) < 0.0001 || Math.abs(cv) > 1e6 ? cv.toExponential(4) : parseFloat(cv.toPrecision(8)).toString();
        return { symbol: u.symbol, value: formatted, name: u.name };
      });
  }, [fromValue, fromIndex, category]);

  const swap = useCallback(() => {
    setFromIndex(toIndex);
    setToIndex(fromIndex);
  }, [fromIndex, toIndex]);

  const addToHistory = useCallback(() => {
    const val = parseFloat(fromValue);
    if (isNaN(val) || !result) return;
    const entry: HistoryEntry = {
      id: Date.now().toString(),
      fromValue: val,
      fromUnit: category.units[fromIndex].symbol,
      toValue: parseFloat(result),
      toUnit: category.units[toIndex].symbol,
      category: category.name,
    };
    setHistory((prev) => [entry, ...prev].slice(0, 20));
  }, [fromValue, result, category, fromIndex, toIndex]);

  const handleFromChange = (v: string) => {
    setFromValue(v);
    addToHistory();
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <ArrowLeftRight size={16} style={{ color: 'var(--accent-gold)' }} />
        <span className="text-sm font-semibold">Unit Converter</span>
      </div>

      {/* Category tabs */}
      <div className="flex gap-1 px-2 py-2 overflow-x-auto shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        {CATEGORIES.map((cat, i) => (
          <button
            key={cat.name}
            onClick={() => {
              setActiveCategory(i);
              setFromIndex(0);
              setToIndex(1);
              setFromValue('1');
            }}
            className="px-3 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-colors"
            style={{
              background: i === activeCategory ? 'rgba(201,168,76,0.15)' : 'transparent',
              color: i === activeCategory ? 'var(--accent-gold)' : 'var(--text-secondary)',
            }}
          >
            {cat.name}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Conversion area */}
        <div className="p-4">
          {/* From */}
          <div className="flex gap-2">
            <input
              type="number"
              value={fromValue}
              onChange={(e) => handleFromChange(e.target.value)}
              className="flex-1 px-3 py-2.5 rounded-md text-lg font-mono outline-none"
              style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
            />
            <select
              value={fromIndex}
              onChange={(e) => setFromIndex(Number(e.target.value))}
              className="px-3 py-2.5 rounded-md text-xs outline-none cursor-pointer"
              style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)', minWidth: '100px' }}
            >
              {category.units.map((u, i) => (
                <option key={u.symbol} value={i}>{u.name} ({u.symbol})</option>
              ))}
            </select>
          </div>

          {/* Swap button */}
          <div className="flex items-center justify-center my-2">
            <button
              onClick={swap}
              className="p-2 rounded-full transition-all hover:scale-110 active:rotate-180"
              style={{ background: 'var(--surface-elevated)', color: 'var(--accent-gold)' }}
            >
              <ArrowLeftRight size={14} />
            </button>
          </div>

          {/* To */}
          <div className="flex gap-2">
            <input
              type="text"
              value={result}
              readOnly
              className="flex-1 px-3 py-2.5 rounded-md text-lg font-mono outline-none"
              style={{ background: 'var(--surface)', border: '1px solid var(--border-active)', color: 'var(--accent-gold)' }}
            />
            <select
              value={toIndex}
              onChange={(e) => setToIndex(Number(e.target.value))}
              className="px-3 py-2.5 rounded-md text-xs outline-none cursor-pointer"
              style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)', minWidth: '100px' }}
            >
              {category.units.map((u, i) => (
                <option key={u.symbol} value={i}>{u.name} ({u.symbol})</option>
              ))}
            </select>
          </div>

          {/* Common conversions */}
          <div className="mt-4">
            <div className="text-[11px] font-medium mb-2" style={{ color: 'var(--text-muted)' }}>All Conversions</div>
            <div className="grid grid-cols-2 gap-1.5">
              {commonConversions.map((c) => (
                <div
                  key={c.symbol}
                  className="flex items-center justify-between px-2.5 py-1.5 rounded-md"
                  style={{ background: 'var(--surface)' }}
                >
                  <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{c.name}</span>
                  <span className="text-xs font-mono" style={{ color: 'var(--text-primary)' }}>{c.value} {c.symbol}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* History */}
        {history.length > 0 && (
          <div className="px-4 pb-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <Clock size={12} style={{ color: 'var(--text-muted)' }} />
                <span className="text-[11px] font-medium" style={{ color: 'var(--text-muted)' }}>Recent Conversions</span>
              </div>
              <button
                onClick={() => setHistory([])}
                className="p-1 rounded hover:bg-[#222235]"
                style={{ color: 'var(--text-muted)' }}
              >
                <RotateCcw size={10} />
              </button>
            </div>
            <div className="flex flex-col gap-1">
              {history.slice(0, 10).map((h) => (
                <div
                  key={h.id}
                  className="flex items-center justify-between px-2.5 py-1.5 rounded-md"
                  style={{ background: 'var(--surface)' }}
                >
                  <span className="text-[10px] font-mono">
                    {h.fromValue} {h.fromUnit} = <span style={{ color: 'var(--accent-gold)' }}>{parseFloat(h.toValue.toPrecision(8))} {h.toUnit}</span>
                  </span>
                  <span className="text-[9px]" style={{ color: 'var(--text-muted)' }}>{h.category}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
