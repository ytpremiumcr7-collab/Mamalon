import { useState, useRef, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  Download,
  Grid3X3,
  FileText,
  Printer,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
type ContentBlock =
  | { type: 'heading'; text: string }
  | { type: 'body'; text: string }
  | { type: 'bullet'; text: string }
  | { type: 'spacer' }
  | { type: 'meta'; label: string; value: string }
  | { type: 'table'; headers: string[]; rows: string[][] }
  | { type: 'centered'; text: string };

interface PDFPage {
  title: string;
  subtitle: string;
  content: ContentBlock[];
}

/* ------------------------------------------------------------------ */
/*  Sample PDF Content — 5-page Project Proposal                       */
/* ------------------------------------------------------------------ */
const PAGES: PDFPage[] = [
  {
    title: 'Project Proposal',
    subtitle: 'Cornstone OS — Productivity Suite Enhancement',
    content: [
      { type: 'heading', text: 'Executive Summary' },
      { type: 'body', text: 'This proposal outlines the development and integration of a comprehensive productivity suite within the Cornstone OS environment. The project aims to deliver nine fully functional applications that enhance user productivity while maintaining the sacred minimalism design philosophy that defines the Cornstone OS experience.' },
      { type: 'body', text: 'The productivity suite will include Calendar, Spreadsheet, Presentation, PDF Viewer, Notes, Task Manager, Password Manager, Whiteboard, and Clock applications — each designed with deep functionality and seamless integration into the desktop environment.' },
      { type: 'spacer' },
      { type: 'heading', text: 'Project Overview' },
      { type: 'body', text: 'Cornstone OS is a premium, fully functional web-based Linux desktop replica presenting as a complete operating system running inside the browser. The productivity apps represent a critical expansion of the platform capabilities, transforming it from a demonstration environment into a genuine productivity tool.' },
      { type: 'meta', label: 'Prepared by', value: 'Cornstone Engineering Team' },
      { type: 'meta', label: 'Date', value: 'June 2025' },
      { type: 'meta', label: 'Version', value: '1.0' },
    ],
  },
  {
    title: 'Technical Architecture',
    subtitle: 'Design Principles & Technology Stack',
    content: [
      { type: 'heading', text: 'Technology Stack' },
      { type: 'body', text: 'The productivity suite is built using modern web technologies optimized for performance and user experience:' },
      { type: 'bullet', text: 'React 19 with TypeScript for type-safe component architecture' },
      { type: 'bullet', text: 'Tailwind CSS v3 with custom design tokens matching the Cornstone OS aesthetic' },
      { type: 'bullet', text: 'Framer Motion for smooth window animations and micro-interactions' },
      { type: 'bullet', text: 'Zustand for lightweight state management with localStorage persistence' },
      { type: 'bullet', text: 'date-fns for reliable date manipulation across all calendar features' },
      { type: 'spacer' },
      { type: 'heading', text: 'Design System Integration' },
      { type: 'body', text: 'All applications adhere to the Cornstone OS design system featuring the sacred minimalism direction. The dark contemplative environment uses warm amber/gold accents (the cornstone motif), glassmorphism window chrome, and smooth purposeful animations that evoke both gravitas and precision.' },
      { type: 'body', text: 'Color tokens include the deep void background (#030305), surface panels (#12121A), accent gold (#C9A84C), and warm parchment text (#E8E4DC). Typography uses Inter for UI elements and JetBrains Mono for technical values.' },
    ],
  },
  {
    title: 'Application Specifications',
    subtitle: 'Detailed Feature Breakdown',
    content: [
      { type: 'heading', text: 'Calendar Application' },
      { type: 'body', text: 'Full month view grid with Sunday-first layout, week view toggle, and mini calendar sidebar. Users can create events with title, time, and description. Mexican holidays are automatically marked. All events persist to localStorage.' },
      { type: 'heading', text: 'Spreadsheet Engine' },
      { type: 'body', text: '20-column by 50-row grid with a complete formula engine supporting SUM, AVG, MIN, MAX, COUNT, IF, and cell references. Formatting includes bold, italic, number formats, and text colors. Export to JSON and CSV formats.' },
      { type: 'heading', text: 'Presentation Tool' },
      { type: 'body', text: 'Slide editor with thumbnail panel, text boxes, shapes, images, and bullet lists. Present mode provides full-screen slideshow navigation with fade, slide, and zoom transitions powered by Framer Motion.' },
      { type: 'heading', text: 'Task Manager' },
      { type: 'body', text: 'Kanban board with four columns (To Do, In Progress, Review, Done). Task cards include priority badges, tags, and due dates. All data persists to localStorage with filtering capabilities.' },
    ],
  },
  {
    title: 'Implementation Plan',
    subtitle: 'Timeline & Resource Allocation',
    content: [
      { type: 'heading', text: 'Phase 1: Core Applications' },
      { type: 'table', headers: ['Application', 'Complexity', 'Duration', 'Priority'], rows: [
        ['Calendar', 'Medium', '2 days', 'High'],
        ['Spreadsheet', 'High', '3 days', 'High'],
        ['Presentation', 'High', '3 days', 'High'],
        ['Notes', 'Medium', '2 days', 'High'],
        ['PDF Viewer', 'Low', '1 day', 'Medium'],
      ]},
      { type: 'spacer' },
      { type: 'heading', text: 'Phase 2: Utility Applications' },
      { type: 'table', headers: ['Application', 'Complexity', 'Duration', 'Priority'], rows: [
        ['Task Manager', 'Medium', '2 days', 'High'],
        ['Password Manager', 'Medium', '2 days', 'High'],
        ['Whiteboard', 'High', '3 days', 'Medium'],
        ['Clock', 'Medium', '2 days', 'Medium'],
      ]},
      { type: 'spacer' },
      { type: 'heading', text: 'Quality Assurance' },
      { type: 'body', text: 'Each application undergoes rigorous testing including functionality verification, edge case handling, localStorage persistence validation, and visual consistency checks against the design system. Build verification ensures zero TypeScript errors and successful production bundling.' },
    ],
  },
  {
    title: 'Conclusion',
    subtitle: 'Next Steps & Deliverables',
    content: [
      { type: 'heading', text: 'Expected Outcomes' },
      { type: 'body', text: 'Upon completion, Cornstone OS will feature a fully integrated productivity suite that rivals standalone web applications. Users will be able to manage schedules, analyze data, create presentations, organize tasks, secure passwords, take notes, sketch ideas, and track time — all within a cohesive desktop environment.' },
      { type: 'spacer' },
      { type: 'heading', text: 'Future Enhancements' },
      { type: 'bullet', text: 'Cloud synchronization across devices using backend API integration' },
      { type: 'bullet', text: 'Real-time collaboration features for shared documents and whiteboards' },
      { type: 'bullet', text: 'Advanced spreadsheet charting with Recharts visualization library' },
      { type: 'bullet', text: 'AI-powered suggestions for task prioritization and scheduling' },
      { type: 'bullet', text: 'Plugin architecture allowing third-party application development' },
      { type: 'spacer' },
      { type: 'body', text: 'The productivity suite represents a significant milestone in the Cornstone OS roadmap, establishing the platform as both a technical demonstration and a practical tool for daily productivity workflows.' },
      { type: 'spacer' },
      { type: 'centered', text: '— End of Document —' },
    ],
  },
];

const ZOOM_LEVELS = [0.5, 0.75, 1, 1.25, 1.5, 2];

/* ------------------------------------------------------------------ */
/*  Page Renderer                                                      */
/* ------------------------------------------------------------------ */
function PDFPageRenderer({ page, pageNum, total }: { page: PDFPage; pageNum: number; total: number }) {
  return (
    <div
      className="bg-white text-black mx-auto mb-4 shadow-[0_4px_16px_rgba(0,0,0,0.3)] relative"
      style={{
        width: '680px',
        minHeight: '880px',
        padding: '60px 60px 50px 60px',
      }}
    >
      {/* Header */}
      <div className="border-b-2 border-[#1A1A26] pb-4 mb-6">
        <div className="text-[10px] text-[#666666] uppercase tracking-widest mb-1">Cornstone OS</div>
        <h1 className="text-2xl font-bold text-[#1A1A26] mb-1">{page.title}</h1>
        {page.subtitle && <div className="text-sm text-[#555555]">{page.subtitle}</div>}
      </div>

      {/* Content */}
      <div className="space-y-1">
        {page.content.map((block, i) => {
          switch (block.type) {
            case 'heading':
              return <h2 key={i} className="text-base font-bold text-[#1A1A26] mt-5 mb-2">{block.text}</h2>;
            case 'body':
              return <p key={i} className="text-[11px] leading-relaxed text-[#333333] mb-2 text-justify">{block.text}</p>;
            case 'bullet':
              return (
                <div key={i} className="flex items-start gap-2 text-[11px] text-[#333333] mb-1.5 ml-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C9A84C] mt-1.5 flex-shrink-0" />
                  <span className="leading-relaxed">{block.text}</span>
                </div>
              );
            case 'spacer':
              return <div key={i} className="h-3" />;
            case 'meta':
              return (
                <div key={i} className="flex items-center gap-2 text-[11px] mb-1">
                  <span className="text-[#888888] w-[100px]">{block.label}:</span>
                  <span className="text-[#333333] font-medium">{block.value}</span>
                </div>
              );
            case 'table':
              return (
                <div key={i} className="my-3 border border-[#CCCCCC] rounded overflow-hidden">
                  <table className="w-full text-[10px]">
                    <thead>
                      <tr className="bg-[#F5F5F0]">
                        {block.headers?.map((h, hi) => (
                          <th key={hi} className="px-2 py-1.5 text-left font-semibold text-[#1A1A26] border-b border-[#CCCCCC]">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {block.rows?.map((row, ri) => (
                        <tr key={ri} className={ri % 2 === 1 ? 'bg-[#FAFAFA]' : ''}>
                          {row.map((cell, ci) => (
                            <td key={ci} className="px-2 py-1.5 text-[#333333] border-b border-[#EEEEEE]">{cell}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
            case 'centered':
              return <div key={i} className="text-center text-[11px] text-[#888888] mt-6 italic">{block.text}</div>;
            default:
              return null;
          }
        })}
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 left-0 right-0 flex items-center justify-between px-[60px]">
        <span className="text-[9px] text-[#AAAAAA]">Cornstone OS Productivity Suite</span>
        <span className="text-[9px] text-[#AAAAAA]">Page {pageNum} of {total}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main PDF Viewer App                                                */
/* ------------------------------------------------------------------ */
export default function PDFViewerApp() {
  const [currentPage, setCurrentPage] = useState(0);
  const [zoomIndex, setZoomIndex] = useState(2); // 100%
  const [showThumbnails, setShowThumbnails] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const [selectedText, setSelectedText] = useState(false);
  const viewerRef = useRef<HTMLDivElement>(null);

  const zoom = ZOOM_LEVELS[zoomIndex];
  const totalPages = PAGES.length;

  const handlePrev = () => setCurrentPage((p) => Math.max(0, p - 1));
  const handleNext = () => setCurrentPage((p) => Math.min(totalPages - 1, p + 1));

  const handleZoomIn = () => setZoomIndex((i) => Math.min(ZOOM_LEVELS.length - 1, i + 1));
  const handleZoomOut = () => setZoomIndex((i) => Math.max(0, i - 1));

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'ArrowRight' || e.key === ' ') setCurrentPage((p) => Math.min(totalPages - 1, p + 1));
    if (e.key === 'ArrowLeft') setCurrentPage((p) => Math.max(0, p - 1));
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const content = PAGES.map((p, i) =>
      `=== Page ${i + 1}: ${p.title} ===\n${p.subtitle}\n\n${p.content.map((c: ContentBlock) => {
        if (c.type === 'heading') return `## ${c.text}`;
        if (c.type === 'body') return c.text;
        if (c.type === 'bullet') return `• ${c.text}`;
        if (c.type === 'meta') return `${c.label}: ${c.value}`;
        if (c.type === 'centered') return c.text;
        if (c.type === 'table') return c.headers.join(' | ') + '\n' + c.rows.map((r: string[]) => r.join(' | ')).join('\n');
        return '';
      }).join('\n')}`
    ).join('\n\n---\n\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'project-proposal.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`w-full h-full bg-[#0A0A0F] text-[#E8E4DC] flex flex-col ${fullscreen ? 'fixed inset-0 z-[99999]' : ''}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E] bg-[#1A1A26]">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-[#C9A84C]" />
          <span className="text-sm font-medium text-[#E8E4DC]">document.pdf</span>
          <span className="text-xs text-[#4D4A42]">|</span>
          <span className="text-xs text-[#8A8578]">{totalPages} pages</span>
        </div>

        <div className="flex items-center gap-1">
          <button onClick={handlePrev} disabled={currentPage === 0} className="p-1.5 hover:bg-[#222235] rounded transition-colors disabled:opacity-30">
            <ChevronLeft className="w-4 h-4 text-[#8A8578]" />
          </button>
          <span className="text-xs text-[#8A8578] min-w-[80px] text-center">
            Page {currentPage + 1} of {totalPages}
          </span>
          <button onClick={handleNext} disabled={currentPage === totalPages - 1} className="p-1.5 hover:bg-[#222235] rounded transition-colors disabled:opacity-30">
            <ChevronRight className="w-4 h-4 text-[#8A8578]" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1.5" />
          <button onClick={handleZoomOut} className="p-1.5 hover:bg-[#222235] rounded transition-colors">
            <ZoomOut className="w-4 h-4 text-[#8A8578]" />
          </button>
          <span className="text-xs text-[#8A8578] min-w-[40px] text-center">{Math.round(zoom * 100)}%</span>
          <button onClick={handleZoomIn} className="p-1.5 hover:bg-[#222235] rounded transition-colors">
            <ZoomIn className="w-4 h-4 text-[#8A8578]" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1.5" />
          <button
            onClick={() => setShowThumbnails(!showThumbnails)}
            className={`p-1.5 rounded transition-colors ${showThumbnails ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235] text-[#8A8578]'}`}
            title="Toggle Thumbnails"
          >
            <Grid3X3 className="w-4 h-4" />
          </button>
          <button onClick={handlePrint} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Print">
            <Printer className="w-4 h-4" />
          </button>
          <button onClick={handleDownload} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Download">
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={() => setFullscreen(!fullscreen)}
            className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]"
            title={fullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {fullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Viewer area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Thumbnail sidebar */}
        {showThumbnails && (
          <div className="w-[150px] border-r border-[#2A2A3E] bg-[#12121A] overflow-auto p-2 space-y-2">
            {PAGES.map((page, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx)}
                className={`w-full rounded border-2 transition-all overflow-hidden ${
                  idx === currentPage ? 'border-[#C9A84C]' : 'border-[#2A2A3E] hover:border-[#3D3D5C]'
                }`}
              >
                <div
                  className="aspect-[17/22] bg-white p-1 overflow-hidden"
                >
                  <div className="text-[3px] text-[#1A1A26] font-bold leading-tight truncate">{page.title}</div>
                  <div className="text-[2px] text-[#888888] truncate">{page.subtitle}</div>
                  <div className="mt-0.5 space-y-0.5">
                    {page.content.slice(0, 4).map((c, ci) => (
                      <div key={ci}>
                        {c.type === 'heading' && <div className="text-[2.5px] font-bold text-[#1A1A26] truncate">{c.text}</div>}
                        {c.type === 'body' && <div className="text-[2px] text-[#555555] line-clamp-2">{c.text}</div>}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="text-[9px] text-[#8A8578] py-0.5 bg-[#1A1A26]">{idx + 1}</div>
              </button>
            ))}
          </div>
        )}

        {/* Main page view */}
        <div
          ref={viewerRef}
          className="flex-1 overflow-auto bg-[#2A2A3E]/30 select-text"
          style={{ cursor: selectedText ? 'text' : 'default' }}
          onMouseUp={() => setSelectedText(!!window.getSelection()?.toString())}
        >
          <div
            className="py-6 transition-transform duration-200 origin-top"
            style={{ transform: `scale(${zoom})`, marginLeft: 'auto', marginRight: 'auto', width: 'fit-content' }}
          >
            <PDFPageRenderer page={PAGES[currentPage]} pageNum={currentPage + 1} total={totalPages} />
          </div>
        </div>
      </div>
    </div>
  );
}
