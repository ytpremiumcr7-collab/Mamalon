import { useState, useRef, useEffect, useCallback } from 'react';
import { useFileSystem } from '@/stores/useFileSystem';
type OutputLine = {
  type: 'prompt' | 'output' | 'error' | 'info';
  text: string;
};

const COMMANDS = [
  'ls', 'cd', 'pwd', 'mkdir', 'rm', 'cp', 'mv', 'cat', 'echo', 'clear',
  'neofetch', 'whoami', 'date', 'help', 'touch', 'head', 'tail', 'find', 'tree',
];

export default function Terminal() {
  const { nodes, addNode, deleteNode, renameNode } = useFileSystem();
  const [output, setOutput] = useState<OutputLine[]>([
    { type: 'info', text: 'Cornstone OS Terminal v1.0' },
    { type: 'info', text: 'Type "help" for available commands.' },
    { type: 'output', text: '' },
  ]);
  const [input, setInput] = useState('');
  const [cwd, setCwd] = useState<string[]>([]); // stack of node IDs
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [tabSuggestions, setTabSuggestions] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [output]);

  const getCurrentNodeId = useCallback((): string | null => {
    return cwd.length > 0 ? cwd[cwd.length - 1] : null;
  }, [cwd]);

  const resolvePath = useCallback((path: string): string | null => {
    if (path === '/' || path === '~') return null;
    if (path === '.') return getCurrentNodeId();
    if (path === '..') return cwd.length > 1 ? cwd[cwd.length - 2] : null;

    let currentId: string | null = getCurrentNodeId();
    const parts = path.split('/').filter(Boolean);

    for (const part of parts) {
      if (part === '..') {
        if (currentId === null) return null;
        const node = nodes.find(n => n.id === currentId);
        currentId = node?.parentId ?? null;
      } else if (part !== '.') {
        const children = nodes.filter(n => n.parentId === currentId);
        const match = children.find(c => c.name === part);
        if (!match) return null;
        currentId = match.id;
      }
    }
    return currentId;
  }, [cwd, getCurrentNodeId, nodes]);

  const getCwdPath = useCallback((): string => {
    if (cwd.length === 0) return '~';
    const parts: string[] = [];
    for (const id of cwd) {
      const node = nodes.find(n => n.id === id);
      if (node) parts.push(node.name);
    }
    return `~/` + parts.join('/');
  }, [cwd, nodes]);

  const formatDate = (ts: number): string => {
    const d = new Date(ts);
    return `${d.toLocaleString('en', { month: 'short' })} ${d.getDate().toString().padStart(2, '0')} ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  const addLines = useCallback((lines: OutputLine[]) => {
    setOutput(prev => [...prev, ...lines]);
  }, []);

  const addPrompt = useCallback(() => {
    setOutput(prev => [...prev, { type: 'prompt', text: '' }]);
  }, []);

  const parseArgs = (input: string): string[] => {
    const args: string[] = [];
    let current = '';
    let inQuotes = false;
    for (const ch of input) {
      if (ch === '"') { inQuotes = !inQuotes; continue; }
      if (ch === ' ' && !inQuotes) {
        if (current) { args.push(current); current = ''; }
      } else { current += ch; }
    }
    if (current) args.push(current);
    return args;
  };

  const executeCommand = useCallback((rawInput: string) => {
    const trimmed = rawInput.trim();
    const lines: OutputLine[] = [];

    if (!trimmed) { addPrompt(); return; }

    // Add to history
    setCommandHistory(prev => [...prev.slice(-499), trimmed]);
    setHistoryIndex(-1);

    const args = parseArgs(trimmed);
    const cmd = args[0].toLowerCase();
    const rest = args.slice(1);

    const append = (text: string, type: OutputLine['type'] = 'output') => {
      lines.push({ type, text });
    };

    const currentParentId = getCurrentNodeId();

    switch (cmd) {
      case 'ls': {
        const showAll = rest.includes('-a') || rest.includes('-la') || rest.includes('-al');
        const longFormat = rest.includes('-l') || rest.includes('-la') || rest.includes('-al');
        const targetPath = rest.find(a => !a.startsWith('-'));
        const targetId = targetPath ? resolvePath(targetPath) : currentParentId;

        const children = nodes.filter(n => n.parentId === targetId);
        if (!children.length) { append('total 0'); break; }

        if (longFormat) {
          append(`total ${children.length * 4}`);
          // . and .. entries
          append(`drwxr-xr-x  2 user user 4096 ${formatDate(Date.now())} .`);
          append(`drwxr-xr-x  2 user user 4096 ${formatDate(Date.now())} ..`);
          children.forEach(child => {
            if (!showAll && child.name.startsWith('.')) return;
            const isDir = child.type === 'folder';
            const perms = isDir ? 'drwxr-xr-x' : '-rw-r--r--';
            const size = child.size || 0;
            const name = child.name;
            lines.push({ type: isDir ? 'output' : 'output', text: `${perms}  1 user user ${size.toString().padStart(5)} ${formatDate(child.modifiedAt)} ` });
            // Colorize the name
            lines.push({ type: isDir ? 'info' : 'output', text: name });
            lines.push({ type: 'output', text: '' });
          });
        } else {
          const names = children
            .filter(c => showAll || !c.name.startsWith('.'))
            .map(c => c.name);
          append(names.join('  '));
        }
        break;
      }

      case 'cd': {
        const target = rest[0] || '~';
        if (target === '~' || target === '/') { setCwd([]); break; }
        if (target === '-') { append('No previous directory'); break; }
        if (target === '..') { setCwd(prev => prev.slice(0, -1)); break; }
        const targetId = resolvePath(target);
        if (!targetId) { append(`cd: no such file or directory: ${target}`, 'error'); break; }
        const node = nodes.find(n => n.id === targetId);
        if (!node || node.type !== 'folder') { append(`cd: not a directory: ${target}`, 'error'); break; }
        setCwd(prev => [...prev, targetId]);
        break;
      }

      case 'pwd':
        append('/home/user' + (cwd.length > 0 ? '/' + cwd.map(id => nodes.find(n => n.id === id)?.name).join('/') : ''));
        break;

      case 'mkdir': {
        const name = rest[0];
        if (!name) { append('mkdir: missing operand', 'error'); break; }
        addNode({ name, type: 'folder', parentId: currentParentId });
        break;
      }

      case 'touch': {
        const name = rest[0];
        if (!name) { append('touch: missing operand', 'error'); break; }
        const existing = nodes.find(n => n.parentId === currentParentId && n.name === name);
        if (!existing) {
          addNode({ name, type: 'file', parentId: currentParentId, content: '', size: 0 });
        }
        break;
      }

      case 'rm': {
        const recursive = rest.includes('-r') || rest.includes('-rf');
        const target = rest.find(a => !a.startsWith('-'));
        if (!target) { append('rm: missing operand', 'error'); break; }
        const targetId = resolvePath(target);
        if (!targetId) { append(`rm: cannot remove '${target}': No such file or directory`, 'error'); break; }
        const node = nodes.find(n => n.id === targetId);
        if (!node) break;
        if (node.type === 'folder' && !recursive) { append(`rm: cannot remove '${target}': Is a directory`, 'error'); break; }
        deleteNode(targetId);
        break;
      }

      case 'cp': {
        if (rest.length < 2) { append('cp: missing file operand', 'error'); break; }
        const [src, dst] = rest;
        const srcId = resolvePath(src);
        if (!srcId) { append(`cp: cannot stat '${src}': No such file or directory`, 'error'); break; }
        const srcNode = nodes.find(n => n.id === srcId);
        if (!srcNode) break;
        const dstId = resolvePath(dst);
        const dstParentId = dstId ?? currentParentId;
        const dstName = dstId ? nodes.find(n => n.id === dstId)?.name : dst;
        addNode({
          name: dstName || `${srcNode.name}_copy`,
          type: srcNode.type,
          parentId: dstParentId,
          content: srcNode.content,
          size: srcNode.size,
        });
        break;
      }

      case 'mv': {
        if (rest.length < 2) { append('mv: missing file operand', 'error'); break; }
        const [src, dst] = rest;
        const srcId = resolvePath(src);
        if (!srcId) { append(`mv: cannot stat '${src}': No such file or directory`, 'error'); break; }
        const dstId = resolvePath(dst);
        if (dstId) {
          // Move to directory
          renameNode(srcId, nodes.find(n => n.id === srcId)?.name || src);
          const dstNode = nodes.find(n => n.id === dstId);
          if (dstNode?.type === 'folder') {
            // Update parentId directly by re-adding
            const srcNode = nodes.find(n => n.id === srcId);
            if (srcNode) {
              deleteNode(srcId);
              const { id: _id, createdAt: _ct, modifiedAt: _mt, ...rest } = srcNode;
              addNode({ ...rest, parentId: dstId });
            }
          }
        } else {
          renameNode(srcId, dst);
        }
        break;
      }

      case 'cat': {
        const target = rest[0];
        if (!target) { append('cat: missing operand', 'error'); break; }
        const targetId = resolvePath(target);
        if (!targetId) { append(`cat: ${target}: No such file or directory`, 'error'); break; }
        const node = nodes.find(n => n.id === targetId);
        if (!node || node.type === 'folder') { append(`cat: ${target}: Is a directory`, 'error'); break; }
        append(node.content || '(empty file)');
        break;
      }

      case 'head': {
        const target = rest[0];
        if (!target) { append('head: missing operand', 'error'); break; }
        const targetId = resolvePath(target);
        if (!targetId) { append(`head: ${target}: No such file or directory`, 'error'); break; }
        const node = nodes.find(n => n.id === targetId);
        if (!node) break;
        const contentLines = (node.content || '').split('\n').slice(0, 20);
        contentLines.forEach(l => append(l));
        break;
      }

      case 'tail': {
        const target = rest[0];
        if (!target) { append('tail: missing operand', 'error'); break; }
        const targetId = resolvePath(target);
        if (!targetId) { append(`tail: ${target}: No such file or directory`, 'error'); break; }
        const node = nodes.find(n => n.id === targetId);
        if (!node) break;
        const contentLines = (node.content || '').split('\n').slice(-20);
        contentLines.forEach(l => append(l));
        break;
      }

      case 'echo': {
        append(rawInput.slice(5));
        break;
      }

      case 'clear': {
        setOutput([]);
        return;
      }

      case 'neofetch': {
        const neofetch = [
          { type: 'output' as const, text: '       ___                               user@cornstone' },
          { type: 'output' as const, text: '      /   \\                              --------------' },
          { type: 'output' as const, text: '     |  ✦  |     Cornstone OS            OS: Cornstone OS 1.0' },
          { type: 'output' as const, text: '      \\___/                              Kernel: cornstone-6.8.0' },
          { type: 'output' as const, text: '    /       \\                            Uptime: 2h 34m' },
          { type: 'output' as const, text: '   |  ✦   ✦  |                           Shell: bash 5.2' },
          { type: 'output' as const, text: '    \\   ✦   /                            Resolution: 1920x1080' },
          { type: 'output' as const, text: '     \\_____/                             DE: Cornstone Desktop' },
          { type: 'output' as const, text: '       ||                                WM: Cornstone WM' },
          { type: 'output' as const, text: '       ||                                Theme: Dark [Gold]' },
          { type: 'output' as const, text: '       ||                                CPU: Virtual 8-Core' },
          { type: 'output' as const, text: '       ||                                Memory: 4GB / 16GB' },
        ];
        addLines(neofetch);
        addPrompt();
        return;
      }

      case 'whoami': {
        append('user');
        break;
      }

      case 'date': {
        append(new Date().toString());
        break;
      }

      case 'find': {
        const searchPath = rest[0] || '.';
        const namePattern = rest.find((_, i) => rest[i - 1] === '-name');
        const startId = searchPath === '.' ? currentParentId : resolvePath(searchPath);
        const results: string[] = [];
        const searchRecursive = (parentId: string | null, prefix: string) => {
          nodes.filter(n => n.parentId === parentId).forEach(child => {
            const fullPath = prefix + child.name;
            if (!namePattern || child.name.includes(namePattern.replace(/"/g, '').replace(/\*/g, ''))) {
              results.push(fullPath);
            }
            if (child.type === 'folder') {
              searchRecursive(child.id, fullPath + '/');
            }
          });
        };
        searchRecursive(startId, startId ? (nodes.find(n => n.id === startId)?.name || '') + '/' : '');
        results.forEach(r => append(r));
        break;
      }

      case 'tree': {
        const treePath = rest[0] || '.';
        const startId = treePath === '.' ? currentParentId : resolvePath(treePath);
        const buildTree = (parentId: string | null, prefix: string): string[] => {
          const result: string[] = [];
          const children = nodes.filter(n => n.parentId === parentId);
          children.forEach((child, i) => {
            const isLastChild = i === children.length - 1;
            const connector = isLastChild ? '└── ' : '├── ';
            result.push(prefix + connector + child.name);
            if (child.type === 'folder') {
              result.push(...buildTree(child.id, prefix + (isLastChild ? '    ' : '│   ')));
            }
          });
          return result;
        };
        const nodeName = startId ? nodes.find(n => n.id === startId)?.name || '.' : '.';
        append(nodeName);
        buildTree(startId, '').forEach(l => append(l));
        break;
      }

      case 'help': {
        append('Available commands:', 'info');
        append('  ls [-la] [path]     List directory contents');
        append('  cd [dir]            Change directory');
        append('  pwd                 Print working directory');
        append('  mkdir [name]        Create directory');
        append('  touch [name]        Create empty file');
        append('  rm [-r] [file]      Remove file/directory');
        append('  cp [src] [dst]      Copy file');
        append('  mv [src] [dst]      Move/rename file');
        append('  cat [file]          Display file contents');
        append('  head [file]         Show first 20 lines');
        append('  tail [file]         Show last 20 lines');
        append('  echo [text]         Print text');
        append('  clear               Clear terminal');
        append('  neofetch            Display system info');
        append('  whoami              Current user');
        append('  date                Current date/time');
        append('  find [path] -name   Search for files');
        append('  tree [path]         Directory tree');
        append('  help                Show this help');
        break;
      }

      default: {
        append(`Command not found: ${cmd}. Type "help" for available commands.`, 'error');
      }
    }

    addLines(lines);
    addPrompt();
  }, [cwd, getCurrentNodeId, nodes, addNode, deleteNode, renameNode, resolvePath, addLines, addPrompt]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) { addPrompt(); return; }

    setOutput(prev => [...prev, { type: 'prompt', text: input }]);
    executeCommand(input);
    setInput('');
    setTabSuggestions([]);
  }, [input, executeCommand, addPrompt]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHistoryIndex(prev => {
        const newIdx = prev + 1;
        if (newIdx >= commandHistory.length) return prev;
        setInput(commandHistory[commandHistory.length - 1 - newIdx] || '');
        return newIdx;
      });
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHistoryIndex(prev => {
        const newIdx = prev - 1;
        if (newIdx < 0) { setInput(''); return -1; }
        setInput(commandHistory[commandHistory.length - 1 - newIdx] || '');
        return newIdx;
      });
    } else if (e.key === 'Tab') {
      e.preventDefault();
      void historyIndex; // used by arrow key handlers
      if (tabSuggestions.length > 0) {
        // Cycle through suggestions
        return;
      }

      // Try to complete
      const words = input.split(' ');
      const lastWord = words[words.length - 1];
      if (words.length === 1) {
        // Complete command
        const matches = COMMANDS.filter(c => c.startsWith(lastWord.toLowerCase()));
        if (matches.length === 1) {
          setInput(matches[0] + ' ');
        } else if (matches.length > 1) {
          setOutput(prev => [...prev, { type: 'output', text: matches.join('  ') }]);
          setTabSuggestions(matches);
        }
      } else {
        // Complete file/directory
        const currentId = getCurrentNodeId();
        const children = nodes.filter(n => n.parentId === currentId);
        const matches = children.map(c => c.name).filter(n => n.startsWith(lastWord));
        if (matches.length === 1) {
          words[words.length - 1] = matches[0];
          setInput(words.join(' ') + (children.find(c => c.name === matches[0])?.type === 'folder' ? '/' : ' '));
        } else if (matches.length > 1) {
          setOutput(prev => [...prev, { type: 'output', text: matches.join('  ') }]);
          setTabSuggestions(matches);
        }
      }
    } else {
      setHistoryIndex(-1);
      setTabSuggestions([]);
    }
  }, [input, commandHistory, tabSuggestions, getCurrentNodeId, nodes]);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] font-mono text-sm flex flex-col p-3 overflow-hidden">
      <div ref={scrollRef} className="flex-1 overflow-auto space-y-0.5">
        {output.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap leading-relaxed">
            {line.type === 'prompt' && (
              <span>
                <span className="text-[#5A9E6F]">user</span>
                <span className="text-[#8A8578]">@cornstone:</span>
                <span className="text-[#4A9E9E]">{getCwdPath()}</span>
                <span className="text-[#E8E4DC]">$ </span>
                {line.text && <span className="text-[#E8E4DC]">{line.text}</span>}
              </span>
            )}
            {line.type === 'error' && <span className="text-[#B84A4A]">{line.text}</span>}
            {line.type === 'info' && <span className="text-[#C9A84C]">{line.text}</span>}
            {line.type === 'output' && <span className="text-[#E8E4DC]">{line.text}</span>}
          </div>
        ))}

        {/* Active input line */}
        <form onSubmit={handleSubmit} className="flex items-center">
          <span>
            <span className="text-[#5A9E6F]">user</span>
            <span className="text-[#8A8578]">@cornstone:</span>
            <span className="text-[#4A9E9E]">{getCwdPath()}</span>
            <span className="text-[#E8E4DC]">$ </span>
          </span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent outline-none text-[#E8E4DC] font-mono ml-1"
            autoFocus
            spellCheck={false}
            autoComplete="off"
          />
        </form>
      </div>
    </div>
  );
}
