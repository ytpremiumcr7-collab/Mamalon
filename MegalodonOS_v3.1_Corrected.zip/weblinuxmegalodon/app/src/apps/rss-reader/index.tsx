import { useState, useMemo } from 'react';
import {
  Rss,
  Plus,
  X,
  Star,
  RefreshCw,
  ExternalLink,
  Clock,
  Search,
  Newspaper,
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  source: string;
  feedId: string;
  date: string;
  read: boolean;
  starred: boolean;
  category: string;
}

interface Feed {
  id: string;
  name: string;
  url: string;
  category: string;
}

const FEEDS: Feed[] = [
  { id: '1', name: 'TechCrunch', url: 'https://techcrunch.com/feed', category: 'Tech' },
  { id: '2', name: 'Hacker News', url: 'https://news.ycombinator.com/rss', category: 'Tech' },
  { id: '3', name: 'Dev.to', url: 'https://dev.to/feed', category: 'Dev' },
  { id: '4', name: 'CSS-Tricks', url: 'https://css-tricks.com/feed', category: 'Design' },
  { id: '5', name: 'Smashing Mag', url: 'https://www.smashingmagazine.com/feed', category: 'Design' },
];

const DEMO_ARTICLES: Article[] = [
  { id: '1', title: 'Cornstone OS v1.0 Released to the Public', excerpt: 'After months of development, the web-based operating system is finally available...',
    content: 'After months of development, Cornstone OS v1.0 has been released to the public. The web-based operating system features over 50 fully functional applications, a customizable desktop environment, and seamless integration between tools.\n\nKey features include:\n- Full window management system\n- 50+ applications (productivity, development, media, games)\n- Customizable themes and desktop layouts\n- File system with persistence\n- Real-time system monitoring\n\nThe OS is built with React 19, TypeScript, and Tailwind CSS.', source: 'TechCrunch', feedId: '1', date: '2026-01-15T10:00:00', read: false, starred: true, category: 'Tech' },
  { id: '2', title: 'The Future of Web-Based Operating Systems', excerpt: 'As browser capabilities expand, web OS platforms are becoming increasingly viable...',
    content: 'The line between native applications and web applications continues to blur. With the advent of WebAssembly, File System Access API, and advanced browser rendering, web-based operating systems are becoming a real alternative to traditional desktop environments.\n\nThis article explores the technical foundations, current limitations, and future potential of browser-based OS platforms.', source: 'TechCrunch', feedId: '1', date: '2026-01-14T14:30:00', read: false, starred: false, category: 'Tech' },
  { id: '3', title: 'Show HN: I built a desktop OS in the browser', excerpt: 'After 6 months of weekend hacking, I present Cornstone OS...',
    content: 'Show HN: After 6 months of weekend hacking, I present Cornstone OS - a fully functional web-based desktop environment inspired by classic operating systems.\n\nBuilt with React, TypeScript, Zustand for state management, and Framer Motion for animations.\n\nFeatures 50+ apps including:\n- Code editor with syntax highlighting\n- File manager with drag-and-drop\n- Media player\n- Games (Chess, Tetris, Snake)\n- Scientific calculators and graphing tools\n\nWould love feedback from the HN community!', source: 'Hacker News', feedId: '2', date: '2026-01-13T08:00:00', read: true, starred: false, category: 'Tech' },
  { id: '4', title: 'Understanding React Server Components', excerpt: 'A deep dive into the architecture and benefits of RSC...',
    content: 'React Server Components (RSC) represent a paradigm shift in how we build React applications. By allowing components to render exclusively on the server, we can reduce the amount of JavaScript sent to the client while improving initial page load performance.\n\nIn this article, we\'ll explore:\n- How RSC differs from SSR and SSG\n- The mental model for server/client boundaries\n- Practical patterns for building with RSC\n- Performance implications and trade-offs', source: 'Dev.to', feedId: '3', date: '2026-01-12T11:00:00', read: true, starred: true, category: 'Dev' },
  { id: '5', title: 'CSS Container Queries: A Complete Guide', excerpt: 'Container queries are finally here. Learn how to use them effectively...',
    content: 'CSS Container Queries have landed in all major browsers, and they\'re a game-changer for component-based design. Unlike media queries that respond to viewport size, container queries respond to the size of their parent container.\n\nThis comprehensive guide covers:\n- Container query syntax and usage\n- @container at-rule\n- container-type property\n- Practical examples and patterns\n- Browser support and fallbacks', source: 'CSS-Tricks', feedId: '4', date: '2026-01-11T09:00:00', read: false, starred: false, category: 'Design' },
  { id: '6', title: 'Design Systems at Scale: Lessons Learned', excerpt: 'How we built and maintained a design system for 50+ applications...',
    content: 'Building a design system for a large suite of applications presents unique challenges. In this article, I share lessons learned from creating Cornstone OS\'s design system, which spans 50+ applications.\n\nTopics include:\n- Token architecture and naming conventions\n- Component composition patterns\n- Documentation strategies\n- Governance and contribution models\n- Measuring adoption and success', source: 'Smashing Mag', feedId: '5', date: '2026-01-10T13:00:00', read: true, starred: false, category: 'Design' },
  { id: '7', title: 'TypeScript 5.7: What\'s New', excerpt: 'The latest TypeScript release brings exciting features...',
    content: 'TypeScript 5.7 has been released with several exciting features that improve developer experience and type safety.\n\nKey highlights:\n- Improved type inference for generic functions\n- New utility types\n- Better error messages\n- Performance improvements\n- ECMAScript decorators stage 3 support\n\nLet\'s explore each feature in detail.', source: 'Dev.to', feedId: '3', date: '2026-01-09T16:00:00', read: false, starred: false, category: 'Dev' },
  { id: '8', title: 'Vite vs Webpack in 2026', excerpt: 'A comprehensive comparison of the two most popular bundlers...',
    content: 'The JavaScript tooling landscape has evolved rapidly. In 2026, Vite and Webpack remain the two most popular bundlers, but their approaches differ significantly.\n\nThis article compares:\n- Build performance\n- Development experience\n- Plugin ecosystems\n- Configuration complexity\n- Migration paths\n- Real-world benchmarks', source: 'Hacker News', feedId: '2', date: '2026-01-08T10:00:00', read: true, starred: false, category: 'Tech' },
  { id: '9', title: 'Accessible UI Patterns for Modern Web Apps', excerpt: 'Practical accessibility techniques that improve UX for everyone...',
    content: 'Accessibility is not just a checklist - it\'s about creating experiences that work for everyone. This article covers practical UI patterns that improve accessibility while enhancing the experience for all users.\n\nPatterns covered:\n- Focus management in modals\n- ARIA live regions for notifications\n- Keyboard navigation patterns\n- Screen reader friendly data tables\n- Color-independent status indicators', source: 'Smashing Mag', feedId: '5', date: '2026-01-07T08:00:00', read: false, starred: true, category: 'Design' },
  { id: '10', title: 'The State of AI-Powered Development Tools', excerpt: 'How AI is reshaping the developer experience in 2026...',
    content: 'AI-powered development tools have matured significantly in 2026. From intelligent code completion to automated testing, AI is becoming an integral part of the developer workflow.\n\nThis article examines:\n- Current AI coding assistants\n- Automated code review tools\n- AI-generated documentation\n- Testing and debugging with AI\n- Ethical considerations and limitations', source: 'TechCrunch', feedId: '1', date: '2026-01-06T12:00:00', read: true, starred: false, category: 'Tech' },
  { id: '11', title: 'Building Custom React Hooks: Best Practices', excerpt: 'Patterns and anti-patterns for creating reusable React hooks...',
    content: 'Custom React hooks are one of the most powerful features of React, but they\'re often misused. This article covers best practices for creating hooks that are truly reusable and composable.\n\nTopics:\n- Hook composition patterns\n- Dependencies management\n- Avoiding common pitfalls\n- Testing custom hooks\n- Documentation strategies', source: 'Dev.to', feedId: '3', date: '2026-01-05T14:00:00', read: false, starred: false, category: 'Dev' },
  { id: '12', title: 'Modern CSS Layout Techniques', excerpt: 'Grid, Flexbox, and the new layout algorithms you should know...',
    content: 'CSS layout has evolved dramatically. Modern techniques like subgrid, anchor positioning, and CSS nesting are changing how we approach page and component layouts.\n\nThis comprehensive guide covers:\n- CSS Grid advanced patterns\n- Subgrid practical applications\n- Anchor positioning API\n- CSS nesting best practices\n- Container query layout patterns\n- Future layout specifications', source: 'CSS-Tricks', feedId: '4', date: '2026-01-04T09:00:00', read: true, starred: false, category: 'Design' },
  { id: '13', title: 'WebAssembly: Beyond the Browser', excerpt: 'WASI and the future of portable server-side Wasm...',
    content: 'WebAssembly is breaking out of the browser. With WASI (WebAssembly System Interface), Wasm modules can now run on servers, edge devices, and even embedded systems.\n\nThis article explores:\n- WASI architecture and capabilities\n- Running Wasm on the server\n- Edge computing with Wasm\n- Security model and sandboxing\n- Performance characteristics', source: 'Hacker News', feedId: '2', date: '2026-01-03T11:00:00', read: false, starred: false, category: 'Tech' },
  { id: '14', title: 'Color Theory for Dark Mode Interfaces', excerpt: 'How to design effective dark themes that reduce eye strain...',
    content: 'Designing dark mode interfaces requires more than just inverting colors. This article explores the science behind dark mode design and provides practical guidance.\n\nKey topics:\n- Contrast ratios for dark backgrounds\n- Saturation adjustments in dark themes\n- Depth and elevation without shadows\n- Color temperature and eye strain\n- Accessibility considerations\n- Testing dark mode designs', source: 'Smashing Mag', feedId: '5', date: '2026-01-02T13:00:00', read: true, starred: false, category: 'Design' },
  { id: '15', title: 'Zustand vs Redux in 2026', excerpt: 'State management in modern React applications...',
    content: 'State management remains a crucial topic in React development. In 2026, Zustand and Redux continue to be popular choices, but they serve different use cases.\n\nComparison points:\n- Bundle size and performance\n- Developer experience\n- TypeScript integration\n- Middleware ecosystem\n- DevTools support\n- When to choose which', source: 'Dev.to', feedId: '3', date: '2026-01-01T10:00:00', read: false, starred: true, category: 'Dev' },
];

export default function RSSReader() {
  const [feeds, setFeeds] = useState<Feed[]>(FEEDS);
  const [articles, setArticles] = useState<Article[]>(DEMO_ARTICLES);
  const [selectedFeedId, setSelectedFeedId] = useState<string | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [showAddFeed, setShowAddFeed] = useState(false);
  const [newFeedUrl, setNewFeedUrl] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const filteredArticles = useMemo(() => {
    let result = articles;
    if (selectedFeedId) {
      result = result.filter((a) => a.feedId === selectedFeedId);
    }
    if (showUnreadOnly) {
      result = result.filter((a) => !a.read);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter((a) => a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q));
    }
    return result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [articles, selectedFeedId, showUnreadOnly, searchQuery]);

  const selectedArticle = articles.find((a) => a.id === selectedArticleId);

  const feedUnreadCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    feeds.forEach((f) => {
      counts[f.id] = articles.filter((a) => a.feedId === f.id && !a.read).length;
    });
    return counts;
  }, [articles, feeds]);

  const toggleStar = (id: string) => {
    setArticles((prev) => prev.map((a) => (a.id === id ? { ...a, starred: !a.starred } : a)));
  };

  const markRead = (id: string) => {
    setArticles((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const refreshFeeds = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1500);
  };

  const addFeed = () => {
    if (!newFeedUrl.trim()) return;
    const newFeed: Feed = {
      id: Date.now().toString(),
      name: new URL(newFeedUrl).hostname,
      url: newFeedUrl,
      category: 'Custom',
    };
    setFeeds((prev) => [...prev, newFeed]);
    setNewFeedUrl('');
    setShowAddFeed(false);
  };

  const formatDate = (d: string) => {
    const date = new Date(d);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (diff === 1) return '1d ago';
    if (diff < 7) return `${diff}d ago`;
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="w-full h-full flex flex-col" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Rss size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">RSS Reader</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
            <Search size={12} style={{ color: 'var(--text-muted)' }} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search articles..."
              className="bg-transparent outline-none w-36 text-xs"
              style={{ color: 'var(--text-primary)' }}
            />
          </div>
          <label className="flex items-center gap-1 text-[10px] cursor-pointer" style={{ color: 'var(--text-muted)' }}>
            <input
              type="checkbox"
              checked={showUnreadOnly}
              onChange={(e) => setShowUnreadOnly(e.target.checked)}
              className="rounded"
            />
            Unread
          </label>
          <button
            onClick={refreshFeeds}
            className="p-1.5 rounded-md hover:bg-[#222235] transition-colors"
            style={{ color: 'var(--text-secondary)' }}
          >
            <RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={() => setShowAddFeed(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors"
            style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
          >
            <Plus size={12} /> Add Feed
          </button>
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Feed sidebar */}
        <div className="w-44 flex flex-col shrink-0 overflow-hidden" style={{ background: 'var(--surface)', borderRight: '1px solid var(--border-subtle)' }}>
          <button
            onClick={() => setSelectedFeedId(null)}
            className="flex items-center justify-between px-3 py-2 mx-2 mt-2 rounded-md text-sm transition-colors"
            style={{
              background: !selectedFeedId ? 'rgba(201,168,76,0.12)' : 'transparent',
              color: !selectedFeedId ? 'var(--accent-gold)' : 'var(--text-secondary)',
            }}
          >
            <span className="flex items-center gap-2">
              <Newspaper size={14} />
              All Feeds
            </span>
            <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{articles.length}</span>
          </button>
          {feeds.map((feed) => (
            <button
              key={feed.id}
              onClick={() => { setSelectedFeedId(feed.id); setSelectedArticleId(null); }}
              className="flex items-center justify-between px-3 py-2 mx-2 rounded-md text-sm transition-colors"
              style={{
                background: selectedFeedId === feed.id ? 'rgba(201,168,76,0.12)' : 'transparent',
                color: selectedFeedId === feed.id ? 'var(--accent-gold)' : 'var(--text-secondary)',
              }}
            >
              <span className="flex items-center gap-2 truncate">
                <Rss size={14} />
                {feed.name}
              </span>
              {feedUnreadCounts[feed.id] > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full shrink-0" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
                  {feedUnreadCounts[feed.id]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Article list */}
        <div className="w-80 flex flex-col shrink-0 overflow-hidden" style={{ borderRight: '1px solid var(--border-subtle)' }}>
          <div className="px-3 py-2 text-xs font-medium" style={{ color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)' }}>
            {filteredArticles.length} articles
          </div>
          <div className="flex-1 overflow-y-auto">
            {filteredArticles.map((article) => (
              <button
                key={article.id}
                onClick={() => { setSelectedArticleId(article.id); markRead(article.id); }}
                className="w-full flex flex-col gap-1 px-3 py-2.5 text-left transition-colors border-b"
                style={{
                  background: selectedArticleId === article.id ? 'rgba(201,168,76,0.08)' : 'transparent',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <div className="flex items-center gap-1.5">
                  {!article.read && <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: 'var(--accent-gold)' }} />}
                  <span className={`text-xs truncate flex-1 ${!article.read ? 'font-semibold' : ''}`} style={{ color: 'var(--text-primary)' }}>
                    {article.title}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px]" style={{ color: 'var(--text-secondary)' }}>{article.source}</span>
                  <span className="text-[10px] shrink-0" style={{ color: 'var(--text-muted)' }}>{formatDate(article.date)}</span>
                </div>
                <div className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>{article.excerpt}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Reading pane */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {selectedArticle ? (
            <>
              <div className="flex items-center justify-between px-4 py-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <div className="flex items-center gap-2">
                  <button onClick={() => toggleStar(selectedArticle.id)} className="transition-transform active:scale-90">
                    <Star size={16} fill={selectedArticle.starred ? 'var(--accent-gold)' : 'none'} style={{ color: selectedArticle.starred ? 'var(--accent-gold)' : 'var(--text-muted)' }} />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: 'var(--surface-elevated)', color: 'var(--text-secondary)' }}>
                    {selectedArticle.category}
                  </span>
                  <button className="p-1.5 rounded hover:bg-[#222235]" style={{ color: 'var(--text-muted)' }}>
                    <ExternalLink size={14} />
                  </button>
                </div>
              </div>
              <div className="px-4 py-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <h2 className="text-base font-semibold mb-2">{selectedArticle.title}</h2>
                <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <Newspaper size={12} />
                  <span>{selectedArticle.source}</span>
                  <span>·</span>
                  <Clock size={12} />
                  <span>{new Date(selectedArticle.date).toLocaleString()}</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto px-4 py-4 text-sm leading-relaxed whitespace-pre-wrap" style={{ color: 'var(--text-primary)' }}>
                {selectedArticle.content}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center gap-3" style={{ color: 'var(--text-muted)' }}>
              <Newspaper size={40} className="opacity-30" />
              <span className="text-sm">Select an article to read</span>
            </div>
          )}
        </div>
      </div>

      {/* Add Feed modal */}
      {showAddFeed && (
        <div className="absolute inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(3,3,5,0.6)', backdropFilter: 'blur(8px)' }}>
          <div className="w-96 rounded-xl overflow-hidden flex flex-col" style={{ background: 'var(--surface-elevated)', boxShadow: 'var(--shadow-window-active)' }}>
            <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
              <span className="text-sm font-semibold">Add Feed</span>
              <button onClick={() => setShowAddFeed(false)} className="p-1 rounded hover:bg-[#222235]">
                <X size={16} />
              </button>
            </div>
            <div className="p-4 flex flex-col gap-3">
              <div>
                <label className="text-xs block mb-1" style={{ color: 'var(--text-muted)' }}>Feed URL</label>
                <input
                  type="text"
                  value={newFeedUrl}
                  onChange={(e) => setNewFeedUrl(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') addFeed(); }}
                  placeholder="https://example.com/feed.xml"
                  className="w-full px-3 py-2 rounded-md text-xs outline-none font-mono"
                  style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
                />
              </div>
              <p className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                Enter a valid RSS or Atom feed URL. The feed will be fetched and parsed.
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 px-4 py-3" style={{ borderTop: '1px solid var(--border-subtle)' }}>
              <button onClick={() => setShowAddFeed(false)} className="px-3 py-1.5 rounded-md text-xs hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}>
                Cancel
              </button>
              <button
                onClick={addFeed}
                className="px-4 py-1.5 rounded-md text-xs font-medium"
                style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
              >
                Add Feed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
