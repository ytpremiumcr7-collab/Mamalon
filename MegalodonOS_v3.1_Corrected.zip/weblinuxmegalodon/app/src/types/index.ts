export type AppCategory =
  | 'system'
  | 'productivity'
  | 'development'
  | 'media'
  | 'communication'
  | 'science'
  | 'games'
  | 'flagship';

export interface AppDefinition {
  id: string;
  name: string;
  icon: string;
  category: AppCategory;
  component: string;
  defaultSize: { width: number; height: number };
  minSize: { width: number; height: number };
  pinned: boolean;
}

export interface WindowState {
  id: string;
  appId: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  prevSize?: { x: number; y: number; width: number; height: number };
}

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'error' | 'info';
  title: string;
  message: string;
  appId?: string;
  timestamp: number;
  actions?: { label: string; action: () => void }[];
}

export interface FileSystemNode {
  id: string;
  name: string;
  type: 'folder' | 'file';
  parentId: string | null;
  content?: string;
  icon?: string;
  createdAt: number;
  modifiedAt: number;
  size?: number;
  isOpen?: boolean;
}

export interface DesktopIconPosition {
  appId: string;
  x: number;
  y: number;
}

export interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
  items: ContextMenuItem[];
}

export interface ContextMenuItem {
  id: string;
  label: string;
  icon?: string;
  action: () => void;
  separator?: boolean;
  disabled?: boolean;
  submenu?: ContextMenuItem[];
}

export interface User {
  id: string;
  name: string;
  username: string;
  avatar?: string;
  isGuest: boolean;
}
